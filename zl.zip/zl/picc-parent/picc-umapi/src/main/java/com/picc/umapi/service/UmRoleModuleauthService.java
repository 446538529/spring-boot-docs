package com.picc.umapi.service;

import java.util.List;

import com.picc.umapi.model.UmRoleModuleauth;

public interface UmRoleModuleauthService {

	public static final String ROLE_START_STR = "MA"; // RoleId起始编码

	/** 分页查询 **/
	public List<UmRoleModuleauth> queryAllUmRolePage(UmRoleModuleauth umRoleModuleauth);

	/** 查询mdid列表 **/
	public List<String> queryUmRoleModuleauthMdid(UmRoleModuleauth umRoleModuleauth);

	/** 保存 数据 **/
	public int saveUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth);

	/** 删除 数据 **/
	public int delUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth);

	/** 更新 数据 **/
	public int updateUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth);

	/** 创建RoleId ***/
	public String makeMaId();
}
