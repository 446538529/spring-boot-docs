package com.picc.umapi.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.model.UmModuledict;

public interface UmModuledictService {

	public static final String ROUTE_TOP = "root";

	/** 分页查询 **/
	public PageInfo<UmModuledict> queryUmModuledictPage(UmModuledict umModuledict, PagingReqParam pagingReqParam);

	/** 查询 数据 **/
	public UmModuledict queryUmModuledict(UmModuledict umModuledict);

	/** 保存 数据 **/
	public int saveUmModuledict(UmModuledict umModuledict);

	/** 删除 数据 **/
	public int delUmModuledict(UmModuledict umModuledict);

	/** 更新 数据 **/
	public int updateUmModuledict(UmModuledict umModuledict);

	/** 查询菜单目录 **/
	public List<Map<String, Object>> queryUmModuleTree(String sysCode, String topId);

	public List<Map> makeRoutesMap(String userCode, String sysCode, String topId);

}
