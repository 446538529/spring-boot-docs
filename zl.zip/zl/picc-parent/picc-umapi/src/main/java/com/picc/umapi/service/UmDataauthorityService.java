package com.picc.umapi.service;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.model.UmDataauthority;

public interface UmDataauthorityService {

	/** 保存 数据 **/
	public int saveUmDataAuthority(UmDataauthority umDataAuthority);

	/** 删除 数据 **/
	public int delUmDataAuthority(UmDataauthority umDataAuthority);

	/** 查询 数据 **/
	public PageInfo<UmDataauthority> queryDataAuthority(String usercode, Integer pageIndex, Integer pageSize);
}
