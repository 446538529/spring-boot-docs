package com.picc.umapi.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmComMapper;
import com.picc.umapi.model.UmCom;
import com.picc.umapi.req.QryComNameByKeyword;

public interface UmComMapper extends BaseUmComMapper {

	public List<UmCom> queryUmComPage();

	UmCom queryUmComByCode(String comcode);

	public List<QryComNameByKeyword> qryComNameByKey(@Param("keyWord") String keyWord,
			@Param("list") List<String> comLikeList);

}
