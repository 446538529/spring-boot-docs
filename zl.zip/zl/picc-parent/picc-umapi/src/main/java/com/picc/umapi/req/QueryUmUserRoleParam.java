package com.picc.umapi.req;

import com.picc.common.PagingReqParam;
import com.picc.common.ReqParam;

public class QueryUmUserRoleParam extends PagingReqParam implements ReqParam {

	private static final long serialVersionUID = 1L;

	private String urid;

	private String usercode;

	private String userid;

	private String roleid;

	private String validstatus;

	private String syscode;

	public String getUrid() {
		return urid;
	}

	public void setUrid(String urid) {
		this.urid = urid;
	}

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getRoleid() {
		return roleid;
	}

	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}

	public String getValidstatus() {
		return validstatus;
	}

	public void setValidstatus(String validstatus) {
		this.validstatus = validstatus;
	}

	public String getSyscode() {
		return syscode;
	}

	public void setSyscode(String syscode) {
		this.syscode = syscode;
	}

}
