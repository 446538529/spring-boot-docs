/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.picc.umapi.model.rowmodel.annotation;