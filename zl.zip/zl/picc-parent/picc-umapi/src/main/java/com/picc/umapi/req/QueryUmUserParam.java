package com.picc.umapi.req;

import com.picc.common.PagingReqParam;
import com.picc.common.ReqParam;

public class QueryUmUserParam extends PagingReqParam implements ReqParam {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String usercode;

	private String username;

	private String mobileno;

	private String comcode;

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getComcode() {
		return comcode;
	}

	public void setComcode(String comcode) {
		this.comcode = comcode;
	}

}
