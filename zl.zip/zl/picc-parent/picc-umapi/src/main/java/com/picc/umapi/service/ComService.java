package com.picc.umapi.service;

public interface ComService {

}
