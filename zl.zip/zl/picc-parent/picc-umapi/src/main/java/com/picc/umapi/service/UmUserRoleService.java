package com.picc.umapi.service;

import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.req.QueryUmUserRoleParam;
import com.picc.umapi.vo.UmUserRoleVO;

public interface UmUserRoleService {

	public static final String ROLE_START_STR = "UR"; // 角色起始编码

	/** 分页查询 **/
	public PageInfo<UmUserRoleVO> queryUmUserrolePage(QueryUmUserRoleParam queryUmUserRoleParam, String syscode, PagingReqParam pagingReqParam);

	/** 查询 数据 **/
	public UmUserrole queryUmUserrole(UmUserrole umUserrole);

	/** 保存 数据 **/
	public int saveUmUserrole(UmUserrole umUserrole);

	/** 删除 数据 **/
	public int delUmUserrole(UmUserrole umUserrole);

	/** 更新 数据 **/
	public int updateUmUserrole(UmUserrole umUserrole);

	/** 删除用户角色关联菜单 **/
	public int cleanUmUserrole(UmUserrole umUserrole);

	/** 清空指定用户所有角色及关联菜单 **/
	public int resetUmUserrole(String usercode, String syscode);

	/** 创建一个新的urid **/
	public String makeUrId();
}
