package com.picc.umapi.utils;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.script.ScriptException;

import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

/**
 * 字符串编码转换,空字符串,空白字符串转换
 * 
 * @author chenjin 2016-9-26
 */
public class CodeUtil {

	public static String makeSysTime(int field, int amount) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(field, amount);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(calendar.getTime());
	}

	/**
	 * 根据日期格式返回日期类型,可用于组合随机数
	 * 
	 * @param format
	 *            日期格式 如：yyyyMMddHHmmssSSS
	 * @return
	 */
	public static String makeSysTime(String format) {
		Calendar calendar = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat(format);
		return df.format(calendar.getTime());
	}

	public static String makeSysTime(int pyear, int pmonth, int pday, String format) {
		Calendar calendar = Calendar.getInstance();
		if (pyear > 0) {
			calendar.set(Calendar.YEAR, pyear);
		}
		if (pmonth > 0 && pmonth < 13) {
			calendar.set(Calendar.MONTH, pmonth);
		}
		if (pday > 0 && pday < 32) {
			calendar.set(Calendar.DAY_OF_MONTH, pday);
		}

		DateFormat df = new SimpleDateFormat(format);
		return df.format(calendar.getTime());
	}

	public static Calendar makeSysTime(String src, String format) {
		Calendar calendar = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat(format);
		try {
			calendar.setTime(df.parse(src));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return calendar;
	}

	public static String makeSysTime(Date src, String format) {
		DateFormat df = new SimpleDateFormat(format);
		return df.format(src);
	}

	public static String makeSysTime(Calendar calendar, String format) {
		DateFormat df = new SimpleDateFormat(format);
		return df.format(calendar.getTime());
	}

	public static Date makeSysTime() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}

	public static String makeSysTime(long src, String format) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(src);
		return makeSysTime(calendar, format);
	}

	/**
	 * 利用时间ID
	 * 
	 * @return
	 */
	public static String makeID() {
		return new StringBuilder().append(System.currentTimeMillis() / 1000).append(System.nanoTime()).toString();
	}

	/***** 返回去除-字符并转为大写的UUID ****/
	public static String makeUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}

	public static boolean nullOrBlank(String src) {
		return !StringUtils.hasText(src);
	}

	@SuppressWarnings({ "rawtypes" })
	public static boolean nullOrBlank(List src) {
		if (src == null) {
			return true;
		}
		return src.isEmpty();
	}

	@SuppressWarnings({ "rawtypes" })
	public static Method makeSetMethod(Class clazz, String name) {
		if (!StringUtils.hasText(name)) {
			return null;
		}
		return ReflectionUtils.findMethod(clazz, new StringBuilder("set").append(name.substring(0, 1).toUpperCase()).append(name.substring(1)).toString(), ReflectionUtils.findField(clazz, name).getType());
	}

	@SuppressWarnings({ "rawtypes" })
	public static Method makeGetMethod(Class clazz, String name) {
		if (!StringUtils.hasText(name)) {
			return null;
		}
		return ReflectionUtils.findMethod(clazz, new StringBuilder("get").append(name.substring(0, 1).toUpperCase()).append(name.substring(1)).toString());
	}

	public static Long makeLID() {
		return System.currentTimeMillis();
	}

	public static void main(String[] args) throws ScriptException {
	}

}
