package com.picc.umapi.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.model.UmRole;

/**
 * 角色信息业务接口
 * 
 * @author hzx
 *
 */
public interface UmRoleService {

	public static final String ROLE_START_STR = "RO"; // 角色起始编码

	/** 分页查询 **/
	public PageInfo<UmRole> queryUmRolePage(UmRole umRole, PagingReqParam pagingReqParam);

	/** 列表查询 **/
	public List<UmRole> queryUmRoleList(UmRole umRole);

	/** 删除 数据 **/
	public int delUmRole(UmRole umRole);

	/** 创建RoleId ***/
	public String makeRoleId();

	/** 合并RoleId(存在就更新,不存在就创建) ***/
	public int megerRole(UmRole umRole);

	/** 查询 数据 ByName **/
	public UmRole queryUmRoleByName(String rolename, String syscode);
}
