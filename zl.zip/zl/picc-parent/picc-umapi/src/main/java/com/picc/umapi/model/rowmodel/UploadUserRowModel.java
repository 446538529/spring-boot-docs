package com.picc.umapi.model.rowmodel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;
import com.picc.umapi.model.rowmodel.annotation.Regexp;
import com.picc.umapi.model.rowmodel.annotation.Required;

/**
 * @author hzx
 *
 */
public class UploadUserRowModel extends BaseRowModel {

	@ExcelProperty(value = "人员代码")
	@Regexp(value = "^\\d{8}$")
	@Required
	private String usercode;

	@ExcelProperty(value = "人员名称")
	@Required
	private String username;

	@ExcelProperty(value = "手机号码")
	@Regexp(value = "^\\d{11}$")
	@Required
	private String mobileno;

	@ExcelProperty(value = "电子邮箱")
	@Required
	private String email;

	@ExcelProperty(value = "用户密码")
	@Required
	private String passwd;

	@ExcelProperty(value = "机构代码")
	@Regexp(value = "^\\d{8}$")
	@Required
	private String comcode;

	@ExcelProperty(value = "权限等级")
	@Regexp(value = "^[0-3]{1}$")
	@Required
	private String datalevel;

	@ExcelProperty(value = "有效状态")
	@Regexp(value = "^[0-1]{1}$")
	@Required
	private String validstatus;

	@ExcelProperty(value = "用户角色代码")
	private String roleid;

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getComcode() {
		return comcode;
	}

	public void setComcode(String comcode) {
		this.comcode = comcode;
	}

	public String getDatalevel() {
		return datalevel;
	}

	public void setDatalevel(String datalevel) {
		this.datalevel = datalevel;
	}

	public String getValidstatus() {
		return validstatus;
	}

	public void setValidstatus(String validstatus) {
		this.validstatus = validstatus;
	}

	public String getRoleid() {
		return roleid;
	}

	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}

}
