package com.picc.umapi.service;

import java.util.List;

import com.picc.umapi.model.UmTaskPost;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.UpdateUmTaskPostParam;

public interface UmTaskPostService {

	/** 查询任务岗位描述信息*/
	public List<UmTaskPost> qryUmTaskPostList();
	
	/** 查询重复支付核查人员*/
	public List<QueryTaskUserListReq> qryTaskUserList(String id);
	
	/** 删除任务岗位用户*/
	public int delUmTaskPost(UpdateUmTaskPostParam updateParam);
	
	/** 添加任务岗位用户*/
	public int addUmTaskPost(UpdateUmTaskPostParam updateParam);
	
	/**
	 * 根据环节名称查询用户编码配置
	 */
	public List<String> qryUserCodeList(String taskName);
	
}
