package com.picc.umapi.req;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("重置用户角色与菜单权限参数")
public class RefreshUmUserRoleParam implements ReqParam {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty("员工编号")
	private String usercode;

	@ApiModelProperty("菜单权限")
	private String userRole;

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

}
