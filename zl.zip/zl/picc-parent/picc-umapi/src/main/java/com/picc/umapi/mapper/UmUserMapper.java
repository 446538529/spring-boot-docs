package com.picc.umapi.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmUserMapper;
import com.picc.umapi.model.UmUser;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.QueryUmUserParam;
import com.picc.umapi.req.SaveUmUserParam;

public interface UmUserMapper extends BaseUmUserMapper {

	/** 查询 数据集 **/
	public List<UmUser> queryUmUserPage(QueryUmUserParam queryUmUserParam);

	/** 查询 数据 **/
	public UmUser queryUmUser(String usercode);

	/** 删除 数据 **/
	public int delUmUser(UmUser umUser);

	/** 保存 **/
	public int saveUmUser(SaveUmUserParam umUser);

	/** 更新 数据 **/
	public int updateUmUser(SaveUmUserParam umUser);

	/** 查询 数据 **/
	List<UmUser> qryUserByList(List<String> userCodeList);

	/** 查询 数据 **/
	List<QueryTaskUserListReq> qryUserByTaskPostId(String taskPostId);

	public List<QueryTaskUserListReq> qryUserByCodeOrName(@Param("keyWord") String keyWord);

	// 模糊查询
	List<UmUser> queryUmUserByValue(@Param("value") String value);

	public String qryComNameByUsreCode(String userCode);

}
