package com.picc.umapi.mapper;

import com.picc.utils.mybatis.generator.MyBatisGeneratorUtils;

public class UmapiGenerator {

	public static void main(String[] args) {

		MyBatisGeneratorUtils.generator("generator/umapiGeneratorConfig.xml", UmapiGenerator.class);

	}

}
