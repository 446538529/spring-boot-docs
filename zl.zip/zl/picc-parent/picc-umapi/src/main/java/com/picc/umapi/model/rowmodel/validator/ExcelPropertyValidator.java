package com.picc.umapi.model.rowmodel.validator;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.excel.annotation.ExcelProperty;
import com.picc.umapi.model.rowmodel.annotation.MaxLength;
import com.picc.umapi.model.rowmodel.annotation.Regexp;
import com.picc.umapi.model.rowmodel.annotation.Required;
import com.picc.umapi.model.rowmodel.annotation.ValueLimit;
import com.picc.umapi.model.rowmodel.annotation.VerifyDate;

public class ExcelPropertyValidator {
	
	private static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private static SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd");
	
	public static boolean valid(Object obj, List<String> errors) {
		boolean valid = true;
		Class<?> clazz = obj.getClass();
		
		Field[] fields = clazz.getDeclaredFields();
		for (Field field : fields) {
			ExcelProperty excelProperty = field.getAnnotation(ExcelProperty.class);
			// 不校验无 @ExcelProperty字段
			if (excelProperty == null) {
				continue;
			}
			String name = "";
			if (excelProperty.value().length > 0) {
				name = excelProperty.value()[0];
			}
			// 获取字段属性值
			Object value = getValue(clazz, field.getName(), obj);
			String val = null;
			if (value != null) {
				val = String.valueOf(value);
			}
			
			// 必填校验
			Required required = field.getAnnotation(Required.class);
			if (validRequreid(required, name, val, errors) == false) {
				valid = false;
				continue;
			}
			
			// 长度校验
			MaxLength maxLength = field.getAnnotation(MaxLength.class);
			if(validMaxLength(maxLength, name, val, errors) == false) {
				valid = false;
				continue;
			}
			
			// 正则校验
			Regexp regexp = field.getAnnotation(Regexp.class);
			if(validRegexp(regexp, name, val, errors) == false) {
				valid = false;
				continue;
			}
			// 时间格式校验
			VerifyDate verifyDate = field.getAnnotation(VerifyDate.class);
			if(validValueDate(verifyDate, name, val, errors) == false) {
				valid = false;
				continue;
			}
			// 指定值范围校验
			ValueLimit valueLimit = field.getAnnotation(ValueLimit.class);
			if(validValueLimit(valueLimit, name, val, errors) == false) {
				valid = false;
				continue;
			}
		}
		return valid;
	}
	// 校验必填项
	private static boolean validRequreid(Required required, String name, String val, List<String> errors) {
		if (required != null && required.value() == true) {
			try {
				if (StringUtils.isBlank(val)) {
					errors.add(name + "为必填项");
					return false;
				}
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} 
		}
		return true;
	}
	
	// 长度校验
	private static boolean validMaxLength(MaxLength maxLength, String name, String val, List<String> errors) {
		if(null != maxLength) {
			if (val != null && val.length() > maxLength.value()) {
				errors.add(name + "不能超过" + maxLength.value() + "个字符");
				return false;
			}
		}
		return true;
	}
	
	//  正则校验
	private static boolean validRegexp(Regexp regexp, String name, String val, List<String> errors) {
		if(null != regexp) {
			if (StringUtils.isNotBlank(val)) {
				if(!val.matches(regexp.value())) {
					errors.add(name + "数据格式有误，请检查");
					return false;
				}
			}
		}
		return true;
	}
	
	// 指定值范围校验
	private static boolean validValueLimit(ValueLimit valueLimit, String name, String val, List<String> errors) {
		if(null != valueLimit) {
			if (!Arrays.asList(valueLimit.value()).contains(val)) {
				errors.add(name + "只能为:" + StringUtils.join(valueLimit.value(),"/"));
				return false;
			}
		}
		return true;
	}
	
	// 时间校验
	private static boolean validValueDate(VerifyDate verifyDate, String name, String val, List<String> errors) {
		if(null != verifyDate) {
			if(StringUtils.isNotBlank(val)) {
				if(verifyDate.value().equals("01")) {
					try {
						sdf1.parse(val);
					} catch (Exception e) {
						errors.add(name + "日期格式必须为:年/月/日 时:分:秒");
						return false;
					}
				}
				if(verifyDate.value().equals("02")) {
					try {
						sdf2.parse(val);
					} catch (Exception e) {
						errors.add(name + "日期格式必须为:年/月/日");
						return false;
					}
				}
			}
		}
		return true;
	}
	
	//反射获取属性值
	public static Object getValue(Class<?> objectClass, String fieldName, Object obj) {  
		// "id" -> getId
       StringBuffer sb = new StringBuffer();  
       sb.append("get");  
       sb.append(fieldName.substring(0, 1).toUpperCase());  
       sb.append(fieldName.substring(1));  
       try {  
           Method method = objectClass.getMethod(sb.toString()); 
           return method.invoke(obj);
       } catch (Exception e) {  
       }  
       return null;  
    }  

}
