package com.picc.umapi.vo;

import io.swagger.annotations.ApiModelProperty;

public class DemoVO {

	@ApiModelProperty("姓名")
	private String name;

	@ApiModelProperty("年龄")
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
