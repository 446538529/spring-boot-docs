package com.picc.umapi.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.picc.umapi.mapper.UmRolePostMapper;
import com.picc.umapi.mapper.UmTaskPostMapper;
import com.picc.umapi.mapper.UmUserMapper;
import com.picc.umapi.model.UmRolePost;
import com.picc.umapi.model.UmTaskPost;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.UpdateUmTaskPostParam;
import com.picc.umapi.service.UmTaskPostService;

@Service("umTaskPostService")
public class UmTaskPostServiceImpl implements UmTaskPostService {

	private static final String TASK_POST_AUDIT = "审核岗";

	private static final String TASK_POST_CLAIM = "核赔岗";

	private static final String TASK_POST_SYNTHESIS = "综合部";

	private static final String TASK_POST_FINANCE_MANAGER = "财务主管";

	private static final String TASK_POST_PAYMENT_POST = "支付岗";

	private static final String TASK_DEPARTMENT_CLAIM_CATREER = "理赔";

	@Autowired
	private UmTaskPostMapper umTaskPostMapper;

	@Autowired
	private UmRolePostMapper umRolePostMapper;

	@Autowired
	private UmUserMapper umUserMapper;

	@Override
	public List<UmTaskPost> qryUmTaskPostList() {
		return umTaskPostMapper.qryUmTaskPostList();
	}

	@Override
	public List<QueryTaskUserListReq> qryTaskUserList(String id) {
		List<QueryTaskUserListReq> queryTaskUserListReq = umUserMapper.qryUserByTaskPostId(id);
		// 岗位名称
		// 任务环节(01:财务任务发起; 02:支公司/理赔初审; 03:财务主管复审; 04:财务终审; 05:财务资金付款)
		for (QueryTaskUserListReq taskUser : queryTaskUserListReq) {
			if (StringUtils.equals(id, "01") || StringUtils.equals(id, "04")) {
				taskUser.setPostName(TASK_POST_AUDIT);
			} else if (StringUtils.equals(id, "02")) {
				taskUser.setPostName(TASK_POST_SYNTHESIS);
				String comName = umUserMapper.qryComNameByUsreCode(taskUser.getUserCode());
				if (comName.contains(TASK_DEPARTMENT_CLAIM_CATREER)) {
					taskUser.setPostName(TASK_POST_CLAIM);
				}
			} else if (StringUtils.equals(id, "03")) {
				taskUser.setPostName(TASK_POST_FINANCE_MANAGER);
			} else if (StringUtils.equals(id, "05")) {
				taskUser.setPostName(TASK_POST_PAYMENT_POST);
			}
		}
		return queryTaskUserListReq;
	}

	@Override
	public int delUmTaskPost(UpdateUmTaskPostParam updateParam) {
		return umRolePostMapper.delete(updateParam.getId(), updateParam.getUserCode());
	}

	@Override
	public int addUmTaskPost(UpdateUmTaskPostParam updateParam) {
		int update = 0;
		// 查询用户是否已经添加
		UmRolePost umRolePost = umRolePostMapper.qryUmRolePostByTaskUserId(updateParam.getUserCode(),
				updateParam.getId());
		if (umRolePost != null) {
			return 2;
		}

		// 保存到数据库
		UmRolePost record = new UmRolePost();
		record.setInserttime(new Date());
		record.setTaskpostid(updateParam.getId());
		record.setUsercode(updateParam.getUserCode());
		update = umRolePostMapper.insertSelective(record);

		return update;
	}

	@Override
	public List<String> qryUserCodeList(String taskName) {
		return umRolePostMapper.qryUserCodeList(taskName);
	}

}
