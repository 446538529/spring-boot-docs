package com.picc.umapi.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.picc.umapi.mapper.UmComMapper;
import com.picc.umapi.model.UmCom;
import com.picc.umapi.service.UmComService;

/**
 * 公司信息业务实现
 * 
 * @author hzx
 *
 */
@Service
public class UmComServiceImpl implements UmComService {

	private static Logger log = LoggerFactory.getLogger(UmComServiceImpl.class);
	@Autowired
	private UmComMapper umComMapper;

	/**
	 * @Description:批量查询支公司信息
	 * @author: HeZhuxing
	 */
	@Override
	public List<UmCom> queryUmComPage() {
		List<UmCom> queryUmComPage = umComMapper.queryUmComPage();
		return queryUmComPage;
	}

	@Override
	public UmCom queryUmComByCode(String comcode) {
		return umComMapper.queryUmComByCode(comcode);
	}

}
