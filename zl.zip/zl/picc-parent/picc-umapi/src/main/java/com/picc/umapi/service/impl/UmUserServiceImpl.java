package com.picc.umapi.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.umapi.mapper.UmTokenMapper;
import com.picc.umapi.mapper.UmUserMapper;
import com.picc.umapi.model.UmUser;
import com.picc.umapi.model.UmUserPermis;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.QueryUmUserParam;
import com.picc.umapi.req.SaveUmUserParam;
import com.picc.umapi.service.UmUserPermisService;
import com.picc.umapi.service.UmUserService;

@Service("umUserService")
public class UmUserServiceImpl implements UmUserService {

	private static Logger log = LoggerFactory.getLogger(ComServiceImpl.class);

	@Autowired
	private UmUserMapper userMapper;
	@Autowired
	private UmTokenMapper umTokenService;
	@Autowired
	private UmUserPermisService userPermisService;

	@Override
	public PageInfo<UmUser> queryUmUserPage(QueryUmUserParam queryUmUserParam) {
		if (queryUmUserParam == null)
			return null;
		PageInfo<UmUser> doSelectPageInfo = PageHelper
				.startPage(queryUmUserParam.getPageIndex(), queryUmUserParam.getPageSize())
				.doSelectPageInfo(() -> userMapper.queryUmUserPage(queryUmUserParam));
		return doSelectPageInfo;
	}

	@Override
	public UmUser queryUmUser(String usercode) {
		return userMapper.queryUmUser(usercode);
	}

	@Override
	public int saveUmUser(SaveUmUserParam umUser) {
		if (umUser == null) {
			return -1;
		}
		umUser.setUserid("U" + umTokenService.createToken());
		return userMapper.saveUmUser(umUser);
	}

	@Override
	public int delUmUser(UmUser umUser) {
		return userMapper.delUmUser(umUser);
	}

	@Override
	public int updateUmUser(SaveUmUserParam umUser) {
		return userMapper.updateUmUser(umUser);
	}

	@Override
	public int megerUser(SaveUmUserParam umUser) {
		UmUser queryUmUser = queryUmUser(umUser.getUsercode());
		if (queryUmUser != null) {
			umUser.setUserid(queryUmUser.getUserid());
			return updateUmUser(umUser);
		}
		// 保存对应的权限
		UmUserPermis umUserPermis = new UmUserPermis();
		umUserPermis.setId(umTokenService.createToken());
		umUserPermis.setPermistype("1");
		umUserPermis.setValidstatus("1");
		umUserPermis.setUsercode(umUser.getUsercode());
		umUserPermis.setPermiscode(umUser.getUsercode());
		userPermisService.insert(umUserPermis);
		// 默认配置支公司权限(数据权限值为对应的机构代码)
		umUserPermis = new UmUserPermis();
		umUserPermis.setId(umTokenService.createToken());
		umUserPermis.setPermistype("2");
		umUserPermis.setValidstatus("1");
		umUserPermis.setUsercode(umUser.getUsercode());
		umUserPermis.setPermiscode(umUser.getComcode());
		userPermisService.insert(umUserPermis);
		return saveUmUser(umUser);
	}

	@Override
	public int updateUmUser(UmUser umUser) {
		return userMapper.updateByPrimaryKeySelective(umUser);
	}

	@Override
	public List<UmUser> qryUserByCodeOrName(String value) {
		return userMapper.queryUmUserByValue(value);
	}

	@Override
	public List<QueryTaskUserListReq> qryUmTaskUserList(String keyWord) {
		return userMapper.qryUserByCodeOrName(keyWord);
	}

}
