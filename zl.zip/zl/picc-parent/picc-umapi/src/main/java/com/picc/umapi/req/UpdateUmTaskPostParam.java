package com.picc.umapi.req;

import javax.validation.constraints.NotNull;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("更新任务环节描述参数")
public class UpdateUmTaskPostParam implements ReqParam {

	private static final long serialVersionUID = 1L;

	@NotNull
	@ApiModelProperty("任务岗位id")
	private String id;

	@NotNull
	@ApiModelProperty("用户代码")
	private String userCode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

}
