package com.picc.umapi.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmRolePostMapper;
import com.picc.umapi.model.UmRolePost;
import com.picc.umapi.req.QueryTaskUserListReq;

public interface UmRolePostMapper extends BaseUmRolePostMapper {

	/** 删除数据 */
	public int delete(@Param("taskPostId") String taskPostId, @Param("userCode") String userCode);

	/** 根据任务用户id查询数据 */
	public UmRolePost qryUmRolePostByTaskUserId(@Param("userCode") String userCode,
			@Param("taskPostId") String taskPostId);

	public List<QueryTaskUserListReq> qryUmRolePostByUserCode(String userCode);

	public List<QueryTaskUserListReq> qryTaskUserListByValue(@Param("list") List<String> list,
			@Param("comName") String comName, @Param("taskName") String taskName);

	public QueryTaskUserListReq qryTaskUserByUserCode(@Param("userCode") String userCode,
			@Param("taskPostId") String taskPostId);

	/** 查询岗位配置人员  */
	public List<String> qryUserCodeList(String taskName);

}
