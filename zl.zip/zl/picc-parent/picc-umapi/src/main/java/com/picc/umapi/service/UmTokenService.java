package com.picc.umapi.service;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.model.UmToken;

public interface UmTokenService {

	/** 分页查询 **/
	public PageInfo<UmToken> queryUmTokenPage(UmToken umToken, Integer pageIndex, Integer pageSize);

	/** 查询 数据 **/
	public UmToken queryUmToken(UmToken umToken);

	/** 保存 数据 **/
	public int saveUmToken(UmToken umToken);

	/** 删除 数据 **/
	public int delUmToken(UmToken umToken);

	/** 更新 数据 **/
	public int updateUmToken(UmToken umToken);

	public String createToken();

	public UmToken checkUmToken(String token);
}
