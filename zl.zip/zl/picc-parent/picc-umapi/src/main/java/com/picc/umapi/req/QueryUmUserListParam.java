package com.picc.umapi.req;

import com.picc.common.PagingReqParam;
import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("添加任务岗位用户参数")
public class QueryUmUserListParam extends PagingReqParam implements ReqParam{

	private static final long serialVersionUID = 1L;

	@ApiModelProperty("查询关键字")
	private String keyWord;

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	
}
