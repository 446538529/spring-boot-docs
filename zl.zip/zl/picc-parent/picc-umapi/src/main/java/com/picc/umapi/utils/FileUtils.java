package com.picc.umapi.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.picc.common.servlet.ContextUtils;
import com.picc.utils.RandomUtils;

/**
 * 文件下载及保存工具类
 * 
 * @author hzx
 *
 */
public class FileUtils {

	private static final Logger log = LoggerFactory.getLogger(FileUtils.class);

	public static final String MIME_XLS = "application/vnd.ms-excel";

	public static final String MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

	private static final SimpleDateFormat datePathFormat = new SimpleDateFormat("yyyy/MM/dd");
	
	private static final SimpleDateFormat tsFilenameFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");

	/**
	 * 保存文件
	 * 
	 * @param multipartFile
	 *            上传的文件
	 * @param path
	 *            保存路径
	 * @return 保存的文件路径
	 */
	public static String save(MultipartFile multipartFile, String path) {
		return save(multipartFile, path, null);
	}

	/**
	 * 保存文件
	 * 
	 * @param multipartFile
	 *            上传的文件
	 * @param path
	 *            保存路径
	 * @param filename
	 *            需要保存的文件名
	 * @return 保存的文件路径
	 */
	public static String save(MultipartFile multipartFile, String path, String filename) {
		StringBuilder pathBuilder = new StringBuilder(path);
		if (!path.endsWith("/")) {
			pathBuilder.append("/");
		}
		
		// 没有指定文件名 则使用时间[yyyyMMddHHmmssSSS] + 4为随机字母
		if (StringUtils.isNotBlank(filename)) {
			pathBuilder.append(filename);
		} else {
			pathBuilder.append(tsFilenameFormat.format(new Date()) + RandomUtils.getRandomLowerCaseLetters(4));
		}

		// 添加上传文件名后缀
		String[] names = multipartFile.getOriginalFilename().split("\\.");
		if (names.length > 1 && names[names.length - 1].indexOf("/") == -1) {
			pathBuilder.append(".").append(names[names.length - 1]);
		}
		
		// 创建目录
		File file = new File(pathBuilder.toString());
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		
		// 保存文件
		try (FileOutputStream outputStream = new FileOutputStream(file)) {
			IOUtils.copy(multipartFile.getInputStream(), outputStream);
		} catch (Exception e) {
			log.error("保存文件失败", e);
			return null;
		}
		
		// 返回保存的文件目录
		return pathBuilder.toString();
	}

	/**
	 * 保存文件(在上传路径后添加日期路径)
	 * 
	 * @param multipartFile
	 *            上传的文件
	 * @param path
	 *            保存的路径
	 * @return 保存的文件路径
	 */
	public static String saveWithDate(MultipartFile multipartFile, String path) {
		return saveWithDate(multipartFile, path, null);
	}

	/**
	 * 保存文件(在上传路径后添加日期路径)
	 * 
	 * @param multipartFile
	 * @param path
	 *            保存的路径
	 * @param filename
	 *            保存文件名
	 * @return 保存的文件路径
	 */
	public static String saveWithDate(MultipartFile multipartFile, String path, String filename) {
		StringBuilder pathBuilder = new StringBuilder(path);
		if (!path.endsWith("/")) {
			pathBuilder.append("/");
		} else {
			pathBuilder.append(datePathFormat.format(new Date()));
		}
		return save(multipartFile, pathBuilder.toString(), filename);
	}

	/**
	 * 下载本地文件
	 * 
	 * @param fullPath
	 * @param response
	 */
	public static void download(String fullPath, HttpServletResponse response) {
		download(fullPath, null, response);
	}

	/**
	 * 下载本地文件
	 * 
	 * @param fullPath
	 * @param response
	 */
	public static void download(String fullPath, String filename, HttpServletResponse response) {
		File file = new File(fullPath);
		if (!file.exists()) {
			log.warn("下载文件不存在{}", fullPath);
			try {
				response.getWriter().write("下载文件不存在");
			} catch (IOException e) {
				log.error("respones 输出异常", e);
			}
			return;
		}
		
		// 设置下载MIME类型
		String contentType = "application/x-msdownload";
		if (fullPath.endsWith(".xls")) {
			contentType = MIME_XLS;
		} else if (fullPath.endsWith(".xlsx")) {
			contentType = MIME_XLSX;
		}
		
		// 设置默认文件名
		if (StringUtils.isEmpty(filename)) {
			filename = file.getName();
		}
		
		try (FileInputStream inputStream = new FileInputStream(file)) {
			download(inputStream, response, contentType, filename);
		} catch (IOException e) {
			log.error("读取本地文件异常", e);
		}
	}

	/**
	 * 下载文件
	 * 
	 * @param inputStream
	 * @param response
	 * @param contentType
	 * @param filename
	 */
	public static void download(InputStream inputStream, HttpServletResponse response, String contentType, String filename) {
		response.reset();
		try (OutputStream output = response.getOutputStream()) {
			response.setContentType(contentType);
			String userAgent = ContextUtils.getRequest().getHeader("User-Agent");
			if (userAgent != null && StringUtils.contains(userAgent, "Firefox")) {
				filename = URLEncoder.encode(filename, "utf-8");
				response.setHeader("Content-Disposition", "attachment; filename*=utf-8'zh_cn'" + filename);
			} else {
				response.setHeader("Content-Disposition", "attachment; filename=" + filename);
			}
			IOUtils.copy(inputStream, output);
		} catch (Exception e) {
			log.error("下载文件异常", e);
		}
	}
}
