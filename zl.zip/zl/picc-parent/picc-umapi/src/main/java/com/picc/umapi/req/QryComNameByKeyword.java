package com.picc.umapi.req;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="任务处理部门出参")
public class QryComNameByKeyword implements ReqParam {
	
	private static final long serialVersionUID = 1L;

	@ApiModelProperty("机构代码")
	private String comCode;
	
	@ApiModelProperty("机构名称")
	private String comName;

	public String getComCode() {
		return comCode;
	}

	public void setComCode(String comCode) {
		this.comCode = comCode;
	}

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}
	
}
