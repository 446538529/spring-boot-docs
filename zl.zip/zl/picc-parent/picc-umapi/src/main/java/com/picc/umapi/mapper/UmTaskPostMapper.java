package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmTaskPostMapper;
import com.picc.umapi.model.UmTaskPost;

public interface UmTaskPostMapper extends BaseUmTaskPostMapper{
	
	/**
	 * 查询任务岗位描述信息
	 * @param userCodeList
	 * @return
	 */
	public List<UmTaskPost> qryUmTaskPostList();
	
}