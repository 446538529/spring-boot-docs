package com.picc.umapi.service;

import java.util.List;
import java.util.Set;

import com.picc.umapi.model.UmUserPermis;

public interface UmUserPermisService {
	int insert(UmUserPermis permis);

	int update(UmUserPermis permis);

	List<UmUserPermis> qryUmUserPermisList(String userCode);

	List<UmUserPermis> qryUmUserPermis(UmUserPermis permis);

	List<UmUserPermis> qryUmUserPermisInPermistype(String userCode, Set<String> permistype);

	List<UmUserPermis> qryUmUserPermisNotInPermistype(String userCode, Set<String> permistype);

	/**
	 * 根据userCode设置所有权限为无效
	 * 
	 * @param userCode
	 */
	void setInvalidByUserCode(String userCode);

	/**
	 * 根据usercode和permistype查询用户权限
	 * 
	 * @param usercode
	 * @param permistype
	 * @return
	 */
	List<UmUserPermis> qryUmUserPermisByUsercodePermistype(String usercode, String permistype);

	UmUserPermis qryUmUserPermisByUserCode(UmUserPermis permis);

	int updateByPermiscode(UmUserPermis permis);
}
