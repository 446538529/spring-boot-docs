package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmTokenMapper;
import com.picc.umapi.model.UmToken;

public interface UmTokenMapper extends BaseUmTokenMapper {

	/** 分页查询 **/
	public List<UmToken> queryUmTokenPage(UmToken umToken);

	/** 查询 数据,检查token是否有效 **/
	public UmToken queryUmToken(UmToken umToken);

	/** 删除 数据 **/
	public int delUmToken(UmToken umToken);

	/** 生成token **/
	public String createToken();

}
