package com.picc.umapi.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmModuledictMapper;
import com.picc.umapi.model.UmModuledict;

public interface UmModuledictMapper extends BaseUmModuledictMapper {

	public List<Map> makeRoutesMap(@Param("userCode") String userCode, @Param("sysCode") String sysCode, @Param("topId") String topId);

	/** 查询数据 **/
	public List<UmModuledict> queryUmModuledictList(UmModuledict umModuledict);

	/** 删除 数据 **/
	public int delUmModuledict(UmModuledict umModuledict);

}
