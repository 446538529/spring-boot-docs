package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmDataauthorityMapper;
import com.picc.umapi.model.UmDataauthority;

public interface UmDataauthorityMapper extends BaseUmDataauthorityMapper {

	/** 删除 数据 **/
	public int delUmDataAuthority(UmDataauthority umDataAuthority);

	/** 查询 数据 **/
	public List<UmDataauthority> queryDataAuthority(String usercode);

}
