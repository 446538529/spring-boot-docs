package com.picc.umapi.service.impl;

import java.util.List;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.mapper.UmRoleMapper;
import com.picc.umapi.model.UmRole;
import com.picc.umapi.service.UmRoleService;

/**
 * 公司信息业务实现
 * 
 * @author hzx
 *
 */
@Service
public class UmRoleServiceImpl implements UmRoleService {

	private static Logger log = LoggerFactory.getLogger(UmRoleServiceImpl.class);

	@Autowired
	private UmRoleMapper umRoleMapper;

	/** 分页查询 **/
	@Override
	public PageInfo<UmRole> queryUmRolePage(UmRole umRole, PagingReqParam pagingReqParam) {
		int pageIndex = pagingReqParam.getPageIndex();
		int pageSize = pagingReqParam.getPageSize();
		PageInfo<UmRole> pageUmRole = PageHelper.startPage(pageIndex, pageSize).doSelectPageInfo(() -> umRoleMapper.queryUmRoleList(umRole));
		return pageUmRole;
	}

	/** 列表查询 **/
	@Override
	public List<UmRole> queryUmRoleList(UmRole umRole) {
		return umRoleMapper.queryUmRoleList(umRole);
	}

	/** 删除 数据 **/
	@Override
	public int delUmRole(UmRole umRole) {
		return umRoleMapper.deleteByRole(umRole);
	}

	/** 创建RoleId ***/
	@Override
	public String makeRoleId() {
		return ROLE_START_STR + UUID.randomUUID().toString().replaceAll("-", "");
	}

	/** 合并RoleId(存在就更新,不存在就创建) ***/
	@Override
	public int megerRole(UmRole umRole) {
		UmRole roleOld = umRoleMapper.selectByPrimaryKey(umRole.getRoleid());
		if (null != roleOld) {
			roleOld.setRoleid(roleOld.getRoleid());
			return umRoleMapper.updateByPrimaryKeySelective(umRole);
		} else {
			return umRoleMapper.insertSelective(umRole);
		}
	}

	/** 查询 数据 ByName **/
	@Override
	public UmRole queryUmRoleByName(String rolename, String syscode) {
		UmRole umRoleReturn = new UmRole();
		UmRole umRole = new UmRole();
		umRole.setRolename(rolename);
		umRole.setSyscode(syscode);
		List<UmRole> listUmRole = umRoleMapper.queryUmRoleList(umRole);
		if (CollectionUtils.isNotEmpty(listUmRole)) {
			umRoleReturn = listUmRole.get(0);
		}
		return umRoleReturn;
	}
}
