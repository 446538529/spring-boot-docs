package com.picc.umapi.mapper;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmModuleauthMapper;
import com.picc.umapi.model.UmModuleauth;

public interface UmModuleauthMapper extends BaseUmModuleauthMapper {

	/** 删除 数据 **/
	public int delUmModuleauth(UmModuleauth umModuleauth);

	/** 根据角色id删除 数据 **/
	public int delByRoleid(@Param("roleid") String roleid, @Param("usercode") String usercode);

}
