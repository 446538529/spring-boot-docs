package com.picc.umapi.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.fastjson.JSON;
import com.picc.common.Pagination;
import com.picc.common.Resp;
import com.picc.common.servlet.Context;
import com.picc.umapi.model.UmCom;
import com.picc.umapi.model.UmDataauthority;
import com.picc.umapi.model.UmToken;
import com.picc.umapi.model.UmUser;
import com.picc.umapi.model.UmUserPermis;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.model.rowmodel.UploadUserRowModel;
import com.picc.umapi.model.rowmodel.validator.ExcelPropertyValidator;
import com.picc.umapi.req.LoginReqParam;
import com.picc.umapi.req.QueryUmUserParam;
import com.picc.umapi.req.RefreshUmUserRoleParam;
import com.picc.umapi.req.SaveUmUserParam;
import com.picc.umapi.service.UmComService;
import com.picc.umapi.service.UmDataauthorityService;
import com.picc.umapi.service.UmModuledictService;
import com.picc.umapi.service.UmTokenService;
import com.picc.umapi.service.UmUserPermisService;
import com.picc.umapi.service.UmUserRoleService;
import com.picc.umapi.service.UmUserService;
import com.picc.umapi.utils.FileUtils;
import com.picc.umapi.vo.UserLoginVo;
import com.picc.utils.ExcelUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@SuppressWarnings("rawtypes")
@Controller
@RequestMapping("/umapi")
@Api(tags = "用户管理")
public class UmUserControl {

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	private static final Logger log = LoggerFactory.getLogger(UmUserControl.class);

	@Autowired
	private UmModuledictService umModuledictService;

	@Autowired
	private UmDataauthorityService umDataauthorityService;

	@Autowired
	private UmTokenService umTokenService;

	@Autowired
	private UmUserService umUserService;

	@Autowired
	private UmUserRoleService umUserRoleService;

	@Autowired
	private UmUserPermisService userPermisService;

	@Autowired
	private UmComService umComService;

	@Autowired(required = false)
	private Context context;

	// 取得文件保存目录
	@Value("${umapi.uploadPath}")
	private String uploadpath;

	// 模板存放目录
	@Value("${umapi.template}")
	private String templatePath;

	@ResponseBody
	@PostMapping("/queryUmUserPage")
	@ApiOperation("查询用户清单")
	public Resp<Pagination<UmUser>> queryUmUserPage(QueryUmUserParam queryUmUserParam) {
		Pagination<UmUser> page = new Pagination<>(umUserService.queryUmUserPage(queryUmUserParam));
		return Resp.success(page);
	}

	@ResponseBody
	@PostMapping("/login")
	@ApiOperation("登录")
	public Resp<UserLoginVo> login(HttpServletRequest request, LoginReqParam req,
			@RequestHeader("X-SysCode") String sysCode) {
		System.out.println("sysCode = " + sysCode);
		if (StringUtils.isBlank(req.getUserCode())) {
			// 用户不能为空
			log.warn("员工编号为空");
			return Resp.fail("员工编号不能为空");
		}
		if (StringUtils.isBlank(req.getPwd())) {
			// 用户不存在
			log.warn("密码为空");
			return Resp.fail("密码不能为空");
		}
		UmUser umUser = umUserService.queryUmUser(req.getUserCode());
		if (umUser == null) {
			// 用户不存在
			log.warn("用户[{}]不存在", req.getUserCode());
			return Resp.fail("用户不存在");
		}
		if (StringUtils.equals(umUser.getValidstatus(), "0")) {
			// 用户不存在
			log.warn("用户[{}]无效", req.getUserCode());
			return Resp.fail("该用户已被禁用");
		}
		if (!StringUtils.equals(umUser.getPasswd(), req.getPwd())) {
			// 用户密码错误
			log.warn("用户[{}]密码错误", req.getUserCode());
			return Resp.fail("用户密码错误");
		}

		// 获取系统访问权限
		List<Map> routes = umModuledictService.makeRoutesMap(req.getUserCode(), sysCode, null);
		if (routes.size() == 0) {
			log.warn("用户 [{}] 无权访问系统", req.getUserCode());
			return Resp.fail("无权访问系统");
		}

		// 返回token
		String token = umTokenService.createToken();
		UserLoginVo loginVo = new UserLoginVo();
		loginVo.setToken(token);
		loginVo.setUserName(umUser.getUsername());
		loginVo.setUserCode(umUser.getUsercode());
		loginVo.setComcode(umUser.getComcode());
		loginVo.setRoutes(routes);

		// 将token保存到session
		request.getSession().setAttribute("X-Token", token);

		// Map<String, Object> map = new HashMap<String, Object>();
		// map.put("token", token);
		// map.put("userName", umUser.getUsername());
		// map.put("userCode", umUser.getUsercode());
		// map.put("comcode", umUser.getComcode());
		// map.put("routes", routes);
		// 返回用户信息
		if (context != null) {
			context.setCurrentUser(umUser);
		}
		// HttpSession session = request.getSession();
		// session.setMaxInactiveInterval(18000);
		// session.setAttribute("umUser", umUser);
		return Resp.success(loginVo);
	}

	/* 用于企业微信号登陆等登陆,获取各种信息 */
	@ResponseBody
	@PostMapping("/loginByToken")
	@ApiOperation("企业微信登录")
	public Resp<Object> loginByToken(@RequestHeader("X-SysCode") String sysCode,
			@RequestHeader("X-Token") String token) {
		if (StringUtils.isBlank(token)) {
			// 用户不存在
			return Resp.fail("无效请求");
		}
		UmToken umToken = new UmToken();
		// 检验token的有效性
		umToken = umTokenService.checkUmToken(token);
		if (umToken == null) {
			// 用户不存在
			return Resp.fail("您的登陆已失效,请重新登录!");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		// 返回token
		map.put("token", token);
		map.put("userName", umToken.getUsername());
		map.put("userCode", umToken.getUsercode());
		List<Map> routes = umModuledictService.makeRoutesMap(umToken.getUsercode(), sysCode, null);

		map.put("routes", routes);
		// 返回用户信息
		return Resp.success(map);
	}

	@ResponseBody
	@PostMapping("/saveUmUser")
	@ApiOperation("保存")
	// @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public Resp<Object> saveUmUser(SaveUmUserParam umUser) {
		if (StringUtils.isBlank(umUser.getUsercode())) {
			return Resp.fail("用户代码不能为空!");
		}
		if (StringUtils.isBlank(umUser.getPasswd())) {
			return Resp.fail("密码不能为空!");
		}
		if (StringUtils.isBlank(umUser.getUsername())) {
			return Resp.fail("人员姓名不能为空!");
		}
		if (StringUtils.isBlank(umUser.getMobileno())) {
			return Resp.fail("手机号码不能为空!");
		}
		if (StringUtils.isBlank(umUser.getComcode())) {
			return Resp.fail("机构代码不能为空!");
		}
		if (StringUtils.isBlank(umUser.getEmail())) {
			return Resp.fail("电子邮箱不能为空!");
		}
		UmCom queryUmComByCode = umComService.queryUmComByCode(umUser.getComcode());
		if (queryUmComByCode == null) {
			return Resp.fail("机构代码不存在!");
		}
		umUser.setDatalevel("3");
		if (!StringUtils.isBlank(umUser.getDatalevel())) {
			if (StringUtils.equals("0", umUser.getDatalevel())) {
				// 权限为0时,去前4位
				umUser.setAuthflag("comcode like ");
				umUser.setDataauth("'" + umUser.getComcode().substring(0, 4) + "%'");
			} else if (StringUtils.equals("1", umUser.getDatalevel())) {
				umUser.setAuthflag("comcode like ");
				umUser.setDataauth("'" + umUser.getComcode().substring(0, 6) + "%'");
			} else if (StringUtils.equals("2", umUser.getDatalevel())) {
				umUser.setAuthflag("comcode=");
				umUser.setDataauth("'" + umUser.getComcode() + "'");
			} else if (StringUtils.equals("3", umUser.getDatalevel())) {
				umUser.setAuthflag("usercode=");
				umUser.setDataauth("'" + umUser.getUsercode() + "'");
			}
		} else {
			return Resp.fail("权限等级不能为空!");
		}
		// megerUser为合并操作,如果用户存在,更新不为空字段,如果用户不存在,插入成为新用户
		if (umUserService.megerUser(umUser) >= 0) {
			return Resp.success();
		} else {
			return Resp.fail("保存失败!");
		}
	}

	/** 查询用户 **/
	@ResponseBody
	@PostMapping("/queryUmUser")
	@ApiOperation("查询用户")
	public Resp<Object> queryUmUser(@ApiParam("用户代码") String usercode) {
		UmUser qryUser = umUserService.queryUmUser(usercode);
		if (qryUser != null) {
			return Resp.success(qryUser);
		} else {
			return Resp.fail("查不到该用户信息!");
		}
	}

	/** 按数据重置用户角色与菜单权限 **/
	@ResponseBody
	@PostMapping("/refreshUmUserRole")
	@ApiOperation("按数据重置用户角色与菜单权限")
	public Resp<Object> refreshUmUserRole(RefreshUmUserRoleParam param, @RequestHeader("X-SysCode") String sysCode) {
		System.out.println("userCode=" + param.getUsercode());
		System.out.println("userRole=" + param.getUserRole());
		String[] roleids = param.getUserRole().split(",");
		if (StringUtils.isBlank(param.getUsercode())) {
			return Resp.fail("用户不能为空!");
		}
		// 清空用户所有角色及菜单
		umUserRoleService.resetUmUserrole(param.getUsercode(), sysCode);
		// 若权限为空,直接返回
		if (StringUtils.isBlank(param.getUserRole())) {
			return Resp.fail("改用户权限已清空!");
		}
		// 重新赋权限
		for (String roleid : roleids) {

			UmUserrole umUserrole = new UmUserrole();
			String userid = umUserService.queryUmUser(param.getUsercode()).getUserid();
			umUserrole.setUserid(userid);
			umUserrole.setUsercode(param.getUsercode());
			umUserrole.setRoleid(roleid);
			umUserrole.setValidstatus("1");
			umUserrole.setUrid(umUserRoleService.makeUrId());

			int saveNum = umUserRoleService.saveUmUserrole(umUserrole);
			// if(saveNum>0){
			// //给用户按角色赋予菜单权限
			// UmRoleModuleauth umRoleModuleauth = new UmRoleModuleauth();
			// umRoleModuleauth.setRoleid(umUserrole.getRoleid());
			// Pagination<UmRoleModuleauth> pagination = new
			// Pagination<UmRoleModuleauth>(1,1000);
			// pagination =
			// umApiRoleModuleauthService.queryUmRoleModuleauthPage(umRoleModuleauth,
			// pagination);
			// for(UmRoleModuleauth umrm:pagination.getEntities()){
			// UmModuleauth umModuleauth = new UmModuleauth();
			// umModuleauth.setUsercode(umUserrole.getUsercode());
			// umModuleauth.setMdid(umrm.getMdid());
			// umModuleauth.setMaid(umrm.getMaid());
			// umApiModuleauthService.saveUmModuleauth(umModuleauth);
			// }
			// }
		}
		return Resp.success();
	}

	// @ResponseBody
	// @RequestMapping("/saveUserDataAuth")
	// @ApiOperation("保存数据权限")
	// // @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	// public Resp<Object> saveUserDataAuth(@ApiParam("data")String data) {
	//
	// JSONObject jObject = JSON.parseObject(data);
	// List<UmDataauthority> dtList = JSON.toList(jObject.get("domains"),
	// UmDataAuthority.class);
	// /**** 删除旧的数据权限 **/
	// List<UmDataauthority> queryList =
	// umApiUserService.queryDataAuthority(jObject.getString("usercode"))
	// .getEntities();
	// if (queryList.size() != 0) {
	// UmDataauthority umDataAuthority = new UmDataauthority();
	// umDataAuthority.setUsercode(jObject.getString("usercode"));
	// umApiUserService.delUmDataAuthority(umDataAuthority);
	//
	// }
	// /**** 保存数据权限 ****/
	// for (UmDataauthority t : dtList) {
	// t.setUsername(jObject.getString("username"));
	// t.setUsercode(jObject.getString("usercode"));
	// /*
	// * if("in".equals(t.getDatarelation())){
	// * t.setDatavalue("("+t.getDatavalue()+")"); }
	// */
	// umApiUserService.saveUmDataAuthority(t);
	// }
	// System.out.println(data);
	//
	// returnWithJsonObject(response, res);
	// return;
	// }

	/*** 查询 数据 **/
	@ResponseBody
	@PostMapping("/queryUserDataAuth")
	@ApiOperation("查询")
	public Resp<Pagination<UmDataauthority>> queryUserDataAuth(@ApiParam("用户代码") String usercode) {
		if (StringUtils.isBlank(usercode)) {
			return Resp.fail();
		}
		Pagination<UmDataauthority> page = new Pagination<>(umDataauthorityService.queryDataAuthority(usercode, 1, 20));
		return Resp.success(page);
	}

	/** 修改密码 **/
	@ResponseBody
	@PostMapping("updateUser")
	@ApiOperation("修改密码")
	public Resp<String> updateUser(@ApiParam("原密码") String pwd, @ApiParam("新密码") String cpwd1,
			@ApiParam("确认密码") String cpwd2) {
		String usercode = "";
		if (context != null) {
			UmUser user = (UmUser) context.getCurrentUser();
			usercode = user.getUsercode();
		}
		UmUser qryUser = umUserService.queryUmUser(usercode);
		if (!StringUtils.equals(pwd, qryUser.getPasswd())) {
			return Resp.fail("原密码错误");
		}
		if (!StringUtils.equals(cpwd1, cpwd2)) {
			return Resp.fail("两次密码输入不匹配");
		}
		qryUser.setPasswd(cpwd1);
		umUserService.updateUmUser(qryUser);
		return Resp.success("修改成功");
	}

	// 保存人员数据权限
	/**
	 * @param userCode
	 * @param json
	 * @return
	 */
	@ResponseBody
	@PostMapping("saveUserPermis")
	@ApiOperation("保存人员数据权限")
	public Resp<String> saveUserPermis(@ApiParam("用户代码") String userCode, @ApiParam("权限类别以及对应的值") String json) {
		List<UmUserPermis> parseArray = JSON.parseArray(json, UmUserPermis.class);
		log.info("需要操作的权限{}", parseArray);
		// 判断是否有重复数据权限类别
		Set<String> set = new HashSet<>();
		StringBuffer sb = new StringBuffer();
		for (UmUserPermis user : parseArray) {
			boolean flag = set.add(user.getPermistype());
			if (!flag) {
				return Resp.fail("不能添加两个相同的权限类别");
			}
			if (StringUtils.isBlank(user.getPermistype())) {
				return Resp.fail("权限类别不能为空");
			}
			if (StringUtils.isBlank(user.getPermiscode())) {
				return Resp.fail("权限值不能为空");
			} else {
				// 个人
				if (StringUtils.equals("1", user.getPermistype())) {
					String[] split = user.getPermiscode().split(",|，");
					for (String permiscode : split) {
						// 根据permiscode查询人员信息
						UmUser umUser = umUserService.queryUmUser(permiscode);
						if (null == umUser) {
							sb.append(permiscode + ",");
						}
					}
				}
				// 支公司
				if (StringUtils.equals("2", user.getPermistype())) {

					String[] split = user.getPermiscode().split(",|，");
					for (String permiscode : split) {
						// 根据permiscode查询支公司
						UmCom umCom = umComService.queryUmComByCode(permiscode);
						if (null == umCom) {
							sb.append(permiscode + ",");
						}
					}
				}
			}
		}
		if (StringUtils.isNotBlank(sb.toString())) {
			return Resp.fail("数据权限值" + sb.toString().substring(0, sb.toString().length() - 1) + "不存在");
		}
		if (CollectionUtils.isNotEmpty(parseArray)) {
			// 设置用户所有权限无效
			userPermisService.setInvalidByUserCode(userCode);
			for (UmUserPermis newPermis : parseArray) {
				// 按权限类型查询信息
				List<UmUserPermis> qryUmUserPermis = userPermisService.qryUmUserPermisByUsercodePermistype(userCode,
						newPermis.getPermistype());
				// 保存新的权限信息
				if (qryUmUserPermis == null || qryUmUserPermis.size() == 0) {
					newPermis.setUsercode(userCode);
					newPermis.setValidstatus("1");
					newPermis.setId(umTokenService.createToken());
					newPermis.setInserttime(new Date());
					String[] split = newPermis.getPermiscode().split(",|，");
					for (String string : split) {
						newPermis.setPermiscode(string);
						userPermisService.insert(newPermis);
					}
				} else {
					for (UmUserPermis umUserPermis : qryUmUserPermis) {
						UmUserPermis qryUserPermis = new UmUserPermis();
						qryUserPermis.setPermistype(newPermis.getPermistype());
						qryUserPermis.setUsercode(umUserPermis.getUsercode());
						String[] split = newPermis.getPermiscode().split(",|，");
						for (String string : split) {
							qryUserPermis.setPermiscode(string);
							UmUserPermis qryUmUserPermisByUserCode = userPermisService
									.qryUmUserPermisByUserCode(qryUserPermis);
							// 不存在新增
							if (qryUmUserPermisByUserCode == null) {
								newPermis.setUsercode(userCode);
								newPermis.setValidstatus("1");
								newPermis.setId(umTokenService.createToken());
								newPermis.setInserttime(new Date());
								newPermis.setPermiscode(string);
								userPermisService.insert(newPermis);
								// 存在修改
							} else {
								newPermis.setOperatetime(new Date());
								newPermis.setValidstatus("1");
								newPermis.setPermiscode(string);
								newPermis.setUsercode(userCode);
								userPermisService.updateByPermiscode(newPermis);
							}
						}
					}

				}
			}
		} else {
			userPermisService.setInvalidByUserCode(userCode);
		}
		return Resp.success("保存成功");
	}

	// 按用户代码查询数据权限
	@ResponseBody
	@PostMapping("qryUserPermis")
	@ApiOperation("按用户代码查询数据权限")
	public Resp<List<UmUserPermis>> qryUserPermis(@ApiParam("用户代码") String userCode) {
		List<UmUserPermis> qryUmUserPermisList = userPermisService.qryUmUserPermisList(userCode);
		return Resp.success(qryUmUserPermisList);
	}

	// 根据代码或名称模糊查询
	@ResponseBody
	@PostMapping("qryUserByCodeOrName")
	@ApiOperation("根据代码或名称模糊查询")
	public Resp<List<UmUser>> qryUserByCodeOrName(@ApiParam("用户代码或用户名称") String value) {
		List<UmUser> qryUserByCodeOrName = umUserService.qryUserByCodeOrName(value);
		return Resp.success(qryUserByCodeOrName);
	}

	@ResponseBody
	@GetMapping("downLoadExample")
	@ApiOperation("模板下载")
	public void downLoadExample(HttpServletResponse response) {
		String filename = "模板";
		if (StringUtils.endsWith(templatePath, ".xls")) {
			filename += ".xls";
		} else {
			filename += ".xlsx";
		}
		try {
			filename = new String(filename.getBytes("utf-8"), "ISO-8859-1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		FileUtils.download(templatePath, filename, response);
	}

	@ResponseBody
	@PostMapping("uploadUser")
	@ApiOperation("上传")
	public Resp<String> uploadUser(MultipartFile file) throws FileNotFoundException, IOException {
		if (file == null || file.getSize() == 0) {
			log.warn("上传文件大小异常");
			return Resp.fail("请选择正确的EXCEL文件");
		}
		ExcelTypeEnum excelType = null;
		if (file.getOriginalFilename().endsWith(".xls")) {
			// excelType = ExcelTypeEnum.XLS;
			return Resp.fail("仅支持.xlsx文件上传");
		} else if (file.getOriginalFilename().endsWith(".xlsx")) {
			excelType = ExcelTypeEnum.XLSX;
		} else {
			log.warn("上传文件格式错误");
			return Resp.fail("请选择正确的EXCEL文件");
		}
		SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
		String filename = "saveUser" + sdf.format(new Date());
		// 生成保存文件
		String savefilename = filename + (excelType == ExcelTypeEnum.XLS ? ".xls" : ".xlsx");
		String datePath = new SimpleDateFormat("yyyy/MM/dd/").format(new Date());
		String savePath = uploadpath;
		if (!savePath.endsWith("/")) {
			savePath += "/";
		}
		savePath += datePath + savefilename;
		// 保存文件
		File storeFile = new File(savePath);
		if (!storeFile.getParentFile().exists()) {
			storeFile.getParentFile().mkdirs();
		}
		try (FileOutputStream storeOutputStream = new FileOutputStream(storeFile)) {
			IOUtils.copy(file.getInputStream(), storeOutputStream);
		}
		try (FileInputStream storeFileStream = new FileInputStream(new File(savePath))) {
			List<UploadUserRowModel> userRowList = ExcelUtils.readObject(storeFileStream, excelType,
					UploadUserRowModel.class);
			if (CollectionUtils.isEmpty(userRowList)) {
				return Resp.fail("文件为空");
			}
			// 基本格式校验
			List<String> errorList = new ArrayList<>();
			List<String> error = new ArrayList<>();
			boolean flag = true;
			for (int i = 0; i < userRowList.size(); i++) {
				flag = ExcelPropertyValidator.valid(userRowList.get(i), errorList);
				String errorMsg = "第" + (i + 1) + "行：" + StringUtils.join(errorList.iterator(), ",");
				error.add(errorMsg);
				errorList = new ArrayList<>();
			}
			if (flag) {
				String jsonString = JSON.toJSONString(userRowList);
				List<SaveUmUserParam> saveUserList = JSON.parseArray(jsonString, SaveUmUserParam.class);
				int i = 0;
				for (SaveUmUserParam umUser : saveUserList) {
					umUser.setDatalevel("3");
					if (!StringUtils.isBlank(umUser.getDatalevel())) {
						if (StringUtils.equals("0", umUser.getDatalevel())) {
							// 权限为0时,去前4位
							umUser.setAuthflag("comcode like ");
							umUser.setDataauth("'" + umUser.getComcode().substring(0, 4) + "%'");
						} else if (StringUtils.equals("1", umUser.getDatalevel())) {
							umUser.setAuthflag("comcode like ");
							umUser.setDataauth("'" + umUser.getComcode().substring(0, 6) + "%'");
						} else if (StringUtils.equals("2", umUser.getDatalevel())) {
							umUser.setAuthflag("comcode=");
							umUser.setDataauth("'" + umUser.getComcode() + "'");
						} else if (StringUtils.equals("3", umUser.getDatalevel())) {
							umUser.setAuthflag("usercode=");
							umUser.setDataauth("'" + umUser.getUsercode() + "'");
						}
					} else {
						return Resp.fail("权限等级不能为空!");
					}
					if (umUserService.megerUser(umUser) >= 0) {
						UmUser queryUmUser = umUserService.queryUmUser(umUser.getUsercode());
						UploadUserRowModel uploadUserRowModel = userRowList.get(i);
						i++;
						String roleid = uploadUserRowModel.getRoleid();
						if (StringUtils.isNotBlank(roleid)) {
							String[] split = roleid.split(",|，");
							for (String string : split) {
								UmUserrole umUserrole = new UmUserrole();
								umUserrole.setRoleid(string);
								umUserrole.setUserid(queryUmUser.getUserid());
								umUserrole.setUsercode(queryUmUser.getUsercode());
								umUserrole.setValidstatus("1");
								UmUserrole queryUmUserrole = umUserRoleService.queryUmUserrole(umUserrole);
								umUserrole.setUrid(umTokenService.createToken());
								if (queryUmUserrole == null)
									umUserRoleService.saveUmUserrole(umUserrole);
							}
						}
					} else {
						return Resp.fail("保存失败!");
					}
				}
			} else {
				return Resp.fail(error.toString());
			}
		}
		return Resp.success("上传成功");
	}

	// 获取最新路由
	@ResponseBody
	@PostMapping("/qryNewRotes")
	@ApiOperation("获取最新路由")
	public Resp<List<Map>> qryNewRotes(@ApiParam("员工代码") String userCode, @RequestHeader("X-SysCode") String sysCode) {
		// 获取系统访问权限
		List<Map> routes = umModuledictService.makeRoutesMap(userCode, sysCode, null);
		return Resp.success(routes);
	}

	@ResponseBody
	@PostMapping("checkUserPermis")
	@ApiOperation("展示数据管理-检查用户权限")
	public Resp<String> checkUserPermis(@ApiParam("员工代码") String userCode) {
		UmUserPermis umUserPermis = new UmUserPermis();
		umUserPermis.setUsercode(userCode);
		umUserPermis.setPermistype("4");
		List<UmUserPermis> qryUmUserPermis = userPermisService.qryUmUserPermis(umUserPermis);
		if (qryUmUserPermis == null || qryUmUserPermis.size() == 0) {
			return Resp.success("false");
		}
		boolean flag = false;
		for (UmUserPermis umUserPermis2 : qryUmUserPermis) {
			if(umUserPermis2.getPermiscode().equals("1"))
				flag = true;
		}
		if (!flag) {
			return Resp.success("false");
		}
		return Resp.success("true");
	}
}
