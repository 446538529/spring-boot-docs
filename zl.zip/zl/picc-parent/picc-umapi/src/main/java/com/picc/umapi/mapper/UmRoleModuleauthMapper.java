package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmRoleModuleauthMapper;
import com.picc.umapi.model.UmRoleModuleauth;

public interface UmRoleModuleauthMapper extends BaseUmRoleModuleauthMapper {

	/** 查询列表 **/
	public List<UmRoleModuleauth> queryUmRoleModuleauthList(UmRoleModuleauth umRoleModuleauth);

	/** 删除 数据 **/
	public int delUmModuledict(UmRoleModuleauth umRoleModuleauth);
	
	/**
	 * 根据角色id查询是否拥有财务分析数据展示权限
	 * @param roleid 角色id
	 * @return
	 */
	public UmRoleModuleauth haveDataManagementAuthority(String roleid);

}
