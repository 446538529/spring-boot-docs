package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmRoleMapper;
import com.picc.umapi.model.UmRole;

public interface UmRoleMapper extends BaseUmRoleMapper {

	/** 查询列表数据 **/
	public List<UmRole> queryUmRoleList(UmRole umRole);

	/** 删除 数据 **/
	public int deleteByRole(UmRole umRole);

}
