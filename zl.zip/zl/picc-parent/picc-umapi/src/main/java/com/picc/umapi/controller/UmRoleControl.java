package com.picc.umapi.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.picc.common.Pagination;
import com.picc.common.PagingReqParam;
import com.picc.common.Resp;
import com.picc.umapi.model.UmModuledict;
import com.picc.umapi.model.UmRole;
import com.picc.umapi.model.UmRoleModuleauth;
import com.picc.umapi.model.UmTaskPost;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.QueryUmUserRoleParam;
import com.picc.umapi.req.UpdateUmTaskPostParam;
import com.picc.umapi.service.UmModuledictService;
import com.picc.umapi.service.UmRoleModuleauthService;
import com.picc.umapi.service.UmRoleService;
import com.picc.umapi.service.UmTaskPostService;
import com.picc.umapi.service.UmUserRoleService;
import com.picc.umapi.service.UmUserService;
import com.picc.umapi.utils.CodeUtil;
import com.picc.umapi.vo.UmUserRoleVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/umapi")
@Api(tags = "用户角色")
public class UmRoleControl {

	@Autowired
	private UmRoleService umApiRoleService;

	@Autowired
	private UmModuledictService umApiModuledictService;

	@Autowired
	private UmRoleModuleauthService umApiRoleModuleauthService;

	@Autowired
	private UmUserRoleService umApiUserroleService;

	@Autowired
	private UmUserService umApiUserService;

	@Autowired
	private UmTaskPostService umTaskPostService;

	@Autowired
	private UmUserService umUserService;

	@PostMapping("/queryUmModuleTree")
	@ResponseBody
	@ApiOperation("查询菜单树")
	public Resp<List<Map<String, Object>>> queryUmModuleTree(@RequestHeader("X-SysCode") String sysCode) {

		List<Map<String, Object>> tree = umApiModuledictService.queryUmModuleTree(sysCode, null);

		return Resp.success(tree);

	}

	@PostMapping("/queryAllUmRolePage")
	@ResponseBody
	@ApiOperation("查询角色所有菜单页")
	public Resp<List<UmRoleModuleauth>> queryAllUmRolePage(@RequestHeader("X-SysCode") String sysCode,
			UmRoleModuleauth umRoleModuleauth) {
		List<UmRoleModuleauth> listUmRoleModuleauth = umApiRoleModuleauthService.queryAllUmRolePage(umRoleModuleauth);
		return Resp.success(listUmRoleModuleauth);
	}

	@PostMapping("/saveRoleAndModule")
	@ResponseBody
	@ApiOperation("新增角色")
	public Resp<String> saveRoleAndModule(@RequestHeader("X-SysCode") String sysCode, @ApiParam("树节点") String treeNode,
			UmRole umRole) {
		String[] mdids = treeNode.split(",");
		umRole.setSyscode(sysCode);
		// 当Roleid为空时,数据为新增
		if (CodeUtil.nullOrBlank(umRole.getRoleid())) {
			// 查询该系统是否有重复角色,存在不予新增
			UmRole umRoleRe = umApiRoleService.queryUmRoleByName(umRole.getRolename(), sysCode);
			if (StringUtils.isNotBlank(umRoleRe.getRolename())) {
				return Resp.fail("该角色名称已存在,请修改重试");
			}
			// 如果不存在,新建roleid
			umRole.setRoleid(umApiRoleService.makeRoleId());
		}
		// 保存角色修改
		if (umApiRoleService.megerRole(umRole) < 0) {
			return Resp.fail("保存失败!");
		}
		;
		// 获取权限菜单上级
		Set<String> mdidSet = new HashSet<String>();
		for (String mdid : mdids) {
			mdidSet.add(mdid);
			UmModuledict umModuledict = new UmModuledict();
			umModuledict.setMdid(mdid);
			umModuledict = umApiModuledictService.queryUmModuledict(umModuledict);
			if (umModuledict != null) {
				if (!"root".equals(umModuledict.getTopid())) {
					mdidSet.add(umModuledict.getTopid());
				}
			}
		}
		// 删除原角色关联菜单
		UmRoleModuleauth umRoleModuleauth = new UmRoleModuleauth();
		umRoleModuleauth.setRoleid(umRole.getRoleid());
		umApiRoleModuleauthService.delUmRoleModuleauth(umRoleModuleauth);
		// 添加角色关联菜单
		for (String mdid : mdidSet) {
			UmRoleModuleauth newUmRM = new UmRoleModuleauth();
			newUmRM.setMaid(umApiRoleModuleauthService.makeMaId());
			newUmRM.setMdid(mdid);
			newUmRM.setRoleid(umRole.getRoleid());
			umApiRoleModuleauthService.saveUmRoleModuleauth(newUmRM);
		}
		return Resp.success();
	}

	@PostMapping("/queryUmRolePage")
	@ResponseBody
	@ApiOperation("查询角色页")
	public Resp<Pagination<UmRole>> queryUmRolePage(@RequestHeader("X-SysCode") String sysCode,
			PagingReqParam pagingReqParam, UmRole umRole) {
		umRole.setSyscode(sysCode);
		PageInfo<UmRole> pageUmRole = umApiRoleService.queryUmRolePage(umRole, pagingReqParam);
		return Resp.success(new Pagination<>(pageUmRole));
	}

	@PostMapping("/queryUmRoleModule")
	@ResponseBody
	@ApiOperation("查询模块ID")
	public Resp<List<String>> queryUmRoleModule(@RequestHeader("X-SysCode") String sysCode,
			UmRoleModuleauth umRoleModuleauth) {

		List<String> list = umApiRoleModuleauthService.queryUmRoleModuleauthMdid(umRoleModuleauth);

		return Resp.success(list);
	}

	@PostMapping("/queryUmRoleUser")
	@ResponseBody
	@ApiOperation("查询指定角色所含用户列表,或者指定用户所有角色")
	public Resp<List<UmUserRoleVO>> queryUmRoleUser(@RequestHeader("X-SysCode") String sysCode,
			QueryUmUserRoleParam queryUmUserRoleParam) {
		PagingReqParam pagingReqParam = new PagingReqParam();
		pagingReqParam.setPageSize(1000);
		queryUmUserRoleParam.setSyscode(sysCode);
		PageInfo<UmUserRoleVO> pageUmUserrole = umApiUserroleService.queryUmUserrolePage(queryUmUserRoleParam, sysCode,
				pagingReqParam);
		List<UmUserRoleVO> listUmUserrole = pageUmUserrole.getList();
		return Resp.success(listUmUserrole);
	}

	@PostMapping("/delUmRoleUser")
	@ResponseBody
	@ApiOperation("删除指定角色所含用户列表")
	public Resp<String> delUmRoleUser(@RequestHeader("X-SysCode") String sysCode, UmUserrole umUserrole) {
		if (StringUtils.isBlank(umUserrole.getUrid())) {
			return Resp.fail("请求错误");
		}
		// 删除角色相应菜单
		umApiUserroleService.cleanUmUserrole(umUserrole);
		int delNum = umApiUserroleService.delUmUserrole(umUserrole);
		if (delNum > 0) {
			return Resp.success();
		} else {
			return Resp.fail("删除失败");
		}
	}

	@PostMapping("/addUmRoleUser")
	@ResponseBody
	@ApiOperation("添加指定角色给用户")
	public Resp<String> addUmRoleUser(@RequestHeader("X-SysCode") String sysCode,
			QueryUmUserRoleParam queryUmUserRoleParam) {
		PageInfo<UmUserRoleVO> pageUmUserrole = umApiUserroleService.queryUmUserrolePage(queryUmUserRoleParam, sysCode,
				new PagingReqParam());
		if (pageUmUserrole.getTotal() > 0) {
			return Resp.fail("该用户已拥有该角色权限!");
		}
		String userid;
		try {
			userid = umApiUserService.queryUmUser(queryUmUserRoleParam.getUsercode()).getUserid();
		} catch (Exception e) {
			return Resp.fail("查无该用户!");
		}
		// 当输入用户代码有误，数据库中没有此id时，此处会报空指针
		UmUserrole umUserrole = new UmUserrole();
		umUserrole.setValidstatus("1");
		umUserrole.setUsercode(queryUmUserRoleParam.getUsercode());
		umUserrole.setRoleid(queryUmUserRoleParam.getRoleid());
		umUserrole.setUserid(userid);
		umUserrole.setUrid(umApiUserroleService.makeUrId());

		int saveNum = umApiUserroleService.saveUmUserrole(umUserrole);
		if (saveNum > 0) {
			// 给用户按角色赋予菜单权限
			UmRoleModuleauth umRoleModuleauth = new UmRoleModuleauth();
			umRoleModuleauth.setRoleid(umUserrole.getRoleid());
			// PageInfo<UmRoleModuleauth> pageUmRoleModuleauth =
			// umApiRoleModuleauthService.queryUmRoleModuleauthPage(umRoleModuleauth);
			/** 不再操作人员菜单映射表,由角色决定菜单,人员菜单需要独立配置 **/
			// for(UmRoleModuleauth umrm:pagination.getEntities()){
			// UmModuleauth umModuleauth = new UmModuleauth();
			// umModuleauth.setUsercode(umUserrole.getUsercode());
			// umModuleauth.setMdid(umrm.getMdid());
			// umModuleauth.setMaid(umrm.getMaid());
			// umApiModuleauthService.saveUmModuleauth(umModuleauth);
			// }
			return Resp.success();
		} else {
			return Resp.fail("保存失败");
		}
	}

	@PostMapping("/qryUmTaskPostList")
	@ResponseBody
	@ApiOperation("重复支付核查人员配置-任务岗位职责描述信息")
	public Resp<List<UmTaskPost>> qryUmTaskPostList() {
		List<UmTaskPost> umLinkList = umTaskPostService.qryUmTaskPostList();
		return Resp.success(umLinkList);
	}

	@PostMapping("/qryTaskUserList")
	@ResponseBody
	@ApiOperation("重复支付核查人员配置-人员配置")
	public Resp<List<QueryTaskUserListReq>> qryTaskUserList(@ApiParam("id") String id) {
		List<QueryTaskUserListReq> TaskUserList = umTaskPostService.qryTaskUserList(id);
		// 人员配置列表为空，返回空数组
		if (TaskUserList == null) {
			return Resp.success(new ArrayList<QueryTaskUserListReq>());
		}
		return Resp.success(TaskUserList);
	}

	@PostMapping("/qryUmTaskUserList")
	@ResponseBody
	@ApiOperation("重复支付核查人员配置-人员配置-人员添加列表")
	public Resp<List<QueryTaskUserListReq>> qryUmTaskUserList(@ApiParam("关键字") String keyWord) {
		List<QueryTaskUserListReq> umUserList = umUserService.qryUmTaskUserList(keyWord);
		return Resp.success(umUserList);
	}

	@PostMapping("/addUmTaskPost")
	@ResponseBody
	@ApiOperation("重复支付核查人员配置-人员配置-新增")
	public Resp<String> addUmTaskPost(UpdateUmTaskPostParam updateParam) {
		int update = umTaskPostService.addUmTaskPost(updateParam);
		if (update == 0) {
			return Resp.fail("更新失败");
		}else if (update == 2) {
			return Resp.fail("用户已经添加");
		}else{
			return Resp.success("更新成功");
		}
	}

	@PostMapping("/delUmTaskPost")
	@ResponseBody
	@ApiOperation("重复支付核查人员配置-人员配置-删除")
	public Resp<String> delUmTaskPost(UpdateUmTaskPostParam updateParam) {
		int update = umTaskPostService.delUmTaskPost(updateParam);
		if (update != 0)
			return Resp.success("更新成功");
		return Resp.fail("更新失败");
	}

}
