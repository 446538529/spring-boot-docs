package com.picc.umapi.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.model.UmUser;
import com.picc.umapi.req.QueryTaskUserListReq;
import com.picc.umapi.req.QueryUmUserParam;
import com.picc.umapi.req.SaveUmUserParam;

public interface UmUserService {

	/** 分页查询 **/
	public PageInfo<UmUser> queryUmUserPage(QueryUmUserParam queryUmUserParam);

	/** 查询 数据 **/
	public UmUser queryUmUser(String usercode);

	/** 保存 数据 **/
	public int saveUmUser(SaveUmUserParam umUser);

	/** 删除 数据 **/
	public int delUmUser(UmUser umUser);

	/** 更新 数据 **/
	public int updateUmUser(SaveUmUserParam umUser);

	/** 合并数据 **/
	public int megerUser(SaveUmUserParam umUser);

	/** 修改密码 **/
	public int updateUmUser(UmUser umUser);

	/** 根据代码或名称模糊查询 **/
	public List<UmUser> qryUserByCodeOrName(String value);

	/** 根据代码或名称模糊查询,取前10条 **/
	public List<QueryTaskUserListReq> qryUmTaskUserList(String keyWord);

}
