package com.picc.umapi.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.mapper.UmModuledictMapper;
import com.picc.umapi.model.UmModuledict;
import com.picc.umapi.service.UmModuledictService;

@Service
public class UmModuledictServiceImpl implements UmModuledictService {

	private static Logger log = LoggerFactory.getLogger(UmModuledictServiceImpl.class);

	@Autowired
	private UmModuledictMapper umModuledictMapper;

	@Override
	public List<Map> makeRoutesMap(String userCode, String sysCode, String topId) {
		// 如果上级路由为空,默认root,root为最顶层目录,且必须存在
		if (topId == null) {
			topId = "root";
		}
		List<Map> makeRoutesMap = umModuledictMapper.makeRoutesMap(userCode, sysCode, topId);
		List<Map> routeList = new ArrayList<Map>();
		// 添加children路由
		if (makeRoutesMap.size() > 0) {
			for (Map route : makeRoutesMap) {
				Set<String> keySet = route.keySet();
				Map newMap = new HashMap<>();
				for (String key : keySet) {
					String newKey = key.toLowerCase();
					String value = (String)route.get(key);
					newMap.put(newKey, value);
				}
				String top = (String) newMap.get("mdid");
				List<Map> children = makeRoutesMap(userCode, sysCode, top);
				// 如果子路由为空时,不添加
				if (children.size() > 0) {
					newMap.put("children", children);
				}
				// 删除mdid,不返回前台
				newMap.remove("mdid");
				routeList.add(newMap);
			}
		}
		return routeList;
	}

	/** 分页查询 **/
	@Override
	public PageInfo<UmModuledict> queryUmModuledictPage(UmModuledict umModuledict, PagingReqParam pagingReqParam) {

		int pageIndex = pagingReqParam.getPageIndex();
		int pageSize = pagingReqParam.getPageSize();

		PageInfo<UmModuledict> pageUmModuledict = PageHelper.startPage(pageIndex, pageSize).doSelectPageInfo(() -> umModuledictMapper.queryUmModuledictList(umModuledict));
		return pageUmModuledict;
	}

	/** 查询 数据 **/
	@Override
	public UmModuledict queryUmModuledict(UmModuledict umModuledict) {
		UmModuledict umModuledicteReturn = null;
		List<UmModuledict> listUmModuledict = umModuledictMapper.queryUmModuledictList(umModuledict);
		if (CollectionUtils.isNotEmpty(listUmModuledict)) {
			umModuledicteReturn = listUmModuledict.get(0);
		}
		return umModuledicteReturn;
	}

	/** 保存 数据 **/
	@Override
	public int saveUmModuledict(UmModuledict umModuledict) {
		return umModuledictMapper.insertSelective(umModuledict);
	}

	/** 删除 数据 **/
	@Override
	public int delUmModuledict(UmModuledict umModuledict) {

		return umModuledictMapper.delUmModuledict(umModuledict);
	}

	/** 更新 数据 **/
	@Override
	public int updateUmModuledict(UmModuledict umModuledict) {
		return umModuledictMapper.updateByPrimaryKeySelective(umModuledict);
	}

	/** 查询菜单目录 **/
	@Override
	public List<Map<String, Object>> queryUmModuleTree(String sysCode, String topId) {
		// 如果上级树为空,默认root,root为最顶层目录,且必须存在
		if (topId == null) {
			topId = ROUTE_TOP;
		}
		UmModuledict umModuledict = new UmModuledict();
		umModuledict.setValidstatus("1"); // 有效状态
		umModuledict.setSyscode(sysCode);
		umModuledict.setTopid(topId);
		List<UmModuledict> queryUmModuledictList = umModuledictMapper.queryUmModuledictList(umModuledict);

		List<Map<String, Object>> treeList = new ArrayList<>();

		// 添加children ModuleTree
		if (CollectionUtils.isNotEmpty(queryUmModuledictList)) {
			for (UmModuledict umModuledictOb : queryUmModuledictList) {
				HashMap<String, Object> map = new HashMap<>();
				String top = umModuledictOb.getMdid();
				String label = umModuledictOb.getName();
				map.put("mdid", top);
				map.put("label", label);
				List<Map<String, Object>> children = queryUmModuleTree(sysCode, top);
				// 如果子路由为空时,不添加
				if (children.size() > 0) {
					map.put("children", children);
				}
				// 添加进list
				treeList.add(map);
			}
		}
		return treeList;
	}

}
