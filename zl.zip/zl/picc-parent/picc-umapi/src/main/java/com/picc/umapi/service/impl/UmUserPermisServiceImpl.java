package com.picc.umapi.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.picc.umapi.mapper.UmUserPermisMapper;
import com.picc.umapi.model.UmUserPermis;
import com.picc.umapi.service.UmUserPermisService;

@Service("userPermisService")
public class UmUserPermisServiceImpl implements UmUserPermisService {

	@Autowired
	private UmUserPermisMapper mapper;

	@Override
	public int insert(UmUserPermis permis) {
		return mapper.insertSelective(permis);
	}

	@Override
	public int update(UmUserPermis permis) {
		return mapper.updateByPrimaryKeySelective(permis);
	}

	@Override
	public List<UmUserPermis> qryUmUserPermisList(String userCode) {
		List<UmUserPermis> qryUmUserPermisList = mapper.qryUmUserPermisList(userCode);
		Map<String, Set<String>> map = new HashMap<>();
		for (UmUserPermis permis : qryUmUserPermisList) {
			Set<String> codes = map.get(permis.getPermistype());
			if (codes == null) {
				codes = new HashSet<>();
				map.put(permis.getPermistype(), codes);
			}
			codes.add(permis.getPermiscode());
		}
		List<UmUserPermis> list = new ArrayList<>();
		for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
			UmUserPermis umUserPermis = new UmUserPermis();
			umUserPermis.setUsercode(userCode);
			umUserPermis.setPermistype(entry.getKey());
			umUserPermis.setPermiscode(StringUtils.join(entry.getValue(),","));
			list.add(umUserPermis);
		}
		return list;
	}

	@Override
	public List<UmUserPermis> qryUmUserPermis(UmUserPermis permis) {
		return mapper.qryUmUserPermis(permis);
	}

	@Override
	public List<UmUserPermis> qryUmUserPermisInPermistype(String userCode, Set<String> permistype) {
		return mapper.qryUmUserPermisInPermistype(userCode, permistype);
	}

	@Override
	public List<UmUserPermis> qryUmUserPermisNotInPermistype(String userCode, Set<String> permistype) {
		return mapper.qryUmUserPermisNotInPermistype(userCode, permistype);
	}

	@Override
	public void setInvalidByUserCode(String userCode) {
		mapper.setInvalidByUserCode(userCode);
	}

	@Override
	public List<UmUserPermis> qryUmUserPermisByUsercodePermistype(String usercode, String permistype) {
		return mapper.qryUmUserPermisByUsercodePermistype(usercode, permistype);
	}

	@Override
	public UmUserPermis qryUmUserPermisByUserCode(UmUserPermis permis) {
		return mapper.qryUmUserPermisByUserCode(permis);
	}

	@Override
	public int updateByPermiscode(UmUserPermis permis) {
		return mapper.updateByPermiscode(permis);
	}

}
