package com.picc.umapi.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.umapi.mapper.UmDataauthorityMapper;
import com.picc.umapi.model.UmDataauthority;
import com.picc.umapi.service.UmDataauthorityService;
import com.picc.umapi.service.UmTokenService;

@Service("umDataauthorityService")
public class UmDataauthorityServiceImpl implements UmDataauthorityService {

	private static Logger log = LoggerFactory.getLogger(ComServiceImpl.class);

	@Autowired
	private UmDataauthorityMapper umDataauthorityMapper;
	@Autowired
	private UmTokenService umTokenService;

	@Override
	public int saveUmDataAuthority(UmDataauthority umDataAuthority) {
		if (umDataAuthority == null) {
			return -1;
		}
		umDataAuthority.setId("DT" + umTokenService.createToken());
		return umDataauthorityMapper.insertSelective(umDataAuthority);
	}

	@Override
	public int delUmDataAuthority(UmDataauthority umDataAuthority) {
		return umDataauthorityMapper.delUmDataAuthority(umDataAuthority);
	}

	@Override
	public PageInfo<UmDataauthority> queryDataAuthority(String usercode, Integer pageIndex, Integer pageSize) {
		PageInfo<UmDataauthority> pageInfo = PageHelper.startPage(pageIndex, pageSize).doSelectPageInfo(() -> umDataauthorityMapper.queryDataAuthority(usercode));
		return pageInfo;
	}

}
