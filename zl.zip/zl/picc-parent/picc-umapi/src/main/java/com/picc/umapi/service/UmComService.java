package com.picc.umapi.service;

import java.util.List;

import com.picc.umapi.model.UmCom;

/**
 * 公司信息业务接口
 * 
 * @author hzx
 *
 */
public interface UmComService {

	/**
	 * 批量查询支公司信息
	 */
	public List<UmCom> queryUmComPage();
	
	//通过机构代码查询支公司名称
	UmCom queryUmComByCode(String comcode);
	
}
