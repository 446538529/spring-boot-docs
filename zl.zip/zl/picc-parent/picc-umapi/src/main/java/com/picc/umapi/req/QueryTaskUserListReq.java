package com.picc.umapi.req;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("重复支付核查人员")
public class QueryTaskUserListReq implements ReqParam {

	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty("任务用户id")
	private String id;
	
	@ApiModelProperty("人员姓名")
	private String userName;
	
	@ApiModelProperty("用户编码")
	private String userCode;
	
	@ApiModelProperty("机构代码")
	private String comCode;
	
	@ApiModelProperty("岗位名称")
	private String postName;
	
	@ApiModelProperty("公司名称")
	private String comName;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getComCode() {
		return comCode;
	}

	public void setComCode(String comCode) {
		this.comCode = comCode;
	}

	public String getPostName() {
		return postName;
	}

	public void setPostName(String postName) {
		this.postName = postName;
	}

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}
	
}
