package com.picc.umapi.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.picc.common.Resp;
import com.picc.umapi.model.UmCom;
import com.picc.umapi.service.UmComService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/umapi")
@Api(tags = "组织机构")
public class UmComControl {

	@Autowired
	private UmComService umComService;

	private static Logger log = LoggerFactory.getLogger(UmComControl.class);

	@ResponseBody
	@PostMapping("/queryUmComPage")
	@ApiOperation("批量查询支公司")
	public Resp<List<UmCom>> queryUmComPage() {
		List<UmCom> queryUmComPage = umComService.queryUmComPage();
		Resp<List<UmCom>> umComResp = Resp.response(Resp.SUCCESS, Resp.SUCCESS_MESSAGE, queryUmComPage);
		return umComResp;

	}
	
	
	@ResponseBody
	@PostMapping("/queryUmComByCode")
	@ApiOperation("通过机构代码查询支公司名称")
	public Resp<UmCom> queryUmComByCode(@ApiParam("机构代码") String comcode) {
		UmCom queryUmCom = umComService.queryUmComByCode(comcode);
		return Resp.success(queryUmCom);

	}

}
