package com.picc.umapi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.picc.umapi.mapper.UmRoleModuleauthMapper;
import com.picc.umapi.model.UmRoleModuleauth;
import com.picc.umapi.service.UmRoleModuleauthService;

@Service
public class UmRoleModuleauthServiceImpl implements UmRoleModuleauthService {

	private static Logger log = LoggerFactory.getLogger(UmRoleModuleauthServiceImpl.class);

	@Autowired
	private UmRoleModuleauthMapper umRoleModuleauthMapper;

	/** 分页查询 **/
	@Override
	public List<UmRoleModuleauth> queryAllUmRolePage(UmRoleModuleauth umRoleModuleauth) {
		return umRoleModuleauthMapper.queryUmRoleModuleauthList(umRoleModuleauth);
	}

	/** 查询mdid列表 **/
	@Override
	public List<String> queryUmRoleModuleauthMdid(UmRoleModuleauth umRoleModuleauth) {
		List<UmRoleModuleauth> listUmRoleModuleauth = umRoleModuleauthMapper.queryUmRoleModuleauthList(umRoleModuleauth);
		List<String> list = new ArrayList<String>();
		if (CollectionUtils.isNotEmpty(listUmRoleModuleauth)) {
			for (UmRoleModuleauth umRoleModuleauthOb : listUmRoleModuleauth) {
				list.add(umRoleModuleauthOb.getMdid());
			}
		}
		return list;
	}

	/** 保存 数据 **/
	@Override
	public int saveUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth) {
		log.info("新增角色模块数据");
		return umRoleModuleauthMapper.insertSelective(umRoleModuleauth);
	}

	/** 删除 数据 **/
	@Override
	public int delUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth) {
		log.info("删除角色模块数据", umRoleModuleauth.getMaid());
		return umRoleModuleauthMapper.delUmModuledict(umRoleModuleauth);
	}

	/** 更新 数据 **/
	@Override
	public int updateUmRoleModuleauth(UmRoleModuleauth umRoleModuleauth) {
		log.info("更新角色模块数据{}", umRoleModuleauth.getMaid());
		return umRoleModuleauthMapper.updateByPrimaryKeySelective(umRoleModuleauth);
	}

	/** 创建RoleId ***/
	@Override
	public String makeMaId() {
		return ROLE_START_STR + UUID.randomUUID().toString().replaceAll("-", "");
	}

}
