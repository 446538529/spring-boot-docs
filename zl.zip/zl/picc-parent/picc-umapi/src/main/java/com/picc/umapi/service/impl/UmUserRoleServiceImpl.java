package com.picc.umapi.service.impl;

import java.util.HashMap;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.mapper.UmModuleauthMapper;
import com.picc.umapi.mapper.UmRoleMapper;
import com.picc.umapi.mapper.UmUserRoleMapper;
import com.picc.umapi.model.UmModuleauth;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.req.QueryUmUserRoleParam;
import com.picc.umapi.service.UmUserRoleService;
import com.picc.umapi.utils.CodeUtil;
import com.picc.umapi.vo.UmUserRoleVO;

/**
 * 公司信息业务实现
 * 
 * @author hzx
 *
 */
@Service
public class UmUserRoleServiceImpl implements UmUserRoleService {

	private static Logger log = LoggerFactory.getLogger(UmUserRoleServiceImpl.class);

	@Autowired
	private UmUserRoleMapper umUserRoleMapper;
	@Autowired
	private UmRoleMapper umRoleMapper;
	@Autowired
	private UmModuleauthMapper umModuleauthMapper;

	/** 分页查询 **/
	@Override
	public PageInfo<UmUserRoleVO> queryUmUserrolePage(QueryUmUserRoleParam queryUmUserRoleParam, String syscode, PagingReqParam pagingReqParam) {
		int pageIndex = pagingReqParam.getPageIndex();
		int pageSize = pagingReqParam.getPageSize();
		PageInfo<UmUserRoleVO> pageUmRole = PageHelper.startPage(pageIndex, pageSize).doSelectPageInfo(() -> umUserRoleMapper.queryUmRoleList(queryUmUserRoleParam));
		return pageUmRole;
	}

	/** 查询 数据 **/
	@Override
	public UmUserrole queryUmUserrole(UmUserrole umUserrole) {
		return umUserRoleMapper.queryUmUserrole(umUserrole);
	}

	/** 保存 数据 **/
	@Override
	public int saveUmUserrole(UmUserrole umUserrole) {
		return umUserRoleMapper.insertSelective(umUserrole);
	}

	/** 删除 数据 **/
	@Override
	public int delUmUserrole(UmUserrole umUserrole) {
		return umUserRoleMapper.delUmUserrole(umUserrole);
	}

	/** 更新 数据 **/
	@Override
	public int updateUmUserrole(UmUserrole umUserrole) {
		return umUserRoleMapper.updateByPrimaryKeySelective(umUserrole);
	}

	/** 删除用户角色关联菜单 **/
	@Override
	public int cleanUmUserrole(UmUserrole umUserrole) {
		if (!CodeUtil.nullOrBlank(umUserrole.getUrid())) {
			umUserrole = queryUmUserrole(umUserrole);
			int delNum = umModuleauthMapper.delByRoleid(umUserrole.getRoleid(), umUserrole.getUsercode());
			return delNum;
		} else {
			return 0;
		}
	}

	/** 清空指定用户所有角色及关联菜单 **/
	@Override
	public int resetUmUserrole(String usercode, String syscode) {
		if (!CodeUtil.nullOrBlank(usercode)) {
			HashMap<String, String> param = new HashMap<>();
			param.put("usercode", usercode);
			param.put("syscode", syscode);
			UmUserrole umUserrole = new UmUserrole();
			umUserrole.setUsercode(usercode);
			int delNum = umUserRoleMapper.delUmUserrole(umUserrole);

			UmModuleauth umModuleauth = new UmModuleauth();
			umModuleauth.setSyscode(syscode);
			umModuleauth.setUsercode(usercode);
			delNum += umModuleauthMapper.delUmModuleauth(umModuleauth);
			return delNum;
		} else {
			return 0;
		}
	}

	/** 创建一个新的urid **/
	@Override
	public String makeUrId() {
		return ROLE_START_STR + UUID.randomUUID().toString().replaceAll("-", "");
	}
}
