package com.picc.umapi.mapper;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.picc.umapi.mapper.base.BaseUmUserPermisMapper;
import com.picc.umapi.model.UmUserPermis;

public interface UmUserPermisMapper extends BaseUmUserPermisMapper{
	
	List<UmUserPermis> qryUmUserPermisList(String userCode);
	
	List<UmUserPermis> qryUmUserPermis(UmUserPermis permis);
	
	List<UmUserPermis> qryUmUserPermisInPermistype(@Param("userCode")String userCode, @Param("set")Set<String> permistype);
	
	List<UmUserPermis> qryUmUserPermisNotInPermistype(@Param("userCode")String userCode, @Param("set")Set<String> permistype);

	void setInvalidByUserCode(String userCode);
	
	List<UmUserPermis> qryUmUserPermisByUsercodePermistype(@Param("usercode")String usercode, @Param("permistype")String permistype);
	
	UmUserPermis qryUmUserPermisByUserCode(UmUserPermis permis);
	
	int updateByPermiscode(UmUserPermis permis);
	
}
