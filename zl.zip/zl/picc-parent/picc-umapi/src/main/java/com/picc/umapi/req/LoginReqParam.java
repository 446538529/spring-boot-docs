package com.picc.umapi.req;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("用户登录参数")
public class LoginReqParam implements ReqParam {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty("员工编号")
	private String userCode;

	@ApiModelProperty("密码")
	private String pwd;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

}
