package com.picc.umapi.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.picc.umapi.service.ComService;

@Service
public class ComServiceImpl implements ComService {

	private static Logger log = LoggerFactory.getLogger(ComServiceImpl.class);

	// public void test() {
	// PageHelper.startPage(1, 20).doSelectPageInfo(() -> )
	// }

}
