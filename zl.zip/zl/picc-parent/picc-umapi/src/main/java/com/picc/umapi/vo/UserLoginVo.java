package com.picc.umapi.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class UserLoginVo implements Serializable {

	private static final long serialVersionUID = 1L;

	private String token;

	private String userName;

	private String userCode;

	private String comcode;

	private List<Map> routes;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getComcode() {
		return comcode;
	}

	public void setComcode(String comcode) {
		this.comcode = comcode;
	}

	public List<Map> getRoutes() {
		return routes;
	}

	public void setRoutes(List<Map> routes) {
		this.routes = routes;
	}

}
