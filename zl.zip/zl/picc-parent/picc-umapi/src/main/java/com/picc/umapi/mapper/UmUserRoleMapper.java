package com.picc.umapi.mapper;

import java.util.List;

import com.picc.umapi.mapper.base.BaseUmUserroleMapper;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.req.QueryUmUserRoleParam;
import com.picc.umapi.vo.UmUserRoleVO;

public interface UmUserRoleMapper extends BaseUmUserroleMapper {

	/** 查询列表数据集合 **/
	public List<UmUserRoleVO> queryUmRoleList(QueryUmUserRoleParam queryUmUserRoleParam);

	/** 查询单条数据 **/
	public UmUserrole queryUmUserrole(UmUserrole umUserrole);

	/** 删除 数据 **/
	public int delUmUserrole(UmUserrole umUserrole);

}
