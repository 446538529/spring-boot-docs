package com.picc.umapi.model.rowmodel.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface VerifyDate {
	
	//01 格式 年/月/日 时:分:秒
	//02 格式 年/月/日
	public String value() default "01";

}
