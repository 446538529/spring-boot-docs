package com.picc.umapi.req;

import java.util.Date;

import com.picc.common.ReqParam;

import io.swagger.annotations.ApiModel;

@ApiModel("保存用户（修改用户信息）参数")
public class SaveUmUserParam implements ReqParam {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String userid;

	private String usercode;

	private String passwd;

	private String username;

	private String mobileno;

	private String remark;

	private String comcode;

	private String comname;

	private String authflag;

	private String datalevel;

	private String dataauth;

	private String validstatus;

	private Date inserttime;

	private Date updatetime;

	private String email;

	private String identifytype;

	private String identifynumber;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getComcode() {
		return comcode;
	}

	public void setComcode(String comcode) {
		this.comcode = comcode;
	}

	public String getComname() {
		return comname;
	}

	public void setComname(String comname) {
		this.comname = comname;
	}

	public String getAuthflag() {
		return authflag;
	}

	public void setAuthflag(String authflag) {
		this.authflag = authflag;
	}

	public String getDatalevel() {
		return datalevel;
	}

	public void setDatalevel(String datalevel) {
		this.datalevel = datalevel;
	}

	public String getDataauth() {
		return dataauth;
	}

	public void setDataauth(String dataauth) {
		this.dataauth = dataauth;
	}

	public String getValidstatus() {
		return validstatus;
	}

	public void setValidstatus(String validstatus) {
		this.validstatus = validstatus;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdentifytype() {
		return identifytype;
	}

	public void setIdentifytype(String identifytype) {
		this.identifytype = identifytype;
	}

	public String getIdentifynumber() {
		return identifynumber;
	}

	public void setIdentifynumber(String identifynumber) {
		this.identifynumber = identifynumber;
	}

	public Date getInserttime() {
		return inserttime;
	}

	public void setInserttime(Date inserttime) {
		this.inserttime = inserttime;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}

}
