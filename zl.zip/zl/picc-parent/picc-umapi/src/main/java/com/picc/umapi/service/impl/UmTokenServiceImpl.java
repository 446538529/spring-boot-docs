package com.picc.umapi.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.umapi.mapper.UmTokenMapper;
import com.picc.umapi.model.UmToken;
import com.picc.umapi.service.UmTokenService;

@Service("umTokenService")
public class UmTokenServiceImpl implements UmTokenService {

	private static Logger log = LoggerFactory.getLogger(ComServiceImpl.class);

	@Autowired
	private UmTokenMapper umTokenMapper;

	@Override
	public PageInfo<UmToken> queryUmTokenPage(UmToken umToken, Integer pageIndex, Integer pageSize) {
		PageInfo<UmToken> pageInfo = PageHelper.startPage(pageIndex, pageSize).doSelectPageInfo(() -> umTokenMapper.queryUmTokenPage(umToken));
		return pageInfo;
	}

	@Override
	public UmToken queryUmToken(UmToken umToken) {
		return umTokenMapper.queryUmToken(umToken);
	}

	@Override
	public int saveUmToken(UmToken umToken) {
		return umTokenMapper.insertSelective(umToken);
	}

	@Override
	public int delUmToken(UmToken umToken) {
		return umTokenMapper.delUmToken(umToken);
	}

	@Override
	public int updateUmToken(UmToken umToken) {
		return umTokenMapper.updateByPrimaryKeySelective(umToken);
	}

	@Override
	public String createToken() {
		return umTokenMapper.createToken();
	}

	@Override
	public UmToken checkUmToken(String token) {
		UmToken umToken = new UmToken();
		umToken.setToken(token);
		umToken.setExpiredtime(new Date());
		return umTokenMapper.queryUmToken(umToken);
	}

}
