package com.picc.umapi.req;

import com.picc.common.ReqParam;

public class QryUmTaskUserListReq implements ReqParam{

	private static final long serialVersionUID = 1L;

}
