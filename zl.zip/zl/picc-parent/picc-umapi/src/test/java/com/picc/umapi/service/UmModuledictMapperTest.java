package com.picc.umapi.service;

import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.picc.umapi.AbstractTest;

public class UmModuledictMapperTest extends AbstractTest {

	@Autowired
	private UmModuledictService umModuledictService;

	@Test
	public void makeRoutesMap1() {
		List<Map> makeRoutesMap = umModuledictService.makeRoutesMap("asdf", "asdf", null);
		assertNull(makeRoutesMap);
	}
}
