package com.picc.umapi.service;

import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.mapper.UmComMapper;
import com.picc.umapi.model.UmCom;

public class UmComMapperTest extends AbstractTest {

	@Autowired
	UmComMapper umComMapper;

	// 查询集合
	@Test
	public void queryUmComPage1() {
		List<UmCom> listUmCom = umComMapper.queryUmComPage();
		assertNull(listUmCom);
	}

	// 查询集合（分页）
	@Test
	public void queryUmComPage2() {
		// PageInfo<UmCom> pageUmCom = PageHelper.startPage(1, 10).doSelectPageInfo(new
		// ISelect() {
		// @Override
		// public void doSelect() {
		// umComMapper.selectGroupBy();
		// }
		// });
		PageInfo<UmCom> pageUmCom = PageHelper.startPage(1, 10).doSelectPageInfo(() -> umComMapper.queryUmComPage());
		assertNull(pageUmCom);
	}

}
