package com.picc.umapi.service;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.model.UmRole;

public class UmRoleMapperTest extends AbstractTest {

	@Autowired
	UmRoleService umRoleService;

	// 分页查询--有数据
	@Test
	public void queryUmRolePage1() {
		UmRole umRole = new UmRole();
		umRole.setRoleid("RO3100731724");
		PageInfo<UmRole> queryUmRolePage = umRoleService.queryUmRolePage(umRole, new PagingReqParam());
		assertNotNull(queryUmRolePage);
	}

	// 分页查询--无数据
	@Test
	public void queryUmRolePage2() {
		UmRole umRole = new UmRole();
		umRole.setRoleid("RO3100731724w");
		PageInfo<UmRole> queryUmRolePage = umRoleService.queryUmRolePage(umRole, new PagingReqParam());
		assertNotNull(queryUmRolePage);
	}

	// 查询集合 ---有数据
	@Test
	public void queryUmRoleList1() {
		UmRole umRole = new UmRole();
		umRole.setRoleid("RO3100731724");
		List<UmRole> queryUmRoleList = umRoleService.queryUmRoleList(umRole);
		assertNotNull(queryUmRoleList);
	}

	// 查询集合 ---无数据
	@Test
	public void queryUmRoleList2() {
		UmRole umRole = new UmRole();
		umRole.setRoleid("RO3100731724w");
		List<UmRole> queryUmRoleList = umRoleService.queryUmRoleList(umRole);
		assertNotNull(queryUmRoleList);
	}

	// 删除操作
	@Test
	public void deleteByRole1() {
		UmRole umRole = new UmRole();
		umRole.setRoleid("RO3100731568");
		int deleteByRole = umRoleService.delUmRole(umRole);
		assertNotNull(deleteByRole);
	}

	// 创建随机不重复字符串token
	@Test
	public void createToken() {
		String createToken = umRoleService.makeRoleId();
		assertNotNull(createToken);
	}
}
