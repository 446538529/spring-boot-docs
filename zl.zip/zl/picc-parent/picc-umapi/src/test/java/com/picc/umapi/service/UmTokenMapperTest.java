package com.picc.umapi.service;

import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.model.UmToken;

public class UmTokenMapperTest extends AbstractTest {

	@Autowired
	private UmTokenService umTokenService;

	UmToken umToken = new UmToken();

	@Test
	public void queryUmTokenPage1() {
		PageInfo<UmToken> queryUmTokenPage = umTokenService.queryUmTokenPage(umToken, 0, 10);
		assertNull(queryUmTokenPage);
	}

	@Test
	public void queryUmToken1() {
		UmToken queryUmToken = umTokenService.queryUmToken(umToken);
		assertNull(queryUmToken);
	}

	@Test
	public void createToken1() {
		String createToken = umTokenService.createToken();
		assertNull(createToken);
	}

	@Test
	public void saveUmToken1() {
		umToken.setToken(umTokenService.createToken());
		umToken.setExpiredtime(new Date());
		umToken.setInserttime(new Date());
		umToken.setOpenid("asdf");
		umToken.setUsercode("asdf");
		int saveUmToken = umTokenService.saveUmToken(umToken);
		assertNull(saveUmToken);
	}

	@Test
	public void delUmToken1() {
		umToken.setToken("asdf");
		int delUmToken = umTokenService.delUmToken(umToken);
		assertNull(delUmToken);
	}

	@Test
	public void updateUmToken() {
		int updateUmToken = umTokenService.updateUmToken(umToken);
		assertNull(updateUmToken);
	}

	@Test
	public void checkUmToken1() {
		UmToken checkUmToken = umTokenService.checkUmToken("asdf");
		assertNull(checkUmToken);
	}
}
