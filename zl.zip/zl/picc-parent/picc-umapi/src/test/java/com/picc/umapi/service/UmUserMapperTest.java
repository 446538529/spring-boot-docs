package com.picc.umapi.service;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.model.UmUser;
import com.picc.umapi.req.QueryUmUserParam;
import com.picc.umapi.req.SaveUmUserParam;

public class UmUserMapperTest extends AbstractTest {

	@Autowired
	private UmUserService umUserService;

	QueryUmUserParam umUser = new QueryUmUserParam();
	SaveUmUserParam param = new SaveUmUserParam();
	UmUser user = new UmUser();

	@Test
	public void queryUmUserPage1() {
		umUser.setComcode("4");
		PageInfo<UmUser> queryUmUserPage = umUserService.queryUmUserPage(umUser);
		assertNull(queryUmUserPage);
	}

	@Test
	public void queryUmUserPage2() {
		umUser.setUsername("卢");
		umUser.setPageIndex(2);
		PageInfo<UmUser> queryUmUserPage = umUserService.queryUmUserPage(umUser);
		assertNull(queryUmUserPage);
	}

	@Test
	public void queryUmUserPage3() {
		PageInfo<UmUser> queryUmUserPage = umUserService.queryUmUserPage(umUser);
		assertNull(queryUmUserPage);
	}

	@Test
	public void queryUmUser1() {
		UmUser queryUmUser = umUserService.queryUmUser(null);
		assertNull(queryUmUser);
	}

	@Test
	public void queryUmUser2() {
		UmUser queryUmUser = umUserService.queryUmUser("13151177");
		assertNull(queryUmUser);
	}

	@Test
	public void saveUmUser1() {
		param.setComcode("asdf");
		param.setUsercode("asdf");
		param.setUsername("asdf");
		param.setPasswd("asdf");
		param.setMobileno("asdf");
		param.setAuthflag("usercode=");
		param.setDatalevel("3");
		param.setDataauth("'asdf'");
		param.setEmail("asdf");
		int saveUmUser = umUserService.saveUmUser(param);
		assertNull(saveUmUser);
	}

	@Test
	public void megerUser1() {
		param.setUsercode("13151177");
		param.setPasswd("123");
		int megerUser = umUserService.megerUser(param);
		assertNull(megerUser);
	}

	@Test
	public void megerUser2() {
		param.setUsercode("asdf");
		param.setComcode("test");
		param.setUsername("test");
		param.setPasswd("test");
		param.setMobileno("test");
		param.setAuthflag("test=");
		param.setDatalevel("3");
		param.setDataauth("'test'");
		param.setEmail("test");
		int megerUser = umUserService.megerUser(param);
		assertNull(megerUser);
	}

	@Test
	public void delUmUser1() {
		user.setUsercode("asdf");
		user.setValidstatus("1");
		int delUmUser = umUserService.delUmUser(user);
		assertNull(delUmUser);
	}

	@Test
	public void updateUmUser1() {
		param.setUserid("U2cd2588c96d111e8a13db499baa6ddb8");
		param.setPasswd("123");
		umUserService.updateUmUser(param);
	}
}
