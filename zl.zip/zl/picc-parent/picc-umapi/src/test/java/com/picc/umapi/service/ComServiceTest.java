package com.picc.umapi.service;

import org.junit.Test;

import com.picc.umapi.AbstractTest;

public class ComServiceTest extends AbstractTest {

	@Test
	public void t() {

	}

}
