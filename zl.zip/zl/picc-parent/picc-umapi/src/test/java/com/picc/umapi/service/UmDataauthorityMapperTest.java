package com.picc.umapi.service;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageInfo;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.model.UmDataauthority;

public class UmDataauthorityMapperTest extends AbstractTest {

	@Autowired
	private UmDataauthorityService umDataauthorityService;

	UmDataauthority umDataAuthority = new UmDataauthority();

	@Test
	public void queryDataAuthority1() {
		PageInfo<UmDataauthority> queryDataAuthority = umDataauthorityService.queryDataAuthority("1", 1, 10);
		assertNull(queryDataAuthority);
	}

	@Test
	public void saveUmDataAuthority1() {
		// umDataAuthority.setId("asdf");
		umDataAuthority.setUsercode("asdf");
		// umDataAuthority.setUsername("asdf");
		// umDataAuthority.setDatavalue("asdf");
		// umDataAuthority.setDatarelation("asdf");
		// umDataAuthority.setDatatype("asdf");
		int saveUmDataAuthority = umDataauthorityService.saveUmDataAuthority(umDataAuthority);
		assertNull(saveUmDataAuthority);
	}

	@Test
	public void delUmDataAuthority1() {
		umDataAuthority.setUsercode("asdf");
		int delUmDataAuthority = umDataauthorityService.delUmDataAuthority(umDataAuthority);
		assertNull(delUmDataAuthority);
	}
}
