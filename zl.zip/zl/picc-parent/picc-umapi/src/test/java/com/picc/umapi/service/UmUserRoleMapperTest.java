package com.picc.umapi.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.github.pagehelper.PageInfo;
import com.picc.common.PagingReqParam;
import com.picc.umapi.AbstractTest;
import com.picc.umapi.model.UmUserrole;
import com.picc.umapi.vo.UmUserRoleVO;

public class UmUserRoleMapperTest extends AbstractTest {

	@Autowired
	UmUserRoleService umUserRoleService;

	/**
	 * @Description:分页查询
	 * @author: HeZhuxing
	 */
	@Test
	public void queryUmUserPage1() {
		PageInfo<UmUserRoleVO> queryUmUserrolePage = umUserRoleService.queryUmUserrolePage(null, "prpclaim", new PagingReqParam());
		assertNotNull(queryUmUserrolePage);
	}

	/**
	 * @Description:查询单条数据---无数据
	 * @author: HeZhuxing
	 */
	@Test
	public void queryUmUserrole1() {
		UmUserrole umUserrole = new UmUserrole();
		umUserrole.setUrid("q12");
		UmUserrole umUserroleRe = umUserRoleService.queryUmUserrole(umUserrole);
		assertNull(umUserroleRe);
	}

	/**
	 * @Description:查询单条数据---有数据
	 * @author: HeZhuxing
	 */
	@Test
	public void queryUmUserrole2() {
		UmUserrole umUserrole = new UmUserrole();
		umUserrole.setUrid("UR5775616257");
		UmUserrole umUserroleRe = umUserRoleService.queryUmUserrole(umUserrole);
		assertNotNull(umUserroleRe);
	}

	/**
	 * @Description:创建一个新的urid
	 * @author: HeZhuxing
	 */
	@Test
	public void makeUrId1() {
		String createToken = umUserRoleService.makeUrId();
		System.out.println(createToken);
		assertNotNull(createToken);
	}

}
