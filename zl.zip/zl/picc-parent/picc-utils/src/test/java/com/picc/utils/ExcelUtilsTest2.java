package com.picc.utils;

import java.io.FileInputStream;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import com.alibaba.excel.support.ExcelTypeEnum;

public class ExcelUtilsTest2 {
	
	@Test
	public void testReadDate() throws Exception {
		List<List<String>> dataList = ExcelUtils.read(new FileInputStream("d:/20180821-test.xlsx"), ExcelTypeEnum.XLSX, 1, 1);
		
		System.out.println(StringUtils.join(dataList, "\n"));
	}

}
