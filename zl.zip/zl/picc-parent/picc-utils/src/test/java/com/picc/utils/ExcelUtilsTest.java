package com.picc.utils;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.metadata.Table;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.fastjson.JSON;

public class ExcelUtilsTest {

	/**
	 * 测试读取Excel表头
	 * @throws IOException
	 */
	@Test
	public void testGetSheet() throws IOException {
		
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("template.xlsx");
		Sheet sheet = ExcelUtils.getSheet(inputStream, ExcelTypeEnum.XLSX, 0, 1);
		
		List<List<String>> head = sheet.getHead();
		
		// 共有5列数据
		assertEquals(5, head.size());
		
		// 校验表头数据
		assertEquals("序号", head.get(0).get(0));
		assertEquals("姓名", head.get(1).get(0));
		assertEquals("性别", head.get(2).get(0));
		assertEquals("出生日期", head.get(3).get(0));
		assertEquals("薪资", head.get(4).get(0));
		
	}
	
	/**
	 * 测试导出无表头数据
	 * @throws IOException
	 */
	@Test
	public void testWrite1() throws IOException {
		List<List<String>> data = new ArrayList<>();
		data.add(Arrays.asList("1", "test1", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("2", "test2", "女", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("3", "test3", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("4", "test4", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("5", "test5", "男", "1990-01-01", "12345.67"));
		ExcelUtils.write(data, new FileOutputStream("d:/test1.xlsx"), ExcelTypeEnum.XLSX);
	}
	
	/**
	 * 测试导出带表头数据
	 * @throws IOException
	 */
	@Test
	public void testWrite2() throws IOException {
		List<List<String>> data = new ArrayList<>();
		data.add(Arrays.asList("1", "test1", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("2", "test2", "女", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("3", "test3", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("4", "test4", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("5", "test5", "男", "1990-01-01", "12345.67"));
		
		List<String> head = Arrays.asList("序号", "姓名", "性别", "出生日期", "薪资");
		ExcelUtils.write(data, new FileOutputStream("d:/test2.xlsx"), ExcelTypeEnum.XLSX, head);
	}
	
	
	/**
	 * 测试导出指定模版表头数据
	 * @throws IOException
	 */
	@Test
	public void testWrite3() throws IOException {
		List<List<String>> data = new ArrayList<>();
		data.add(Arrays.asList("1", "test1", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("2", "test2", "女", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("3", "test3", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("4", "test4", "男", "1990-01-01", "12345.67"));
		data.add(Arrays.asList("5", "test5", "男", "1990-01-01", "12345.67"));
		
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("template.xlsx");
		Sheet sheet = ExcelUtils.getSheet(inputStream, ExcelTypeEnum.XLSX, 0, 1);
		
		ExcelUtils.write(data, new FileOutputStream("d:/test3.xlsx"), ExcelTypeEnum.XLSX, sheet);
	}
	
	// 测试读取excel表
	@Test
	public void testZRead() throws IOException {
		List<List<String>> data = ExcelUtils.read(new FileInputStream("d:/test3.xlsx"), ExcelTypeEnum.XLSX, 0, 1);
		
		assertEquals("1", data.get(0).get(0));
		assertEquals("test2", data.get(1).get(1));
		assertEquals("男", data.get(2).get(2));
		assertEquals("1990-01-01", data.get(3).get(3));
		assertEquals("12345.67", data.get(4).get(4));
		 
		
	}
	
	// 测试读取对象
	@Test
	public void testReadObject() throws IOException {
		FileInputStream inputStream = new FileInputStream("d:/test11.xlsx");
		List<TestObject> list = ExcelUtils.readObject(inputStream, ExcelTypeEnum.XLSX, TestObject.class);
		
		String json = JSON.toJSONString(list);
		List<TestObject2> list2 = JSON.parseArray(json, TestObject2.class);
		System.out.println(list);
		
	}
	
	// 测试生成忽略指定字段Excel表
	@Test
	public void testWriteObjectWithoutProperties() throws IOException {
		FileOutputStream output = new FileOutputStream("d:/test22.xlsx");
		TestObject obj2 = new TestObject();
		obj2.setErrors("错误信息");
		obj2.setStrno("1");
		obj2.setProject("projectxxxx");
		
		List<TestObject> list = Arrays.asList(obj2, obj2, obj2, obj2);
		ExcelUtils.writeObject(list, output, ExcelTypeEnum.XLSX, TestObject.class, "errors".split(","));
		
	}
	

}
