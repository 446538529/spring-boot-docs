package com.picc.utils;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.fastjson.annotation.JSONField;

public class TestObject extends BaseRowModel {
	
	@ExcelProperty(value = "序号")
	@JSONField(name = "no")
	private String strno;
	
	@ExcelProperty(value = "姓名")
	private String project;
	
	@ExcelProperty(value = "日期", format = "yyyy/MM/dd")
	private String date;
	
	@ExcelProperty(value = "错误信息")
	private String errors;

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getStrno() {
		return strno;
	}

	public void setStrno(String strno) {
		this.strno = strno;
	}

	public String getErrors() {
		return errors;
	}

	public void setErrors(String errors) {
		this.errors = errors;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
