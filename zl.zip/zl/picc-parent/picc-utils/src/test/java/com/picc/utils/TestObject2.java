package com.picc.utils;

import java.util.List;

public class TestObject2 {
	
	private List<String> errorList;
	
	
	private String errors;
	
	private int no;
	
	private String project;

	public int getNo() {
		
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

}
