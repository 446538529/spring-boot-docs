package com.alibaba.excel.read;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;

import com.alibaba.excel.metadata.ExcelHeadProperty;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.read.context.AnalysisContext;
import com.alibaba.excel.read.event.OneRowAnalysisFinishEvent;
import com.alibaba.excel.read.exception.ExcelAnalysisException;
import com.monitorjbl.xlsx.StreamingReader;
import com.monitorjbl.xlsx.impl.StreamingCell;

public class StreamingReaderSaxAnalyser extends BaseSaxAnalyser {
	
	private static Field rawContentsField;
	
	static {
		try {
			rawContentsField = StreamingCell.class.getDeclaredField("rawContents");
			rawContentsField.setAccessible(true);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	static String getRawContents(Cell cell) {
		try {
			Object val = rawContentsField.get(cell);
			if (val == null) {
				return null;
			} else {
				return String.valueOf(val);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private Workbook workbook;
	private boolean analyAllSheet = false;
	
	public StreamingReaderSaxAnalyser(AnalysisContext context) {
		this.analysisContext = context;
		try {
			this.workbook = StreamingReader.builder()
					.rowCacheSize(100)
					.bufferSize(4096)
					.open(context.getInputStream());
		} catch (Exception e) {
			throw new ExcelAnalysisException(e);
		}
		if (context.getCurrentSheet() == null) {
			this.analyAllSheet = true;
		}
	}
	
	@Override
	public List<Sheet> getSheets() {
		List<Sheet> sheets = new ArrayList<>();
		
		for(int i = 0; i < workbook.getNumberOfSheets(); i++) {
			Sheet sheet = new Sheet(i + 1);
			sheet.setSheetName(workbook.getSheetAt(i).getSheetName());
			sheets.add(sheet);
		}
		
		return sheets;
	}

	@Override
	public void stop() {
		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void analySheet(Sheet sheet) {
		org.apache.poi.ss.usermodel.Sheet ss = workbook.getSheetAt(sheet.getSheetNo() - 1);
		
		ExcelHeadProperty property = analysisContext.getExcelHeadProperty();
		if (property != null) {
			sheet.setClazz(property.getHeadClazz());
			sheet.setHead(property.getHead());
			sheet.setSheetName(ss.getSheetName());
		}
		analysisContext.setCurrentSheet(sheet);
		
		final int rowNum = ss.getLastRowNum();
		
		int line = 1;
		for (Row row : ss) {
			if (line > sheet.getHeadLineMun()) {
				List<String> values = new ArrayList<>();
				for (int j = 0; j < row.getLastCellNum(); j++) {
					Cell cell = row.getCell(j);
					if (cell != null) {
						CellType type = cell.getCellTypeEnum();
						String val = cell.getStringCellValue();
						if (type == CellType.NUMERIC) {
							val = getRawContents(cell);
						}
						if (analysisContext.trim()) {
							val = StringUtils.trim(val);
						}
						values.add(val);
					} else {
						values.add(null);
					}
				}
				analysisContext.setCurrentRowNum(line);
				
				notifyListeners(new OneRowAnalysisFinishEvent(values));
			}
			line++;
		}
		
	}

	@Override
	protected void execute() {
		if (this.analyAllSheet) {
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				analySheet(new Sheet(i + 1));
			}
		} else {
			analySheet(analysisContext.getCurrentSheet());
		}
	}
	
	protected void finalize() throws Throwable {
        stop();
    }

}
