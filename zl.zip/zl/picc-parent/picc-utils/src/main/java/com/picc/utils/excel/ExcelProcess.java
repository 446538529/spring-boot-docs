package com.picc.utils.excel;

import java.util.List;

import com.alibaba.excel.read.context.AnalysisContext;

public interface ExcelProcess {
	
	public void process(List<String> row, AnalysisContext context);

}
