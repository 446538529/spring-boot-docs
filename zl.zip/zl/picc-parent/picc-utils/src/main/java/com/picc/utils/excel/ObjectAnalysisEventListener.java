package com.picc.utils.excel;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.ExcelColumnProperty;
import com.alibaba.excel.read.context.AnalysisContext;
import com.alibaba.excel.read.event.AnalysisEventListener;
import com.alibaba.excel.util.TypeUtil;

/**
 * Easyexcel解析成 T 结构数据
 * @author Jimmy
 *
 * @param <T>
 */
public class ObjectAnalysisEventListener<T extends BaseRowModel> extends AnalysisEventListener<T> {
	
	private static final Logger log = LoggerFactory.getLogger(ObjectAnalysisEventListener.class);
	
	private static final String DOUBLE_REGEXP = "^\\d+(\\.\\d+)?$";
	
	private int line;
	
	private List<Field> dateField = new ArrayList<>();

	private List<T> list = new LinkedList<>();

	private Map<String, SimpleDateFormat> formats = new HashMap<>();

	public List<T> getList() {
		return list;
	}

	private ObjectAnalysisEventListener(Class<T> clazz) {
		this.init(clazz);
	}
	
	public static <T extends BaseRowModel> ObjectAnalysisEventListener<T> newInstance(Class<T> clazz) {
		return new ObjectAnalysisEventListener<>(clazz);
	}

	private void init(Class<T> clazz) {
		Field[] fields = clazz.getDeclaredFields();
		for (Field field : fields) {
			ExcelProperty excelProperty = field.getAnnotation(ExcelProperty.class);
			// 优化string-date类型数据
			if (field.getType() == String.class && excelProperty != null && StringUtils.isNotEmpty(excelProperty.format())) {
				dateField.add(field);
				formats.put(field.getName(), new SimpleDateFormat(excelProperty.format()));
			}
		}
	}

	@Override
	public void invoke(T obj, AnalysisContext context) {
		log.debug("read excel data line:{}", ++line);
		
		// 读取到所有的cell都是空白则忽略
		List<String> rowData = new ArrayList<>();
		for (ExcelColumnProperty property : context.getExcelHeadProperty().getColumnPropertyList()) {
			try {
				String val = BeanUtils.getProperty(obj, property.getField().getName());
				rowData.add(val);
			} catch (Exception e) {
				log.warn("convert excel data fail, line:" + line, e);
			}
		}
		if (StringUtils.isAllEmpty(rowData.toArray(new String[0]))) {
			log.warn("ignore empty data, line:{}", line) ;
			return;
		}
		
		// Date类型转换
		for (Field field : dateField) {
			try {
				String val = BeanUtils.getProperty(obj, field.getName());
				// 数值类型直接调用POI解析日期
				if (val != null && Pattern.matches(DOUBLE_REGEXP, val)) {
					Date date = HSSFDateUtil.getJavaDate(Double.parseDouble(val));
					val = formats.get(field.getName()).format(date);
					BeanUtils.setProperty(obj, field.getName(), val);
				} else {
					// 非数值类型的调用esayexcel解析日期
					try {
						final SimpleDateFormat sdf = formats.get(field.getName());
						Date date = TypeUtil.getSimpleDateFormatDate(val, sdf.toPattern());
						val = formats.get(field.getName()).format(date);
						BeanUtils.setProperty(obj, field.getName(), val);
					} catch (Exception e) {
						log.warn("Excel导入:Date类型转换异常", e);
					}
					
				}
			} 
			catch (NumberFormatException e) {
				log.debug("Date转换错误", e);
			}
			catch (Exception e) {
				log.warn("Excel导入:Date类型转换异常", e);
			}

		}
		list.add(obj);
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext context) {

	}

}