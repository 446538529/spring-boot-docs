package com.picc.utils.mybatis.generator;

import java.sql.Types;

import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.internal.types.JavaTypeResolverDefaultImpl;

public class MyJavaTypeResolverDefaultImpl extends JavaTypeResolverDefaultImpl {

	public MyJavaTypeResolverDefaultImpl() {
		super();
		super.typeMap.put(Types.OTHER, new JdbcTypeInformation("NVARCHAR", new FullyQualifiedJavaType(String.class.getName())));
	}
	
}
