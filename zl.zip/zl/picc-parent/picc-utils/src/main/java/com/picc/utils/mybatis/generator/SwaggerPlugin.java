package com.picc.utils.mybatis.generator;

import java.util.List;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
import org.mybatis.generator.api.dom.java.Field;
import org.mybatis.generator.api.dom.java.TopLevelClass;

public class SwaggerPlugin extends PluginAdapter {

	@Override
	public boolean validate(List<String> warnings) {
		return true;
	}
	
	@Override
	public boolean modelBaseRecordClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
		topLevelClass.addImportedType("io.swagger.annotations.ApiModel");
		topLevelClass.addImportedType("io.swagger.annotations.ApiModelProperty");
		String remarks = introspectedTable.getRemarks();
		if (remarks == null || remarks.trim().length() == 0) {
			remarks = introspectedTable.getFullyQualifiedTableNameAtRuntime();
		}
		topLevelClass.addAnnotation("@ApiModel(description = \"" + remarks + "\")");
		return super.modelBaseRecordClassGenerated(topLevelClass, introspectedTable);
	}
	
	@Override
	public boolean modelFieldGenerated(Field field, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, ModelClassType modelClassType) {
		String remarks = introspectedColumn.getRemarks();
		if (remarks == null || remarks.trim().length() == 0) {
			remarks = introspectedColumn.getActualColumnName();
		}
		field.addAnnotation("@ApiModelProperty(\"" + remarks + "\")");
		return super.modelFieldGenerated(field, topLevelClass, introspectedColumn, introspectedTable, modelClassType);
	}
	

}
