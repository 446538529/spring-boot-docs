package com.picc.utils;

/**
 * 邮件工具类
 * @author LaiLeXin 2018-07-31
 *
 */
public class MailUtils {

}
