package com.picc.utils.mybatis.generator;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyBatisGeneratorUtils {

	private static final Logger log = LoggerFactory.getLogger(MyBatisGeneratorUtils.class);

	/**
	 * 传入 MyBatis Generator Config XML文件流生成代码 (不覆盖代码, 如果需要重新生成需要删除原有代码文件)
	 * @param inputStream
	 */
	public static void generate(InputStream inputStream) {

		List<String> warnings = new ArrayList<String>();
		boolean overwrite = true;
		ConfigurationParser cp = new ConfigurationParser(warnings);

		try {
			Configuration config = cp.parseConfiguration(inputStream);
			DefaultShellCallback callback = new DefaultShellCallback(overwrite);
			MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, callback, warnings);
			myBatisGenerator.generate(null);
		} catch (Exception e) {
			log.error("generator error", e);
		}

		for (String warn : warnings) {
			log.warn("my batis generator result warning: {}", warn);
		}
	}
	
	/**
	 * 从类加载器读取资源信息并生成代码  (不覆盖代码, 如果需要重新生成需要删除原有代码文件)
	 * @param resource
	 * @param clazz
	 */
	public static void generator(String resource, Class<?> clazz) {
		try (InputStream inputStream = clazz.getClassLoader().getResourceAsStream(resource)) {
			generate(inputStream);
		} catch (IOException e) {
			log.error("load resource error", e);
		}
	}

}
