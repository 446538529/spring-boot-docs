package com.picc.utils.excel;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.excel.read.context.AnalysisContext;
import com.alibaba.excel.read.event.AnalysisEventListener;

/**
 * Easyexcel解析成List&lt;String&gt;结构数据
 * @author Jimmy
 *
 */
public class DefaultAnalysisEventListener extends AnalysisEventListener<List<String>> {
	
	private static final Logger log = LoggerFactory.getLogger(DefaultAnalysisEventListener.class);
	
	private int line;
	
	private final ExcelProcess process;

	public DefaultAnalysisEventListener(ExcelProcess process) {
		this.process = process;
	}

	@Override
	public void invoke(List<String> row, AnalysisContext context) {
		log.debug("read excel data line:{}", ++line);
		
		// 读取到所有的cell都是空白则忽略
		if ((context.getCurrentRowAnalysisResult()) instanceof List<?>) {
			try {
				List<?> rowData = (List<?>) context.getCurrentRowAnalysisResult();
				if (StringUtils.isAllEmpty(rowData.toArray(new String[0]))) {
					log.warn("ignore empty data, line:{}", line) ;
					return;
				}
			} catch (Exception e) {
				log.warn("convert excel data fail, line:" + line, e);
			}
		}
		
		if (process != null) {
			process.process(row, context);
		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext context) {

	}

}