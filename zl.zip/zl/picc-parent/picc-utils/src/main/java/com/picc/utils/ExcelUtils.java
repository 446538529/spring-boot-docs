package com.picc.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.StreamingExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.ExcelColumnProperty;
import com.alibaba.excel.metadata.ExcelHeadProperty;
import com.alibaba.excel.metadata.Font;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.metadata.TableStyle;
import com.alibaba.excel.read.exception.ExcelAnalysisException;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.picc.utils.excel.DefaultAnalysisEventListener;
import com.picc.utils.excel.ExcelProcess;
import com.picc.utils.excel.ObjectAnalysisEventListener;

/**
 * Excel 工具类
 * 
 * @author LaiLexin 2018-07-31
 *
 */
public class ExcelUtils {

	private static final Logger log = LoggerFactory.getLogger(ExcelUtils.class);

	private static List<List<String>> rowsToHead(List<List<String>> rows) {
		if (rows == null) {
			return null;
		}

		List<List<String>> head = new ArrayList<>();
		int col_size = 0;
		for (List<String> row : rows) {
			for (int i = col_size; i < row.size(); i++) {
				if (row.get(i) != null) {
					col_size = i;
				}
			}
		}

		for (int i = 0; i <= col_size; i++) {
			String title = null;
			List<String> hRow = new ArrayList<>();
			for (List<String> row : rows) {
				if (row.size() > i) {
					if (row.get(i) != null) {
						title = row.get(i);
					}
					hRow.add(title);
				} else {
					hRow.add(null);
				}
			}
			head.add(hRow);
		}

		return head;
	}

	/**
	 * 获取Excel表信息
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheetNo
	 *            Sheet索引号(从1开始)
	 * @param headNum
	 *            表头行数(0:无表头)
	 * @return
	 */
	public static Sheet getSheet(InputStream inputStream, ExcelTypeEnum type, int sheetNo, final int headNum) {
		StreamingExcelReader reader = new StreamingExcelReader(inputStream, type, null, new DefaultAnalysisEventListener((row, ctx) -> {
			List<List<String>> head = ctx.getCurrentSheet().getHead();
			if (ctx.getCurrentRowNum() < headNum) {
				if (head == null) {
					head = new ArrayList<>();
					ctx.getCurrentSheet().setHead(head);
				}
				head.add(row);
			} else {
				ctx.interrupt();
			}
		}));
		Sheet sheet = new Sheet(sheetNo, headNum);

		try {
			reader.read(sheet);
		} catch (ExcelAnalysisException e) {
			log.warn("解析Excel表异常", e);
			e.printStackTrace();
		}
		sheet.setHead(rowsToHead(sheet.getHead()));
		// sheet.setHeadLineMun(headNo);
		return sheet;
	}

	/**
	 * 读取表格内容
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @return
	 */
	public static List<List<String>> read(InputStream inputStream, ExcelTypeEnum type) {
		return read(inputStream, type, -1, 0);
	}

	/**
	 * 读取表格内容
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheetNo
	 *            sheet索引号(从1开始)
	 * @return
	 */
	public static List<List<String>> read(InputStream inputStream, ExcelTypeEnum type, int sheetNo) {
		return read(inputStream, type, sheetNo, 0);
	}

	/**
	 * 读取表格内容
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheetNo
	 *            sheet索引号(从1开始)
	 * @param headNum
	 *            表头行数(0:无表头)
	 * @return
	 */
	public static List<List<String>> read(InputStream inputStream, ExcelTypeEnum type, int sheetNo, int headNum) {
		List<List<String>> datas = new LinkedList<>();
		StreamingExcelReader reader = new StreamingExcelReader(inputStream, type, null, new DefaultAnalysisEventListener((row, ctx) -> {
			datas.add(row);
		}));
		if (sheetNo < 0) {
			reader.read();
		} else {
			Sheet sheet = new Sheet(sheetNo, headNum);
			reader.read(sheet);
		}
		return datas;
	}

	/**
	 * 读取表格内容
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheet
	 * @return
	 */
	public static List<List<String>> read(InputStream inputStream, ExcelTypeEnum type, Sheet sheet) {
		List<List<String>> datas = new LinkedList<>();
		StreamingExcelReader reader = new StreamingExcelReader(inputStream, type, null, new DefaultAnalysisEventListener((row, ctx) -> {
			datas.add(row);
		}));
		reader.read(sheet);
		return datas;
	}

	/**
	 * 读取表格内容
	 * 
	 * @param inputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheet
	 * @param process
	 *            读取处理器
	 */
	public static void read(InputStream inputStream, ExcelTypeEnum type, Sheet sheet, ExcelProcess process) {
		StreamingExcelReader reader = new StreamingExcelReader(inputStream, type, null, new DefaultAnalysisEventListener(process));
		reader.read();
	}

	/**
	 * 读取BaseRowModel数据(默认读取第一页, 带1行表头)
	 * 
	 * @param inputStream
	 * @param type
	 * @param clazz
	 * @return
	 */
	public static <T extends BaseRowModel> List<T> readObject(InputStream inputStream, ExcelTypeEnum type, Class<T> clazz) {
		return readObject(inputStream, type, new Sheet(1, 1, clazz));
	}

	/**
	 * 读取BaseRowModel数据
	 * 
	 * @param inputStream
	 * @param type
	 * @param sheetNo
	 * @param headNum
	 * @param clazz
	 * @return
	 */
	public static <T extends BaseRowModel> List<T> readObject(InputStream inputStream, ExcelTypeEnum type, int sheetNo, int headNum, Class<T> clazz) {
		return readObject(inputStream, type, new Sheet(sheetNo, headNum, clazz));
	}

	/**
	 * 读取BaseRowModel数据
	 * 
	 * @param inputStream
	 * @param type
	 * @param sheet
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T extends BaseRowModel> List<T> readObject(InputStream inputStream, ExcelTypeEnum type, Sheet sheet) {
		ObjectAnalysisEventListener<T> listener = ObjectAnalysisEventListener.newInstance((Class<T>)sheet.getClazz());
		StreamingExcelReader reader = new StreamingExcelReader(inputStream, type, null, listener);
		reader.read(sheet);
		return listener.getList();
	}

	/**
	 * 生成Excel表
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @throws IOException
	 */
	public static void write(List<List<String>> data, OutputStream outputStream, ExcelTypeEnum type) throws IOException {
		write(data, outputStream, type, new Sheet(1));
	}

	/**
	 * 生成Excel表
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param head
	 *            标题头
	 * @throws IOException
	 */
	public static void write(List<List<String>> data, OutputStream outputStream, ExcelTypeEnum type, List<String> head) throws IOException {
		Sheet sheet = new Sheet(1);
		List<List<String>> headData = new ArrayList<>();
		for (String title : head) {
			headData.add(Arrays.asList(title));
		}
		sheet.setHead(headData);
		write(data, outputStream, type, sheet);
	}

	/**
	 * 生成Excel表
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheet
	 * @throws IOException
	 */
	public static void write(List<List<String>> data, OutputStream outputStream, ExcelTypeEnum type, Sheet sheet) throws IOException {
		ExcelWriter writer = new ExcelWriter(outputStream, type);
		if (sheet.getTableStyle() == null) {
			sheet.setTableStyle(buildDefaultTableStyle());
		}
		try {
			if (null == sheet.getSheetName() || sheet.getSheetName().trim().length() == 0) {
				sheet.setSheetName("Sheet" + sheet.getSheetNo());
			}
			writer.write0(data, sheet);
		} finally {
			writer.finish();
			outputStream.flush();
		}
	}

	/**
	 * 生成Excel表
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param clazz
	 *            数据模型
	 * @throws IOException
	 */
	public static <T extends BaseRowModel> void writeObject(List<T> data, OutputStream outputStream, ExcelTypeEnum type, Class<T> clazz) throws IOException {
		writeObject(data, outputStream, type, new Sheet(1, 1, clazz));
	}

	/**
	 * 生成Excel表
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param sheet
	 *            带有Excel表模型的Sheet
	 * @throws IOException
	 */
	public static <T extends BaseRowModel> void writeObject(List<T> data, OutputStream outputStream, ExcelTypeEnum type, Sheet sheet) throws IOException {
		ExcelWriter writer = new ExcelWriter(outputStream, type);
		if (sheet.getTableStyle() == null) {
			sheet.setTableStyle(buildDefaultTableStyle());
		}
		try {
			if (null == sheet.getSheetName() || sheet.getSheetName().trim().length() == 0) {
				sheet.setSheetName("Sheet" + sheet.getSheetNo());
			}
			writer.write(data, sheet);
		} finally {
			writer.finish();
			outputStream.flush();
		}
	}

	/**
	 * 生成Excel表 (忽略指定属性)
	 * 
	 * @param data
	 *            数据
	 * @param outputStream
	 *            Excel流
	 * @param type
	 *            表格类型 (XLSX, XLS)
	 * @param clazz
	 * @param ignoreFileds
	 *            忽略的字段列表
	 * @throws IOException
	 */
	public static <T extends BaseRowModel> void writeObject(List<T> data, OutputStream outputStream, ExcelTypeEnum type, Class<T> clazz, String[] ignoreFields) throws IOException {
		ExcelHeadProperty excelHeadProperty = buildExcelHeadProperty(clazz, ignoreFields);
		List<List<String>> head = excelHeadProperty.getHead();
		List<List<String>> contents = new LinkedList<>();
		for (T rowData : data) {
			contents.add(convertOneRowData(excelHeadProperty, rowData));
		}
		Sheet sheet = new Sheet(1, 1);
		sheet.setHead(head);
		write(contents, outputStream, type, sheet);
	}

	private static <T extends BaseRowModel> ExcelHeadProperty buildExcelHeadProperty(Class<T> clazz, String[] ignoreFields) {
		ExcelHeadProperty excelHeadProperty = new ExcelHeadProperty(clazz, new ArrayList<>());
		List<String> ignoreList = Arrays.asList(ObjectUtils.defaultIfNull(ignoreFields, new String[0]));
		ExcelColumnProperty[] properties = excelHeadProperty.getColumnPropertyList().toArray(new ExcelColumnProperty[0]);
		for (ExcelColumnProperty prop : properties) {

			if (ignoreList.contains(prop.getField().getName())) {
				excelHeadProperty.getColumnPropertyList().remove(prop);
				excelHeadProperty.getHead().remove(prop.getHead());
			}

		}
		return excelHeadProperty;
	}

	private static List<String> convertOneRowData(ExcelHeadProperty excelHeadProperty, Object data) {
		List<String> row = new ArrayList<>();
		for (ExcelColumnProperty prop : excelHeadProperty.getColumnPropertyList()) {
			String val = null;
			try {
				val = BeanUtils.getProperty(data, prop.getField().getName());
			} catch (Exception e) {
				log.warn("解析数据异常", e);
			}
			row.add(ObjectUtils.defaultIfNull(val, ""));
		}
		return row;
	}
	
	// 默认表格样式: 表头:宋体 12号加粗, 正文: 宋体 11号
	private static TableStyle buildDefaultTableStyle() {

		TableStyle tableStyle = new TableStyle();
		Font headFont = new Font();
		headFont.setBold(true);
		headFont.setFontName("宋体");
		headFont.setFontHeightInPoints((short) 12);

		tableStyle.setTableHeadFont(headFont);
		tableStyle.setTableHeadBackGroundColor(IndexedColors.WHITE1);

		Font contentFont = new Font();
		contentFont.setBold(false);
		contentFont.setFontHeightInPoints((short) 11);
		contentFont.setFontName("宋体");

		tableStyle.setTableContentFont(contentFont);
		tableStyle.setTableContentBackGroundColor(IndexedColors.WHITE1);

		return tableStyle;
	}
}

