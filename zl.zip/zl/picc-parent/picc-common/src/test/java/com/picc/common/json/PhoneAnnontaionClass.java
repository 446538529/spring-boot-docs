package com.picc.common.json;

import com.picc.common.json.annotation.MuilPhoneMask;
import com.picc.common.json.annotation.PhoneMask;

public class PhoneAnnontaionClass {
	@PhoneMask
	private String phone = "18666028746";
	

	@MuilPhoneMask
	private String phone2 = "18666028741,18666028742,18666028743";

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
}
