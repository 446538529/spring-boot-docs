package com.picc.common.json;

import org.junit.Test;

import com.alibaba.fastjson.JSON;

public class TestJsonAnnontaion {
	
	@Test
	public void testGetAnnotaion() throws Exception {
		FastJsonMaskValueFilter filter = new FastJsonMaskValueFilter();
		filter.addMaskFilter(new PhoneMaskFilter());
		
		FastJsonMaskSerializeConfig config = new FastJsonMaskSerializeConfig();
		
		String val = JSON.toJSONString(new PhoneAnnontaionClass(), config);
		System.out.println(val);
	}
}
