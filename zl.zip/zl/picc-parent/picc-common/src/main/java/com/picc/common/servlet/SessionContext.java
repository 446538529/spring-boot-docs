package com.picc.common.servlet;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.ObjectUtils;

/**
 * 基于HttpSession的Context对象
 * 
 * @author Lailexin
 *
 */
public class SessionContext implements Context {

	public static final String DEFAULT_SESSION_USER_KEY = "PICC_SESSION_USER";

	private String sessionUserKey;

	@Override
	public void setCurrentUser(Object user) {
		final String key = ObjectUtils.defaultIfNull(sessionUserKey, DEFAULT_SESSION_USER_KEY);
		set(key, user);
	}

	@Override
	public Object getCurrentUser() {
		final String key = ObjectUtils.defaultIfNull(sessionUserKey, DEFAULT_SESSION_USER_KEY);
		return get(key);
	}

	public String getSessionUserKey() {
		return sessionUserKey;
	}

	public void setSessionUserKey(String sessionUserKey) {
		this.sessionUserKey = sessionUserKey;
	}

	@Override
	public void set(String key, Object value) {
		final HttpSession session = ContextUtils.getSession();
		if (session != null) {
			session.setAttribute(key, value);
		}
	}

	@Override
	public Object get(String key) {
		final HttpSession session = ContextUtils.getSession();
		if (session != null) {
			return session.getAttribute(key);
		} else {
			return null;
		}
	}

}
