package com.picc.common;

import java.io.Serializable;

/**
 * 公共Response消息体
 * 
 * @author LaiLeXin 2018-08-01
 *
 */
public class Resp<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final int SUCCESS = 200;

	public static final int FAIL = 400;

	public static final int ERROR = 500;

	public static final String SUCCESS_MESSAGE = "success";

	public static final String FAIL_MESSAGE = "fail";

	public static final String ERROR_MESSAGE = "error";

	public static <T> Resp<T> success() {
		return response(SUCCESS, SUCCESS_MESSAGE, null);
	}

	public static <T> Resp<T> success(T data) {
		return response(SUCCESS, SUCCESS_MESSAGE, data);
	}

	public static <T> Resp<T> fail() {
		return response(FAIL, FAIL_MESSAGE, null);
	}

	public static <T> Resp<T> fail(String msg) {
		return response(FAIL, msg, null);
	}

	public static <T> Resp<T> error() {
		return response(ERROR, ERROR_MESSAGE, null);
	}

	public static <T> Resp<T> error(String msg) {
		return response(ERROR, msg, null);
	}

	public static <T> Resp<T> response(int code, String msg) {
		return response(code, msg, null);
	}

	public static <T> Resp<T> response(int code, String msg, T data) {
		Resp<T> resp = new Resp<T>();
		resp.setCode(code);
		resp.setMsg(msg);
		resp.setData(data);
		return resp;
	}

	private int code;

	private String msg;

	private T data;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

}
