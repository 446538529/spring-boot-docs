package com.picc.common.json;

import org.apache.commons.lang3.StringUtils;

import com.picc.common.json.annotation.PhoneMask;

public class PhoneMaskFilter implements MaskFilter {

	@Override
	public boolean support(Object annotation) {
		return annotation instanceof PhoneMask;
	}
	
	@Override
	public String process(String value, Object annotation) {
		PhoneMask mask = (PhoneMask) annotation;
		return StringUtils.replacePattern(value, mask.value(), mask.replacement());
	}

}
