package com.picc.common.json;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.serializer.BeanContext;
import com.alibaba.fastjson.serializer.ContextValueFilter;

public class FastJsonMaskValueFilter implements ContextValueFilter {

	private List<MaskFilter> maskFilters;

	@Override
	public Object process(BeanContext context, Object object, String name, Object value) {
		if (value instanceof String && context != null && context.getField() != null) {
			return process(context.getField(), (String) value);
		}
		return value;
	}

	private String process(Field field, String value) {

		Annotation[] annotations = field.getAnnotations();
		if (maskFilters == null || annotations.length == 0) {
			return value;
		}

		for (MaskFilter filter : maskFilters) {
			for (Annotation annotation : annotations) {
				if (filter.support(annotation)) {
					return filter.process(value, annotation);
				}
			}
		}

		return value;
	}
	
	public void addMaskFilter(MaskFilter filter) {
		if (maskFilters == null) {
			maskFilters = new ArrayList<>();
		}
		maskFilters.add(filter);
	}

	public List<MaskFilter> getMaskFilters() {
		return maskFilters;
	}

	public void setMaskFilters(List<MaskFilter> maskFilters) {
		this.maskFilters = maskFilters;
	}
}
