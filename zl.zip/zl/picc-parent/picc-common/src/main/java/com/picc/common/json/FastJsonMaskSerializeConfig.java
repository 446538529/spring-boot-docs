package com.picc.common.json;

import com.alibaba.fastjson.serializer.ObjectSerializer;
import com.alibaba.fastjson.serializer.SerializeConfig;

public class FastJsonMaskSerializeConfig extends SerializeConfig {

	private FastJsonMaskValueFilter fastJsonMaskValueFilter;
	
	public FastJsonMaskSerializeConfig() {
		this.fastJsonMaskValueFilter = new FastJsonMaskValueFilter();
		fastJsonMaskValueFilter.addMaskFilter(new PhoneMaskFilter());
		fastJsonMaskValueFilter.addMaskFilter(new IdentifyMaskFilter());
		fastJsonMaskValueFilter.addMaskFilter(new MuilPhoneMaskFilter());
	}
	
	@Override
	public ObjectSerializer getObjectWriter(Class<?> clazz) {
		
		ObjectSerializer writer = get(clazz);
		
		if (writer == null) {
			writer = super.getObjectWriter(clazz);
			if (fastJsonMaskValueFilter != null) {
				super.addFilter(clazz, fastJsonMaskValueFilter);
			}
		}
		return writer;
	}

	public FastJsonMaskValueFilter getFastJsonMaskValueFilter() {
		return fastJsonMaskValueFilter;
	}

	public void setFastJsonMaskValueFilter(FastJsonMaskValueFilter fastJsonMaskValueFilter) {
		this.fastJsonMaskValueFilter = fastJsonMaskValueFilter;
	}
	
}
