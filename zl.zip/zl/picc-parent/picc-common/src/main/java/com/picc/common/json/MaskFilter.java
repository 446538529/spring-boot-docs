package com.picc.common.json;

public interface MaskFilter {
	
	public boolean support(Object annotation);
	
	public String process(String value, Object annotation);

}
