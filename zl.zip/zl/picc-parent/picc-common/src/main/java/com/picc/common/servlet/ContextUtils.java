package com.picc.common.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class ContextUtils {
	
	/**
	 * 获取  HttpServletRequest 对象
	 * @return {@link HttpServletRequest}
	 */
	public static HttpServletRequest getRequest() {
		if (RequestContextHolder.getRequestAttributes() != null) {
			return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		} else {
			return null;
		}
	}

	/**
	 * 获取 HttpServletResponse 对象
	 * @return {@link HttpServletResponse}
	 */
	public static HttpServletResponse getResponse() {
		if (RequestContextHolder.getRequestAttributes() != null) {
			return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
		} else {
			return null;
		}
	}
	
	/**
	 * 获取 HttpSession 对象
	 * @return {@link HttpSession}
	 */
	public static HttpSession getSession() {
		HttpServletRequest req = getRequest();
		if (req != null) {
			return req.getSession();
		} else {
			return null;
		}
	}

}
