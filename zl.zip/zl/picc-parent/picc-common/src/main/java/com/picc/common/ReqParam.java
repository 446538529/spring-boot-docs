package com.picc.common;

import java.io.Serializable;

/**
 * 公共请求体
 * @author lailexin 2018-08-02
 *
 */
public interface ReqParam extends Serializable {

}
