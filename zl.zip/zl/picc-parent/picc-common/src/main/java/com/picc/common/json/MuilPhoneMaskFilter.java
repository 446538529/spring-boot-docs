package com.picc.common.json;

import org.apache.commons.lang3.StringUtils;

import com.picc.common.json.annotation.MuilPhoneMask;

public class MuilPhoneMaskFilter implements MaskFilter {

	@Override
	public boolean support(Object annotation) {
		return annotation instanceof MuilPhoneMask;
	}
	
	@Override
	public String process(String value, Object annotation) {
		MuilPhoneMask mask = (MuilPhoneMask) annotation;
		
		// StringTokenizer
		
		String[] phones = value.split(StringUtils.join(mask.split(), "|"));
		for (int i = 0; i < phones.length; i++) {
			phones[i] = StringUtils.replacePattern(phones[i], mask.value(), mask.replacement());
		}
		return StringUtils.join(phones, mask.split()[0]);
	}

}
