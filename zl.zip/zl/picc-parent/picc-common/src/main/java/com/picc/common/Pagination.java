package com.picc.common;

import java.io.Serializable;
import java.util.List;

import com.github.pagehelper.PageInfo;

/**
 * 分页
 * 
 * @author lailexin 2018-08-02
 *
 */
public class Pagination<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	public Pagination() {

	}

	public Pagination(int pageIndex, int pageSize, long total, List<T> list) {
		this.pageIndex = pageIndex;
		this.pageSize = pageSize;
		this.total = total;
		this.list = list;
	}
	
	public Pagination(PageInfo<T> pageInfo) {
		this.pageIndex = pageInfo.getPageNum();
		this.pageSize = pageInfo.getPageSize();
		this.total = pageInfo.getTotal();
		this.list = pageInfo.getList();
	}

	private int pageIndex;

	private int pageSize;

	private long total;

	private List<T> list;

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}
}
