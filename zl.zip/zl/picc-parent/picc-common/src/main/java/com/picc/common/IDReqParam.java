package com.picc.common;

/**
 * ID Request Parameter
 * @author LaiLexin
 * @date 2018-08-21
 */
public class IDReqParam implements ReqParam {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getInteger() {
		try {
			return Integer.parseInt(id);
		} catch (Exception e) {
			return null;
		}
	}

	public Long getLong() {
		try {
			return Long.parseLong(id);
		} catch (Exception e) {
			return null;
		}
	}

}
