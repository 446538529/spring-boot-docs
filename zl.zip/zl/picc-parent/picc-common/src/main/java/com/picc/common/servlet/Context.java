package com.picc.common.servlet;

public interface Context {

	/**
	 * 设置当前登录用户信息
	 * @param user
	 */
	public void setCurrentUser(Object user);
	
	/**
	 * 获取当前登录用户信息
	 * @return
	 */
	public Object getCurrentUser();
	
	/**
	 * 设置上下文属性
	 * @param key
	 * @param value
	 */
	public void set(String key, Object value);
	
	/**
	 * 获取上下文值
	 * @param key
	 * @return
	 */
	public Object get(String key);
	
}
