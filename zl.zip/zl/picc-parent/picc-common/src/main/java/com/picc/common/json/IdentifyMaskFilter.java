package com.picc.common.json;

import org.apache.commons.lang3.StringUtils;

import com.picc.common.json.annotation.IdentifyMask;

public class IdentifyMaskFilter implements MaskFilter {

	@Override
	public String process(String value, Object annotation) {
		IdentifyMask mask = (IdentifyMask) annotation;
		return StringUtils.replacePattern(value, mask.value(), mask.replacement());
	}

	@Override
	public boolean support(Object annotation) {
		return annotation instanceof IdentifyMask;
	}

}
