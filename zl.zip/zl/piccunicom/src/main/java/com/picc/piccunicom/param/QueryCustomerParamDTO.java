package com.picc.piccunicom.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

@ApiModel("查询客户列表")
public class QueryCustomerParamDTO implements Serializable{

    @ApiModelProperty("省编码")
    private Integer provinceCode;
    @ApiModelProperty("市编码")
    private Integer cityCode;
    @ApiModelProperty("客户姓名")
    private String customerName;
    @ApiModelProperty("提交时间下限")
    private Date submitMinTime;
    @ApiModelProperty("提交时间上限")
    private Date submitMaxTime;
    @ApiModelProperty("所属企业名称")
    private String comName;
    @ApiModelProperty("客户ID")
    private String customerID;
    @ApiModelProperty("资质审核状态：0.待提交;1.待审核;2.审核通过;3.审核未通过")
    private Integer auditStatus;
    @ApiModelProperty("投保状态：0.待投保;1.已投保;2.已终保")
    private Integer renewType;
    @ApiModelProperty("查询类型：0.资质申请页;1.投保清单页")
    private Integer queryType;
    @ApiModelProperty("操作指向：0.联通;1.人保")
    private Integer operateOption;
    @ApiModelProperty("当前页")
    private Integer pageNum=1;
    @ApiModelProperty("页大小")
    private Integer pageSize=10;

    private String submitterCode;//资质申请提交人

    /**
     * 需要转换一下 不直接传数据库字段
     */
    @ApiModelProperty("排序字段：")
    private String orderByField;//排序字段

    public Integer getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(Integer provinceCode) {
        this.provinceCode = provinceCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Date getSubmitMinTime() {
        return submitMinTime;
    }

    public void setSubmitMinTime(Date submitMinTime) {
        this.submitMinTime = submitMinTime;
    }

    public Date getSubmitMaxTime() {
        return submitMaxTime;
    }

    public void setSubmitMaxTime(Date submitMaxTime) {
        this.submitMaxTime = submitMaxTime;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public Integer getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus) {
        this.auditStatus = auditStatus;
    }

    public Integer getRenewType() {
        return renewType;
    }

    public void setRenewType(Integer renewType) {
        this.renewType = renewType;
    }

    public Integer getQueryType() {
        return queryType;
    }

    public void setQueryType(Integer queryType) {
        this.queryType = queryType;
    }

    public Integer getOperateOption() {
        return operateOption;
    }

    public void setOperateOption(Integer operateOption) {
        this.operateOption = operateOption;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getSubmitterCode() {
        return submitterCode;
    }

    public void setSubmitterCode(String submitterCode) {
        this.submitterCode = submitterCode;
    }

    public String getOrderByField() {
        return orderByField;
    }

    public void setOrderByField(String orderByField) {
        this.orderByField = orderByField;
    }
}
