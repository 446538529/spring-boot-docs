package com.picc.piccunicom.utils;

/** 常量类 **/
public interface Constants {

    /** 企业类型 **/
    enum CompanyType {
        OTHERS(0, "其他"), GOV(1, "政府单位"), Institution(2, "事业单位"), StateOwned(3, "国企"), Private(4, "私企"), Foreign(5,
                "外企");
        private int code;
        private String value;

        private CompanyType(int code, String value) {
            this.code = code;
            this.value = value;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /** 审核状态 **/
    enum AuditStatus {
        NONE(0, "待提交"), ING(1, "待审核"), PASS(2, "审核通过"), FAIL(0, "审核未通过");

        private int code;
        private String value;

        private AuditStatus(int code, String value) {
            this.code = code;
            this.value = value;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /** 投保状态 **/
    enum RenewType {
        NONE(0, "待投保"), DONE(1, "已投保"), END(2, "已终保");

        private int code;
        private String value;

        private RenewType(int code, String value) {
            this.code = code;
            this.value = value;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /** 理赔状态 **/
    enum ClaimStatus {
        NONE(0, "未审核"), AUDITING(1, "审核中"), FAIL(2, "审核退回"), CLAIMING(2, "理赔中"), END(2, "理赔完成");

        private int code;
        private String value;

        private ClaimStatus(int code, String value) {
            this.code = code;
            this.value = value;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
    enum IdentifyType{
        ID_CARD(0,"身份证");
        private int code;
        private String value;

        private IdentifyType(int code, String value) {
            this.code = code;
            this.value = value;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

}
