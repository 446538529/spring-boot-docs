package com.picc.piccunicom.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

@ApiModel(description = "it_unicom_customer_info")
public class CustomerInfo implements Serializable {

    @ApiModelProperty("客户id")
    private String customerID;

    @ApiModelProperty("企业id")
    private String comID;

    @ApiModelProperty("客户姓名")
    private String customerName;

    @ApiModelProperty("客户证件号")
    private String identifyNumber;

    @ApiModelProperty("证件类型")
    private Integer identifyType;

    @ApiModelProperty("联系电话")
    private String phone;

    @ApiModelProperty("所属省份code")
    private Integer provinceCode;

    @ApiModelProperty("所属地市code")
    private Integer cityCode;

    @ApiModelProperty("社保账号")
    private String socialSecurityNO;

    @ApiModelProperty("身份证正面")
    private String identityCardFrontURL;

    @ApiModelProperty("身份证背面")
    private String identityCardBackURL;

    @ApiModelProperty("工作证图片")
    private String workCardURL;

    @ApiModelProperty("社保卡图片")
    private String securityCardURL;

    @ApiModelProperty("有效状态")
    private Integer validStatus;

    @ApiModelProperty("创建人")
    private String creatorCode;

    @ApiModelProperty("创建时间")
    private Date insertTimeForHis;

    @ApiModelProperty("修改人")
    private String updaterCode;

    @ApiModelProperty("修改时间")
    private Date updateTimeForHis;

    private static final long serialVersionUID = 1L;

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getComID() {
        return comID;
    }

    public void setComID(String comID) {
        this.comID = comID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customername) {
        this.customerName = customername;
    }

    public String getIdentifyNumber() {
        return identifyNumber;
    }

    public void setIdentifyNumber(String identifynumber) {
        this.identifyNumber = identifynumber;
    }

    public Integer getIdentifyType() {
        return identifyType;
    }

    public void setIdentifyType(Integer identifyType) {
        this.identifyType = identifyType;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(Integer provincecode) {
        this.provinceCode = provincecode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer citycode) {
        this.cityCode = citycode;
    }

    public String getSocialSecurityNO() {
        return socialSecurityNO;
    }

    public void setSocialSecurityNO(String socialsecurityno) {
        this.socialSecurityNO = socialsecurityno;
    }

    public String getIdentityCardFrontURL() {
        return identityCardFrontURL;
    }

    public void setIdentityCardFrontURL(String identitycardfronturl) {
        this.identityCardFrontURL = identitycardfronturl;
    }

    public String getIdentityCardBackURL() {
        return identityCardBackURL;
    }

    public void setIdentityCardBackURL(String identitycardbackurl) {
        this.identityCardBackURL = identitycardbackurl;
    }

    public String getWorkCardURL() {
        return workCardURL;
    }

    public void setWorkCardURL(String workcardurl) {
        this.workCardURL = workcardurl;
    }

    public String getSecurityCardURL() {
        return securityCardURL;
    }

    public void setSecurityCardURL(String securitycardurl) {
        this.securityCardURL = securitycardurl;
    }

    public Integer getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Integer validstatus) {
        this.validStatus = validstatus;
    }

    public String getCreatorCode() {
        return creatorCode;
    }

    public void setCreatorCode(String creatorcode) {
        this.creatorCode = creatorcode;
    }

    public Date getInsertTimeForHis() {
        return insertTimeForHis;
    }

    public void setInsertTimeForHis(Date inserttimeforhis) {
        this.insertTimeForHis = inserttimeforhis;
    }

    public String getUpdaterCode() {
        return updaterCode;
    }

    public void setUpdaterCode(String updatercode) {
        this.updaterCode = updatercode;
    }

    public Date getUpdateTimeForHis() {
        return updateTimeForHis;
    }

    public void setUpdateTimeForHis(Date updatetimeforhis) {
        this.updateTimeForHis = updatetimeforhis;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", customerid=").append(customerID);
        sb.append(", comid=").append(comID);
        sb.append(", customername=").append(customerName);
        sb.append(", identifynumber=").append(identifyNumber);
        sb.append(", identifytype=").append(identifyType);
        sb.append(", phone=").append(phone);
        sb.append(", provincecode=").append(provinceCode);
        sb.append(", citycode=").append(cityCode);
        sb.append(", socialsecurityno=").append(socialSecurityNO);
        sb.append(", identitycardfronturl=").append(identityCardFrontURL);
        sb.append(", identitycardbackurl=").append(identityCardBackURL);
        sb.append(", workcardurl=").append(workCardURL);
        sb.append(", securitycardurl=").append(securityCardURL);
        sb.append(", validstatus=").append(validStatus);
        sb.append(", creatorcode=").append(creatorCode);
        sb.append(", inserttimeforhis=").append(insertTimeForHis);
        sb.append(", updatercode=").append(updaterCode);
        sb.append(", updatetimeforhis=").append(updateTimeForHis);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}