package com.picc.piccunicom.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

@ApiModel("查询客户列表响应")
public class QueryCustomerResp implements Serializable {

    @ApiModelProperty("订单ID")
    private String orderID;
    @ApiModelProperty("省市")
    private String area;
    @ApiModelProperty("企业名称")
    private String comName;
    @ApiModelProperty("客户姓名")
    private String customerName;
    @ApiModelProperty("证件类型")
    private Integer identifyType;
    @ApiModelProperty("证件号")
    private String identifyNumber;
    @ApiModelProperty("联系电话")
    private String phone;
    @ApiModelProperty("社保账户")
    private String socialSecurityNo;
    @ApiModelProperty("提交时间")
    private Date submitTime;
    @ApiModelProperty("提交人")
    private String submitterName;
    @ApiModelProperty("资质审核状态")
    private Integer auditStatus;
    @ApiModelProperty("资质审核人")
    private String autitorName;
    @ApiModelProperty("资质审核时间")
    private Date auditTime;
    @ApiModelProperty("投保状态")
    private Integer renewType;
    @ApiModelProperty("投保时间")
    private Date underWrittenTime;

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Integer getIdentifyType() {
        return identifyType;
    }

    public void setIdentifyType(Integer identifyType) {
        this.identifyType = identifyType;
    }

    public String getIdentifyNumber() {
        return identifyNumber;
    }

    public void setIdentifyNumber(String identifyNumber) {
        this.identifyNumber = identifyNumber;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSocialSecurityNo() {
        return socialSecurityNo;
    }

    public void setSocialSecurityNo(String socialSecurityNo) {
        this.socialSecurityNo = socialSecurityNo;
    }

    public Date getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(Date submitTime) {
        this.submitTime = submitTime;
    }

    public String getSubmitterName() {
        return submitterName;
    }

    public void setSubmitterName(String submitterName) {
        this.submitterName = submitterName;
    }

    public Integer getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getAutitorName() {
        return autitorName;
    }

    public void setAutitorName(String autitorName) {
        this.autitorName = autitorName;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public Integer getRenewType() {
        return renewType;
    }

    public void setRenewType(Integer renewType) {
        this.renewType = renewType;
    }

    public Date getUnderWrittenTime() {
        return underWrittenTime;
    }

    public void setUnderWrittenTime(Date underWrittenTime) {
        this.underWrittenTime = underWrittenTime;
    }
}

