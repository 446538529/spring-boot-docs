package com.picc.piccunicom.mybatis;

  import com.picc.utils.mybatis.generator.MyBatisGeneratorUtils;
public class DefaultGenerator {
	
	public static void main(String[] args) {
		MyBatisGeneratorUtils.generator("generator/defaultGeneratorConfig.xml", DefaultGenerator.class);
	}

}
