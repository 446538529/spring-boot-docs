package com.picc.piccunicom.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
@ApiModel("人保端审核个人客户资质")
public class AuditParamDto implements Serializable {
    @ApiModelProperty("客户ID")
    @NotNull(message = "客户ID不能为空")
    private String customerID;

    @ApiModelProperty("审核结果2.审核通过;3.审核未通过")
    @NotNull
    private Integer result;

    @ApiModelProperty("审核意见")
    private String auditReason;

    private String autitorCode;//资质审核人
    private String autitorName;
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public String getAuditReason() {
        return auditReason;
    }

    public void setAuditReason(String auditReason) {
        this.auditReason = auditReason;
    }

    public String getAutitorCode() {
        return autitorCode;
    }

    public void setAutitorCode(String autitorCode) {
        this.autitorCode = autitorCode;
    }

    public String getAutitorName() {
        return autitorName;
    }

    public void setAutitorName(String autitorName) {
        this.autitorName = autitorName;
    }
}
