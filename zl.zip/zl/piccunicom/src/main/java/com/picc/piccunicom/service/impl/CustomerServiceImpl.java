package com.picc.piccunicom.service.impl;

import com.alibaba.druid.support.json.JSONUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.picc.common.Resp;
import com.picc.piccunicom.mapper.base.AreaBaseMapper;
import com.picc.piccunicom.mapper.base.CompanyInfoBaseMapper;
import com.picc.piccunicom.mapper.base.CustomerInfoBaseMapper;
import com.picc.piccunicom.mapper.base.OrderStatusBaseMapper;
import com.picc.piccunicom.model.Area;
import com.picc.piccunicom.model.CompanyInfo;
import com.picc.piccunicom.model.CustomerInfo;
import com.picc.piccunicom.model.OrderStatus;
import com.picc.piccunicom.param.*;
import com.picc.piccunicom.resp.QueryCustomerResp;
import com.picc.piccunicom.service.CustomerService;
import com.picc.piccunicom.utils.Constants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerInfoBaseMapper customerInfoBaseMapper;
    @Autowired
    private OrderStatusBaseMapper orderStatusBaseMapper;
    @Autowired
    private CompanyInfoBaseMapper companyInfoBaseMapper;
    @Autowired
    private AreaBaseMapper areaBaseMapper;

    private Logger logger= LoggerFactory.getLogger(CustomerServiceImpl.class);
    /**
     * 新增个人客户申请
     * @param dto
     * @param files
     */
    @Override
    public void addCustomer(AddCustomerDTO dto, Map<String, String> files) {
        dto.setIdentityCardFrontURL(files.get("cardFrontImg"));
        dto.setIdentityCardBackURL(files.get("cardBackImg"));
        dto.setWorkCardURL(files.get("workCardImg"));
        dto.setSecurityCardURL(files.get("securityCardImg"));

        if(dto.getCustomerID()==null){
            //新增

            //生成客户id
            String customerId=genCustomerId(dto.getComID());
            dto.setCustomerID(customerId);
            dto.setCreateTime(new Date());
            if(dto.getCommitStatus()==0){
                //0 暂存
                dto.setAuditStatus(Constants.AuditStatus.NONE.getCode());
            }else{
                //1 提交
                dto.setAuditStatus(Constants.AuditStatus.ING.getCode());
            }
            customerInfoBaseMapper.insertCustomer(dto);
            //如果是手机端提交的，提交人为空，需要查询到企业的提交人作为个人的提交人
            if(StringUtils.isBlank(dto.getSubmitCode())){
                OrderStatus orderStatus = orderStatusBaseMapper.selectByPrimaryKey(dto.getComID());
                if(orderStatus==null){
                    throw new RuntimeException("企业不存在！");
                }
                dto.setSubmitCode(orderStatus.getSubmitterCode());
                dto.setSubmitName(orderStatus.getSubmitterName());
            }
            //todo 设置提交人姓名
            orderStatusBaseMapper.insertOrder(dto);
            logger.info("新增个人客户资质申请，{}", JSONUtils.toJSONString(dto));
      }else{
            //修改
            CustomerInfo customerInfo=new CustomerInfo();
            BeanUtils.copyProperties(dto,customerInfo);
            customerInfoBaseMapper.updateByPrimaryKeySelective(customerInfo);
            logger.info("修改个人客户资质申请，{}", JSONUtils.toJSONString(dto));
        }

    }

    @Override
    public String queryByIdentifyNo(String identifyNo) {
        return customerInfoBaseMapper.selectByIdentifyNo(identifyNo);
    }

    @Override
    public Resp<CustomerInfoDTO> queryCustomerById(String customerID) {
        if(StringUtils.isBlank(customerID)){
            throw new RuntimeException("客户ID为空");
        }
        CustomerInfo customerInfo = customerInfoBaseMapper.selectByPrimaryKey(customerID);
        if(customerInfo==null){
            throw new RuntimeException("客户不存在");
        }
        CustomerInfoDTO dto=new CustomerInfoDTO();
        BeanUtils.copyProperties(customerInfo,dto);
        if(StringUtils.isNotBlank(customerInfo.getComID())){
            CompanyInfo companyInfo = companyInfoBaseMapper.selectByPrimaryKey(customerInfo.getComID());
            if(companyInfo!=null){
                BeanUtils.copyProperties(companyInfo,dto);
                dto.setComCityCode(companyInfo.getCityCode());
                dto.setComProvinceCode(companyInfo.getProvinceCode());
            }
        }
        fillAreaInfo(dto);
        return Resp.success(dto);
    }

    @Override
    public Resp<PageInfo> queryCustomerList(QueryCustomerParamDTO dto) {
        //todo 设置排序字段转换
        PageHelper.startPage(dto.getPageNum(),dto.getPageSize());
        List<QueryCustomerResp> resp = customerInfoBaseMapper.selectCustomerList(dto);
        PageInfo<QueryCustomerResp> pageInfo=new PageInfo<>(resp);
        return Resp.success(pageInfo);
    }

    @Override
    public void submitApply(SubmitApplyParamDTO dto) {
        List<String> customerIDS=getCustomerIDList(dto.getCustomerIDS());
        orderStatusBaseMapper.batchUpdateSubmitStatus(customerIDS);
    }

    @Override
    public void auditCustomer(AuditParamDto dto) {
        orderStatusBaseMapper.auditCustomer(dto);
    }

    @Override
    public void updateSecure(UpdateSecureParamDTO dto) {
        List<String> customerIDS=getCustomerIDList(dto.getCustomerIDS());
        dto.setCustomerIDList(customerIDS);
        orderStatusBaseMapper.updateSecure(dto);
    }

    private List<String> getCustomerIDList(String strIDS) {
        return Arrays.asList(strIDS.split("-"));
    }

    /**
     * 查询省市的名称
     * @param dto
     */
    private void fillAreaInfo(CustomerInfoDTO dto) {
        if(dto.getCityCode()!=null){
            Area area = areaBaseMapper.selectByPrimaryKey(dto.getCityCode());
            if(area!=null){
                dto.setCityName(area.getName());
            }
        }
        if(dto.getProvinceCode()!=null){
            Area area = areaBaseMapper.selectByPrimaryKey(dto.getProvinceCode());
            if(area!=null){
                dto.setProvinceName(area.getName());
            }
        }

        if(dto.getComCityCode()!=null){
            Area area = areaBaseMapper.selectByPrimaryKey(dto.getComCityCode());
            if(area!=null){
                dto.setComCityName(area.getName());
            }
        }

        if(dto.getComProvinceCode()!=null){
            Area area = areaBaseMapper.selectByPrimaryKey(dto.getComProvinceCode());
            if(area!=null){
                dto.setComProvinceName(area.getName());
            }
        }
    }

    /**
     * 获取客户id  企业id(5位)+自增id（5位）
     * @param comId
     * @return
     */
    private synchronized String  genCustomerId(String comId) {
        String maxId = customerInfoBaseMapper.selectMaxId();
        Integer newId=1;
        if(maxId!=null){
            newId=Integer.parseInt(maxId)+1;
        }
        StringBuilder sb=new StringBuilder();
        sb.append(comId);
        for (int i = 0; i <5-(newId+"").length() ; i++) {
            sb.append("0");
        }
        sb.append(newId);
        return sb.toString();
    }

}
