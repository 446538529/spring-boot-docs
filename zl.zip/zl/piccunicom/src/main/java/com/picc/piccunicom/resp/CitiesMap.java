package com.picc.piccunicom.resp;

import java.util.List;

import com.picc.piccunicom.model.City;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("省份与城市列表关联集合")
public class CitiesMap {

    @ApiModelProperty("省份代码")
    private Integer provinceCode;

    @ApiModelProperty("城市列表")
    private List<City> cities;

    public Integer getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(Integer provinceCode) {
        this.provinceCode = provinceCode;
    }

    public List<City> getCities() {
        return cities;
    }

    public void setCities(List<City> citys) {
        this.cities = citys;
    }

}
