package com.picc.piccunicom.service;

import com.picc.piccunicom.resp.AreaResp;

/**
 * 省市信息接口服务
 * @author ChenYanRui
 *
 */
public interface IAreaService {

    /** 获取省市信息 **/
    AreaResp getArea();
}
