package com.picc.piccunicom.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

@ApiModel(description = "it_unicom_claim_record")
public class ClaimRecord implements Serializable {

    @ApiModelProperty("记录id")
    private Integer id;

    @ApiModelProperty("订单id")
    private Integer orderID;

    @ApiModelProperty("审核时间")
    private Date auditTime;

    @ApiModelProperty("理赔状态:1.审核中;2.审核退回;3.理赔中;4.理赔完成")
    private Integer claimStatus;

    @ApiModelProperty("驳回原因")
    private String reason;

    @ApiModelProperty("申请时间")
    private Date applyTime;

    @ApiModelProperty("有效状态")
    private Integer validStatus;

    @ApiModelProperty("创建人")
    private String creatorCode;

    @ApiModelProperty("创建时间")
    private Date insertTimeForHis;

    @ApiModelProperty("修改人")
    private String updaterCode;

    @ApiModelProperty("修改时间")
    private Date updateTimeForHis;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderID() {
        return orderID;
    }

    public void setOrderID(Integer orderid) {
        this.orderID = orderid;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date audittime) {
        this.auditTime = audittime;
    }

    public Integer getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(Integer claimstatus) {
        this.claimStatus = claimstatus;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applytime) {
        this.applyTime = applytime;
    }

    public Integer getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Integer validstatus) {
        this.validStatus = validstatus;
    }

    public String getCreatorCode() {
        return creatorCode;
    }

    public void setCreatorCode(String creatorcode) {
        this.creatorCode = creatorcode;
    }

    public Date getInsertTimeForHis() {
        return insertTimeForHis;
    }

    public void setInsertTimeForHis(Date inserttimeforhis) {
        this.insertTimeForHis = inserttimeforhis;
    }

    public String getUpdaterCode() {
        return updaterCode;
    }

    public void setUpdaterCode(String updatercode) {
        this.updaterCode = updatercode;
    }

    public Date getUpdateTimeForHis() {
        return updateTimeForHis;
    }

    public void setUpdateTimeForHis(Date updatetimeforhis) {
        this.updateTimeForHis = updatetimeforhis;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", orderid=").append(orderID);
        sb.append(", audittime=").append(auditTime);
        sb.append(", claimstatus=").append(claimStatus);
        sb.append(", reason=").append(reason);
        sb.append(", applytime=").append(applyTime);
        sb.append(", validstatus=").append(validStatus);
        sb.append(", creatorcode=").append(creatorCode);
        sb.append(", inserttimeforhis=").append(insertTimeForHis);
        sb.append(", updatercode=").append(updaterCode);
        sb.append(", updatetimeforhis=").append(updateTimeForHis);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}