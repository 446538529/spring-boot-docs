package com.picc.piccunicom.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel("批量提交申请")
public class SubmitApplyParamDTO implements Serializable {
    @ApiModelProperty("批量客户ID拼接，'-'隔开")
    @NotBlank(message = "客户ID为空")
    private String customerIDS;

    public String getCustomerIDS() {
        return customerIDS;
    }

    public void setCustomerIDS(String customerIDS) {
        this.customerIDS = customerIDS;
    }
}
