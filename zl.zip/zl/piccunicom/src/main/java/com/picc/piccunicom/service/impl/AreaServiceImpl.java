package com.picc.piccunicom.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.picc.piccunicom.mapper.base.AreaBaseMapper;
import com.picc.piccunicom.model.Province;
import com.picc.piccunicom.resp.AreaResp;
import com.picc.piccunicom.resp.CitiesMap;
import com.picc.piccunicom.service.IAreaService;

@Service("areaService")
public class AreaServiceImpl implements IAreaService {

    @Autowired
    private AreaBaseMapper areaBaseMapper;

    /** 获取省市信息 **/
    @Override
    @Cacheable("areaCache")
    public AreaResp getArea() {
        AreaResp areaResp = new AreaResp();
        List<CitiesMap> citiesMaps = new LinkedList<CitiesMap>();
        areaResp.setCitiesMaps(citiesMaps);
        // 加载省份信息, 包含省内城市信息
        List<Province> provinces = areaBaseMapper.getProvinces();
        areaResp.setProvinces(provinces);
        // 构造Map<省份code, 该省城市列表>
        provinces.forEach((province) ->{
            CitiesMap citiesMap = new CitiesMap();
            citiesMap.setProvinceCode(province.getProvinceCode());
            citiesMap.setCities(province.getCities());
            citiesMaps.add(citiesMap);
        });
        return areaResp;
    }

}
