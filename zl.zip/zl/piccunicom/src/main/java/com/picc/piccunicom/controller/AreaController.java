package com.picc.piccunicom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.picc.common.Resp;
import com.picc.piccunicom.resp.AreaResp;
import com.picc.piccunicom.service.IAreaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api("省市信息接口")
@RestController
public class AreaController {
    
    @Autowired
    private IAreaService areaService;

    @ApiOperation("获取省市信息")
    @GetMapping("/area")
    public Resp<AreaResp> getArea() {
        return Resp.success(areaService.getArea());
    }
}
