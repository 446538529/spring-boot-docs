package com.picc.piccunicom.controller;

import com.picc.piccunicom.common.TestParam;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.picc.common.Resp;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 测试接口
 * @author Lailexin
 *
 */
@Controller
@ResponseBody
@Api("测试")
public class TestController {

	@PostMapping("/test")
	@ApiOperation("POST测试方法")
	public Resp<Object> postTest(@RequestBody TestParam param) {
		return Resp.success();
	}
	
	@GetMapping("/test")
	@ApiOperation("GET测试方法")
	public Resp<Object> getTest(@RequestParam Integer age) {
		int a=1/age;
		return Resp.success();
	}
	
}
