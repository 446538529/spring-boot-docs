package com.picc.piccunicom.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

@ApiModel(description = "it_unicom_claim_info")
public class ClaimInfo implements Serializable {

    @ApiModelProperty("订单id")
    private String orderID;

    @ApiModelProperty("理赔类型:1.个人;2.企业")
    private Integer claimType;

    @ApiModelProperty("申请人姓名")
    private String applyName;

    @ApiModelProperty("联系电话")
    private String phone;

    @ApiModelProperty("理赔申请单位")
    private String comName;

    @ApiModelProperty("案发经过")
    private String description;

    @ApiModelProperty("有效状态")
    private Integer validStatus;

    @ApiModelProperty("创建人")
    private String creatorCode;

    @ApiModelProperty("创建时间")
    private Date insertTimeForHis;

    @ApiModelProperty("修改人")
    private String updaterCode;

    @ApiModelProperty("修改时间")
    private Date updateTimeForHis;

    private static final long serialVersionUID = 1L;

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getClaimType() {
        return claimType;
    }

    public void setClaimType(Integer claimtype) {
        this.claimType = claimtype;
    }

    public String getApplyName() {
        return applyName;
    }

    public void setApplyName(String applyname) {
        this.applyName = applyname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comname) {
        this.comName = comname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Integer validstatus) {
        this.validStatus = validstatus;
    }

    public String getCreatorCode() {
        return creatorCode;
    }

    public void setCreatorCode(String creatorcode) {
        this.creatorCode = creatorcode;
    }

    public Date getInsertTimeForHis() {
        return insertTimeForHis;
    }

    public void setInsertTimeForHis(Date inserttimeforhis) {
        this.insertTimeForHis = inserttimeforhis;
    }

    public String getUpdaterCode() {
        return updaterCode;
    }

    public void setUpdaterCode(String updatercode) {
        this.updaterCode = updatercode;
    }

    public Date getUpdateTimeForHis() {
        return updateTimeForHis;
    }

    public void setUpdateTimeForHis(Date updatetimeforhis) {
        this.updateTimeForHis = updatetimeforhis;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", orderid=").append(orderID);
        sb.append(", claimtype=").append(claimType);
        sb.append(", applyname=").append(applyName);
        sb.append(", phone=").append(phone);
        sb.append(", comname=").append(comName);
        sb.append(", description=").append(description);
        sb.append(", validstatus=").append(validStatus);
        sb.append(", creatorcode=").append(creatorCode);
        sb.append(", inserttimeforhis=").append(insertTimeForHis);
        sb.append(", updatercode=").append(updaterCode);
        sb.append(", updatetimeforhis=").append(updateTimeForHis);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}