package com.picc.piccunicom.controller;

import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.picc.common.Resp;
import com.picc.piccunicom.param.*;
import com.picc.piccunicom.service.CustomerService;
import com.picc.piccunicom.service.OssService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;
@Api("个人客户管理")
@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private OssService ossService;
    @Autowired
    private CustomerService customerService;
    /**
     * 新增个人客户申请
     * @param customerDTO
     * @param request
     * @return
     */
    @ApiOperation("新增或者修改客户资质申请")
    @PostMapping("/addCustomer")
    public Resp addCustomer(AddCustomerDTO customerDTO, HttpServletRequest request) throws IOException {

        //如果新增，先检验身份证
        if(customerDTO.getCustomerID()==null){
            String customerID = customerService.queryByIdentifyNo(customerDTO.getIdentifyNumber());
            if(StringUtils.isNotBlank(customerID)){
                throw new RuntimeException("该客户已经申请过资质！");
            }
        }

        //文件映射
        Map<String,String> files= Maps.newHashMap();
        if(request instanceof MultipartHttpServletRequest){
            MultipartHttpServletRequest multipartHttpServletRequest=(MultipartHttpServletRequest)request;
            Map<String, MultipartFile> fileMap = multipartHttpServletRequest.getFileMap();
            //循环处理文件
            for (Map.Entry<String, MultipartFile> entry : fileMap.entrySet()) {
                ByteArrayInputStream inputStream=new ByteArrayInputStream(entry.getValue().getBytes());
                String url = ossService.put(entry.getValue().getOriginalFilename(), inputStream);
                files.put(entry.getKey(),url);
            }
        }
        //todo 操作人 上下文取
        //customerDTO.setSubmitCode("12454");
        customerService.addCustomer(customerDTO,files);
        return Resp.success();
   }

    /**
     * 查询个人客户信息
     * @param customerID
     * @return
     */
   @ApiOperation("查询客户详情")
   @GetMapping("/queryById/{customerID}")
   public Resp<CustomerInfoDTO> queryCustomerById(@PathVariable String customerID){
        return customerService.queryCustomerById(customerID);
   }

    /**
     * 查询客户列表
     * @param dto
     * @return
     */
   @ApiOperation("查询客户列表")
   @PostMapping("/queryCustomerList")
   public Resp<PageInfo> queryCustomerList(@RequestBody QueryCustomerParamDTO dto){
        if(new Integer(0).equals(dto.getQueryType())&&new Integer(0).equals(dto.getOperateOption())){
           //todo 如果是联通端查询资质申请列表，查询登录人的角色，客户经理的话设置一下当前登陆人的code
            //dto.setSubmitterCode("set");
        }
       return customerService.queryCustomerList(dto);
   }

    /**
     * 联通批量提交客户申请
     * @param dto
     * @return
     */
   @ApiOperation("批量提交申请")
   @PostMapping("/batchUpdateSubmit")
   public Resp submitApply(@RequestBody SubmitApplyParamDTO dto){
       customerService.submitApply(dto);
       return Resp.success();
   }

   @ApiOperation("人保端审核个人客户")
   @PostMapping("/auditCustomer")
   public Resp auditCustomer(@RequestBody AuditParamDto dto){
       //todo 上下文设置审核人

       customerService.auditCustomer(dto);
       return Resp.success();
   }

   @ApiOperation("人保端更新投保状态")
   @PostMapping("/updateSecure")
   public Resp updateSecure(@RequestBody UpdateSecureParamDTO dto){
       //todo 上下文设置投保更新人

       customerService.updateSecure(dto);
       return Resp.success();
   }


}
