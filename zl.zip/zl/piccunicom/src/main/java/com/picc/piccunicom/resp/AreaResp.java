package com.picc.piccunicom.resp;

import java.util.List;

import com.picc.piccunicom.model.Province;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("省市信息")
public class AreaResp {

    @ApiModelProperty("省份信息")
    private List<Province> provinces;

    @ApiModelProperty("城市信息")
    private List<CitiesMap> citiesMaps;

    public List<Province> getProvinces() {
        return provinces;
    }

    public void setProvinces(List<Province> provinces) {
        this.provinces = provinces;
    }

    public List<CitiesMap> getCitiesMaps() {
        return citiesMaps;
    }

    public void setCitiesMaps(List<CitiesMap> cities) {
        this.citiesMaps = cities;
    }

}
