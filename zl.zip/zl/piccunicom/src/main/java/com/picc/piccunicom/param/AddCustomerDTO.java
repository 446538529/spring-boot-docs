package com.picc.piccunicom.param;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * 个人客户资质申请
 */
public class AddCustomerDTO implements Serializable {
    private String customerID;
    @NotNull(message = "企业ID不能为空")
    private String comID;
    @NotBlank(message = "客户姓名不能为空")
    private String customerName;
    @NotNull(message = "证件类型不能为空")
    private Integer identifyType;
    @NotBlank(message = "证件号码不能为空")
    private String identifyNumber;
    @NotBlank(message = "联系电话不能为空")
    private String phone;
    @NotBlank(message = "省份不能为空")
    private String provinceCode;
    @NotBlank(message = "城市不能为空")
    private String cityCode;
    @NotBlank(message = "社保账号不能为空")
    private String socialSecurityNo;
    @NotNull(message = "提交状态不能为空")
    private Integer commitStatus;
    private String identityCardFrontURL;
    private String identityCardBackURL;
    private String workCardURL;
    private String securityCardURL;
    //操作人ID
    private Integer operaterID;
    private String submitCode;
    private String submitName;
    private Date createTime;
    //资质审核状态
    private Integer auditStatus;

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getComID() {
        return comID;
    }

    public void setComID(String comID) {
        this.comID = comID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Integer getIdentifyType() {
        return identifyType;
    }

    public void setIdentifyType(Integer identifyType) {
        this.identifyType = identifyType;
    }

    public String getIdentifyNumber() {
        return identifyNumber;
    }

    public void setIdentifyNumber(String identifyNumber) {
        this.identifyNumber = identifyNumber;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getSocialSecurityNo() {
        return socialSecurityNo;
    }

    public void setSocialSecurityNo(String socialSecurityNo) {
        this.socialSecurityNo = socialSecurityNo;
    }

    public Integer getCommitStatus() {
        return commitStatus;
    }

    public void setCommitStatus(Integer commitStatus) {
        this.commitStatus = commitStatus;
    }

    public String getIdentityCardFrontURL() {
        return identityCardFrontURL;
    }

    public void setIdentityCardFrontURL(String identityCardFrontURL) {
        this.identityCardFrontURL = identityCardFrontURL;
    }

    public String getIdentityCardBackURL() {
        return identityCardBackURL;
    }

    public void setIdentityCardBackURL(String identityCardBackURL) {
        this.identityCardBackURL = identityCardBackURL;
    }

    public String getWorkCardURL() {
        return workCardURL;
    }

    public void setWorkCardURL(String workCardURL) {
        this.workCardURL = workCardURL;
    }

    public String getSecurityCardURL() {
        return securityCardURL;
    }

    public void setSecurityCardURL(String securityCardURL) {
        this.securityCardURL = securityCardURL;
    }

    public Integer getOperaterID() {
        return operaterID;
    }

    public void setOperaterID(Integer operaterID) {
        this.operaterID = operaterID;
    }

    public String getSubmitCode() {
        return submitCode;
    }

    public void setSubmitCode(String submitCode) {
        this.submitCode = submitCode;
    }

    public String getSubmitName() {
        return submitName;
    }

    public void setSubmitName(String submitName) {
        this.submitName = submitName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus) {
        this.auditStatus = auditStatus;
    }
}

