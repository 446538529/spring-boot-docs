package com.picc.piccunicom.exception;

import com.picc.common.Resp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常捕捉
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(value = {Exception.class})
    public Resp defaultErrorHandler(Exception e){
        logger.error(e.getMessage(),e);
        String errorMesssage = "";
        if (e instanceof MethodArgumentNotValidException){
            MethodArgumentNotValidException validException = (MethodArgumentNotValidException) e;
            BindingResult bindingResult = validException.getBindingResult();
            for (FieldError fieldError : bindingResult.getFieldErrors()) {
                errorMesssage = fieldError.getDefaultMessage() + ", ";
            }
        }else{
            errorMesssage += e.getMessage();
        }
        Resp<Object> response = Resp.response(9999, errorMesssage, null);
        return response;
    }
}
