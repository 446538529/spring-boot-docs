package com.picc.piccunicom.aop;

import com.picc.piccunicom.common.ValidatedGroups;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Set;

@Component
@Aspect
public class ReqParamValidAspect {
    private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    //方法验证
    private final Validator beanValidator = factory.getValidator();

    //此处也可以使用切入点
    @Before("execution (* com.picc.piccunicom.controller..*(..))")
    public void doValid(JoinPoint joinPoint) throws Throwable {
        //获取方法参数
        Object[] args = joinPoint.getArgs();
        //获取切入方法参数
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        Parameter[] parameters = method.getParameters();

        StringBuilder sb = new StringBuilder();

        Set<ConstraintViolation<Object>> validate = null;
        for (int i = 0; i < args.length; i++) {
            if (args[i] != null){
                Parameter parameter = parameters[i];
                ValidatedGroups validGroup = parameter.getAnnotation(ValidatedGroups.class);
                if (validGroup != null){
                    validate = beanValidator.validate(args[i],validGroup.value());
                }else {
                    validate = beanValidator.validate(args[i]);
                }
                for (ConstraintViolation<Object> next : validate) {
                    sb.append(next.getPropertyPath()).append(next.getMessage()).append("---");
                }
            }
        }

        if (sb.length() > 0) {
            throw new RuntimeException(sb.toString());
        }
    }

}
