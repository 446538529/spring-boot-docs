package com.picc.piccunicom.service;


import java.io.InputStream;

public interface OssService {
    /**
     * 上传文件到oss返回url
     * @param fileName
     * @param inputStream
     * @return url
     */
    String put(String fileName, InputStream inputStream);
}
