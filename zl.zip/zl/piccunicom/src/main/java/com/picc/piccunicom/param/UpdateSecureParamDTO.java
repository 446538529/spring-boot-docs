package com.picc.piccunicom.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@ApiModel("人保端更新投保状态")
public class UpdateSecureParamDTO implements Serializable{

    @ApiModelProperty("投保状态")
    @NotNull
    private Integer renewType;

    @ApiModelProperty("客户批量ID,'-'隔开")
    @NotBlank(message = "客户ID不能为空")
    private String customerIDS;

    private String prpUpdaterCode;
    private String prpUpdaterName;
    private List<String> customerIDList;
    public Integer getRenewType() {
        return renewType;
    }

    public void setRenewType(Integer renewType) {
        this.renewType = renewType;
    }

    public String getCustomerIDS() {
        return customerIDS;
    }

    public void setCustomerIDS(String customerIDS) {
        this.customerIDS = customerIDS;
    }

    public String getPrpUpdaterCode() {
        return prpUpdaterCode;
    }

    public void setPrpUpdaterCode(String prpUpdaterCode) {
        this.prpUpdaterCode = prpUpdaterCode;
    }

    public String getPrpUpdaterName() {
        return prpUpdaterName;
    }

    public void setPrpUpdaterName(String prpUpdaterName) {
        this.prpUpdaterName = prpUpdaterName;
    }

    public List<String> getCustomerIDList() {
        return customerIDList;
    }

    public void setCustomerIDList(List<String> customerIDList) {
        this.customerIDList = customerIDList;
    }
}
