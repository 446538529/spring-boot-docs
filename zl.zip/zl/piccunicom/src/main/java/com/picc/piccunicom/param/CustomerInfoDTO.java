package com.picc.piccunicom.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
@ApiModel("个人客户信息")
public class CustomerInfoDTO implements Serializable {
    @ApiModelProperty("客户id")
    private String customerID;

    @ApiModelProperty("企业id")
    private Integer comID;

    @ApiModelProperty("客户姓名")
    private String customerName;

    @ApiModelProperty("客户证件号")
    private String identifyNumber;

    @ApiModelProperty("证件类型")
    private Integer identifyType;

    @ApiModelProperty("联系电话")
    private String phone;

    @ApiModelProperty("所属省份code")
    private Integer provinceCode;

    @ApiModelProperty("客户所在省份名称")
    private String provinceName;

    @ApiModelProperty("所属地市code")
    private Integer cityCode;

    @ApiModelProperty("客户所在城市名称")
    private String cityName;

    @ApiModelProperty("社保账号")
    private String socialSecurityNO;

    @ApiModelProperty("身份证正面")
    private String identityCardFrontURL;

    @ApiModelProperty("身份证背面")
    private String identityCardBackURL;

    @ApiModelProperty("工作证图片")
    private String workCardURL;

    @ApiModelProperty("社保卡图片")
    private String securityCardURL;

    @ApiModelProperty("公司名称")
    private String comName;

    @ApiModelProperty("公司所在城市code")
    private Integer comCityCode;

    @ApiModelProperty("公司所在城市名称")
    private String comCityName;

    @ApiModelProperty("公司所在省份code")
    private Integer comProvinceCode;

    @ApiModelProperty("公司所在省份名称")
    private String comProvinceName;

    @ApiModelProperty("统一社会信用代码")
    private String creditCode;

    @ApiModelProperty("企业类型code:1.政府单位;2.事业单位;3.国企;4.私企;5.外企;6.其他")
    private Integer comTypeCode;

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public Integer getComID() {
        return comID;
    }

    public void setComID(Integer comID) {
        this.comID = comID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getIdentifyNumber() {
        return identifyNumber;
    }

    public void setIdentifyNumber(String identifyNumber) {
        this.identifyNumber = identifyNumber;
    }

    public Integer getIdentifyType() {
        return identifyType;
    }

    public void setIdentifyType(Integer identifyType) {
        this.identifyType = identifyType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(Integer provinceCode) {
        this.provinceCode = provinceCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public String getSocialSecurityNO() {
        return socialSecurityNO;
    }

    public void setSocialSecurityNO(String socialSecurityNO) {
        this.socialSecurityNO = socialSecurityNO;
    }

    public String getIdentityCardFrontURL() {
        return identityCardFrontURL;
    }

    public void setIdentityCardFrontURL(String identityCardFrontURL) {
        this.identityCardFrontURL = identityCardFrontURL;
    }

    public String getIdentityCardBackURL() {
        return identityCardBackURL;
    }

    public void setIdentityCardBackURL(String identityCardBackURL) {
        this.identityCardBackURL = identityCardBackURL;
    }

    public String getWorkCardURL() {
        return workCardURL;
    }

    public void setWorkCardURL(String workCardURL) {
        this.workCardURL = workCardURL;
    }

    public String getSecurityCardURL() {
        return securityCardURL;
    }

    public void setSecurityCardURL(String securityCardURL) {
        this.securityCardURL = securityCardURL;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public Integer getComCityCode() {
        return comCityCode;
    }

    public void setComCityCode(Integer comCityCode) {
        this.comCityCode = comCityCode;
    }

    public Integer getComProvinceCode() {
        return comProvinceCode;
    }

    public void setComProvinceCode(Integer comProvinceCode) {
        this.comProvinceCode = comProvinceCode;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public Integer getComTypeCode() {
        return comTypeCode;
    }

    public void setComTypeCode(Integer comTypeCode) {
        this.comTypeCode = comTypeCode;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getComCityName() {
        return comCityName;
    }

    public void setComCityName(String comCityName) {
        this.comCityName = comCityName;
    }

    public String getComProvinceName() {
        return comProvinceName;
    }

    public void setComProvinceName(String comProvinceName) {
        this.comProvinceName = comProvinceName;
    }
}
