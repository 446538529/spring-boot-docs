package com.picc.piccunicom.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(description = "it_unicom_company_info")
public class CompanyInfo implements Serializable {

    @ApiModelProperty("企业id")
    private String comID;

    @ApiModelProperty("企业名称")
    private String comName;

    @ApiModelProperty("登录口令")
    private String password;

    @ApiModelProperty("统一社会信用代码")
    private String creditCode;

    @ApiModelProperty("企业类型code:1.政府单位;2.事业单位;3.国企;4.私企;5.外企;6.其他")
    private Integer comTypeCode;

    @ApiModelProperty("所属省份code")
    private Integer provinceCode;

    @ApiModelProperty("所属地市code")
    private Integer cityCode;

    @ApiModelProperty("现办公地址")
    private String address;

    @ApiModelProperty("企业联系人姓名")
    private String linkManName;

    @ApiModelProperty("企业联系人岗位")
    private String linkManPost;

    @ApiModelProperty("企业联系人电话")
    private String linkManPhone;

    @ApiModelProperty("信用额度")
    private BigDecimal creditLimit;

    @ApiModelProperty("信用期限")
    private Date creditEndDate;

    @ApiModelProperty("是否存在以企业名义入网:0.否;1.是")
    private Boolean netInFlag;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("营业执照")
    private String lincenceURL;

    @ApiModelProperty("有效状态")
    private Integer validStatus;

    @ApiModelProperty("创建人")
    private String creatorCode;

    @ApiModelProperty("创建时间")
    private Date insertTimeForHis;

    @ApiModelProperty("修改人")
    private String updaterCode;

    @ApiModelProperty("修改时间")
    private Date updateTimeForHis;

    private static final long serialVersionUID = 1L;

    public String getComID() {
        return comID;
    }

    public void setComID(String comID) {
        this.comID = comID;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comname) {
        this.comName = comname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditcode) {
        this.creditCode = creditcode;
    }

    public Integer getComTypeCode() {
        return comTypeCode;
    }

    public void setComTypeCode(Integer comtypecode) {
        this.comTypeCode = comtypecode;
    }

    public Integer getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(Integer provincecode) {
        this.provinceCode = provincecode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer citycode) {
        this.cityCode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLinkManName() {
        return linkManName;
    }

    public void setLinkManName(String linkmanname) {
        this.linkManName = linkmanname;
    }

    public String getLinkManPost() {
        return linkManPost;
    }

    public void setLinkManPost(String linkmanpost) {
        this.linkManPost = linkmanpost;
    }

    public String getLinkManPhone() {
        return linkManPhone;
    }

    public void setLinkManPhone(String linkmanphone) {
        this.linkManPhone = linkmanphone;
    }

    public BigDecimal getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(BigDecimal creditlimit) {
        this.creditLimit = creditlimit;
    }

    public Date getCreditEndDate() {
        return creditEndDate;
    }

    public void setCreditEndDate(Date creditenddate) {
        this.creditEndDate = creditenddate;
    }

    public Boolean getNetInFlag() {
        return netInFlag;
    }

    public void setNetInFlag(Boolean netinflag) {
        this.netInFlag = netinflag;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getLincenceURL() {
        return lincenceURL;
    }

    public void setLincenceURL(String lincenceurl) {
        this.lincenceURL = lincenceurl;
    }

    public Integer getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Integer validstatus) {
        this.validStatus = validstatus;
    }

    public String getCreatorCode() {
        return creatorCode;
    }

    public void setCreatorCode(String creatorcode) {
        this.creatorCode = creatorcode;
    }

    public Date getInsertTimeForHis() {
        return insertTimeForHis;
    }

    public void setInsertTimeForHis(Date inserttimeforhis) {
        this.insertTimeForHis = inserttimeforhis;
    }

    public String getUpdaterCode() {
        return updaterCode;
    }

    public void setUpdaterCode(String updatercode) {
        this.updaterCode = updatercode;
    }

    public Date getUpdateTimeForHis() {
        return updateTimeForHis;
    }

    public void setUpdateTimeForHis(Date updatetimeforhis) {
        this.updateTimeForHis = updatetimeforhis;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", comid=").append(comID);
        sb.append(", comname=").append(comName);
        sb.append(", password=").append(password);
        sb.append(", creditcode=").append(creditCode);
        sb.append(", comtypecode=").append(comTypeCode);
        sb.append(", provincecode=").append(provinceCode);
        sb.append(", citycode=").append(cityCode);
        sb.append(", address=").append(address);
        sb.append(", linkmanname=").append(linkManName);
        sb.append(", linkmanpost=").append(linkManPost);
        sb.append(", linkmanphone=").append(linkManPhone);
        sb.append(", creditlimit=").append(creditLimit);
        sb.append(", creditenddate=").append(creditEndDate);
        sb.append(", netinflag=").append(netInFlag);
        sb.append(", remark=").append(remark);
        sb.append(", lincenceurl=").append(lincenceURL);
        sb.append(", validstatus=").append(validStatus);
        sb.append(", creatorcode=").append(creatorCode);
        sb.append(", inserttimeforhis=").append(insertTimeForHis);
        sb.append(", updatercode=").append(updaterCode);
        sb.append(", updatetimeforhis=").append(updateTimeForHis);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}