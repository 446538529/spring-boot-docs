package com.picc.piccunicom.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

@ApiModel(description = "it_unicom_order_status")
public class OrderStatus implements Serializable {

    @ApiModelProperty("订单id")
    private String orderID;

    @ApiModelProperty("订单类型:1.个人;2.企业")
    private Integer orderType;

    @ApiModelProperty("资质申请提交时间")
    private Date submitTime;

    @ApiModelProperty("资质申请提交人code")
    private String submitterCode;

    @ApiModelProperty("资质申请提交人name")
    private String submitterName;

    @ApiModelProperty("资质审核状态:0.待提交;1.待审核;2.审核通过;3.审核未通过")
    private Integer auditStatus;

    @ApiModelProperty("资质审核时间")
    private Date auditTime;

    @ApiModelProperty("资质审核提交人code")
    private String autitorCode;

    @ApiModelProperty("资质审核提交人name")
    private String autitorName;

    @ApiModelProperty("资质审核意见")
    private String auditReason;

    @ApiModelProperty("投保状态:0.待投保;1.已投保;2.已终保")
    private Integer renewType;

    @ApiModelProperty("投保时间")
    private Date underWrittenTime;

    @ApiModelProperty("投保状态更新人code")
    private String prpUpdaterCode;

    @ApiModelProperty("投保状态更新人name")
    private String prpUpdaterName;

    @ApiModelProperty("理赔状态:0.未申请;1.审核中;2.审核退回;3.理赔中;4.理赔完成")
    private Integer claimStatus;

    @ApiModelProperty("有效状态")
    private Integer validStatus;

    @ApiModelProperty("创建人")
    private String creatorCode;

    @ApiModelProperty("创建时间")
    private Date insertTimeForHis;

    @ApiModelProperty("修改人")
    private String updaterCode;

    @ApiModelProperty("修改时间")
    private Date updateTimeForHis;

    private static final long serialVersionUID = 1L;

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer ordertype) {
        this.orderType = ordertype;
    }

    public Date getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(Date submittime) {
        this.submitTime = submittime;
    }

    public String getSubmitterCode() {
        return submitterCode;
    }

    public void setSubmitterCode(String submittercode) {
        this.submitterCode = submittercode;
    }

    public String getSubmitterName() {
        return submitterName;
    }

    public void setSubmitterName(String submittername) {
        this.submitterName = submittername;
    }

    public Integer getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditstatus) {
        this.auditStatus = auditstatus;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date audittime) {
        this.auditTime = audittime;
    }

    public String getAutitorCode() {
        return autitorCode;
    }

    public void setAutitorCode(String autitorcode) {
        this.autitorCode = autitorcode;
    }

    public String getAutitorName() {
        return autitorName;
    }

    public void setAutitorName(String autitorname) {
        this.autitorName = autitorname;
    }

    public String getAuditReason() {
        return auditReason;
    }

    public void setAuditReason(String auditreason) {
        this.auditReason = auditreason;
    }

    public Integer getRenewType() {
        return renewType;
    }

    public void setRenewType(Integer underwrittenstatus) {
        this.renewType = underwrittenstatus;
    }

    public Date getUnderWrittenTime() {
        return underWrittenTime;
    }

    public void setUnderWrittenTime(Date underwrittentime) {
        this.underWrittenTime = underwrittentime;
    }

    public String getPrpUpdaterCode() {
        return prpUpdaterCode;
    }

    public void setPrpUpdaterCode(String prpupdatercode) {
        this.prpUpdaterCode = prpupdatercode;
    }

    public String getPrpUpdaterName() {
        return prpUpdaterName;
    }

    public void setPrpUpdaterName(String prpupdatername) {
        this.prpUpdaterName = prpupdatername;
    }

    public Integer getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(Integer claimstatus) {
        this.claimStatus = claimstatus;
    }

    public Integer getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Integer validstatus) {
        this.validStatus = validstatus;
    }

    public String getCreatorCode() {
        return creatorCode;
    }

    public void setCreatorCode(String creatorcode) {
        this.creatorCode = creatorcode;
    }

    public Date getInsertTimeForHis() {
        return insertTimeForHis;
    }

    public void setInsertTimeForHis(Date inserttimeforhis) {
        this.insertTimeForHis = inserttimeforhis;
    }

    public String getUpdaterCode() {
        return updaterCode;
    }

    public void setUpdaterCode(String updatercode) {
        this.updaterCode = updatercode;
    }

    public Date getUpdateTimeForHis() {
        return updateTimeForHis;
    }

    public void setUpdateTimeForHis(Date updatetimeforhis) {
        this.updateTimeForHis = updatetimeforhis;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", orderid=").append(orderID);
        sb.append(", ordertype=").append(orderType);
        sb.append(", submittime=").append(submitTime);
        sb.append(", submittercode=").append(submitterCode);
        sb.append(", submittername=").append(submitterName);
        sb.append(", auditstatus=").append(auditStatus);
        sb.append(", audittime=").append(auditTime);
        sb.append(", autitorcode=").append(autitorCode);
        sb.append(", autitorname=").append(autitorName);
        sb.append(", auditreason=").append(auditReason);
        sb.append(", underwrittenstatus=").append(renewType);
        sb.append(", underwrittentime=").append(underWrittenTime);
        sb.append(", prpupdatercode=").append(prpUpdaterCode);
        sb.append(", prpupdatername=").append(prpUpdaterName);
        sb.append(", claimstatus=").append(claimStatus);
        sb.append(", validstatus=").append(validStatus);
        sb.append(", creatorcode=").append(creatorCode);
        sb.append(", inserttimeforhis=").append(insertTimeForHis);
        sb.append(", updatercode=").append(updaterCode);
        sb.append(", updatetimeforhis=").append(updateTimeForHis);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}