package com.picc.piccunicom.service.impl;

import com.aliyun.oss.OSSClient;
import com.picc.piccunicom.service.OssService;
import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Date;

@Service
public class OssServiceImpl implements OssService {
    @Value("${aliyun.oss.access.key.id}")
    private String accessId;
    @Value("${aliyun.oss.access.key.secret}")
    private String accessKey;
    @Value("${aliyun.oss.end.point}")
    private String endpoint;
    @Value("${aliyun.oss.bucket.name}")
    private String bucket;
    @Value("${aliyun.oss.bucketname.endpoint}")
    private String OSS_URL;

    private OSSClient ossClient = null;

    private FastDateFormat dateFormat=FastDateFormat.getInstance("yyyyMMddHHmmssSSS");
    public OssServiceImpl(){
    }

    public OSSClient getClient(){
        if(this.ossClient==null){
            this.ossClient=new OSSClient(endpoint,accessId,accessKey);
        }
        return this.ossClient;
    }

    @Override
    public String put(String fileName, InputStream InputStream) {
        OSSClient ossClient=getClient();
        fileName=dateFormat.format(new Date())+"-"+fileName;
        ossClient.putObject(bucket,fileName,InputStream);
        return OSS_URL+"/"+fileName;
    }


}
