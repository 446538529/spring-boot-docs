package com.picc.piccunicom.service;

import com.github.pagehelper.PageInfo;
import com.picc.common.Resp;
import com.picc.piccunicom.param.*;

import java.util.Map;

public interface CustomerService {
    void addCustomer(AddCustomerDTO dto, Map<String,String> files);
    String queryByIdentifyNo(String identifyNo);

    Resp<CustomerInfoDTO> queryCustomerById(String customerID);

    Resp<PageInfo> queryCustomerList(QueryCustomerParamDTO dto);

    void submitApply(SubmitApplyParamDTO dto);

    void auditCustomer(AuditParamDto dto);

    void updateSecure(UpdateSecureParamDTO dto);
}
